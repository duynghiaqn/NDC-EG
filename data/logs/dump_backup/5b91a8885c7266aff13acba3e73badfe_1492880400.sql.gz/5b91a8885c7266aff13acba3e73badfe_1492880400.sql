-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: April 23, 2017, 10:18 AM GMT
-- Server version: 5.5.5-10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8mb4';
SET SESSION `character_set_results`='utf8mb4';
SET SESSION `character_set_connection`='utf8mb4';
SET SESSION `collation_connection`='utf8mb4_unicode_ci';
SET NAMES 'utf8mb4';
ALTER DATABASE DEFAULT CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_ci`;

--
-- Database: `egov`
--


-- ---------------------------------------


--
-- Table structure for table `nn1_authors`
--

DROP TABLE IF EXISTS `nn1_authors`;
CREATE TABLE `nn1_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text  COLLATE utf8mb4_unicode_ci,
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_authors`
--

INSERT INTO `nn1_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'e615d2da1e67f94c4852e43d4a09f732', 1492939274, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36');


-- ---------------------------------------


--
-- Table structure for table `nn1_authors_config`
--

DROP TABLE IF EXISTS `nn1_authors_config`;
CREATE TABLE `nn1_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_authors_module`
--

DROP TABLE IF EXISTS `nn1_authors_module`;
CREATE TABLE `nn1_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_authors_module`
--

INSERT INTO `nn1_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '36f08f6d9ffb5e08ca015745d000e2bb'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, 'e6f04f336f84c43babc34934569e0e28'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '9fcd0840c4b409cfc121833794a1f9a9'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'f12ef0deea06d72d9c686bde8907da4e'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '4bdaed8decb2a7c23078b29841c17702'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, '6258f182d16895e01cd97c28c69c4b53'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '2daec5bc3627ecd4e580339a61452d8e'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '0237064b94e667bdecc946902148a8df'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '259e20466f672cb7408a6d97dc3b7f85'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '7c604bd3ddcc2101200e8de20207cfc7'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '2706aab5175ebbde4296868e1765df9d');


-- ---------------------------------------


--
-- Table structure for table `nn1_banip`
--

DROP TABLE IF EXISTS `nn1_banip`;
CREATE TABLE `nn1_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_banners_click`
--

DROP TABLE IF EXISTS `nn1_banners_click`;
CREATE TABLE `nn1_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_country` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_ref` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_banners_clients`
--

DROP TABLE IF EXISTS `nn1_banners_clients`;
CREATE TABLE `nn1_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `yim` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtype` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_banners_plans`
--

DROP TABLE IF EXISTS `nn1_banners_plans`;
CREATE TABLE `nn1_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `form` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_banners_plans`
--

INSERT INTO `nn1_banners_plans` VALUES
(1, '', 'Quảng cáo giữa trang', '', 'sequential', 755, 72, 1), 
(2, '', 'Quảng cáo trái', '', 'sequential', 212, 800, 1), 
(3, '', 'Quảng cáo phải', '', 'random', 250, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_banners_rows`
--

DROP TABLE IF EXISTS `nn1_banners_rows`;
CREATE TABLE `nn1_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_ext` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_mime` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageforswf` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `click_url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_banners_rows`
--

INSERT INTO `nn1_banners_rows` VALUES
(3, 'Quang cao giua trang', 1, 0, 'webnhanh.jpg', 'png', 'image/jpeg', 575, 72, '', '', 'http://webnhanh.vn', '_blank', 1492855769, 1492855769, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_config`
--

DROP TABLE IF EXISTS `nn1_config`;
CREATE TABLE `nn1_config` (
  `lang` varchar(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sys',
  `module` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_value` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_config`
--

INSERT INTO `nn1_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '91'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '1'), 
('sys', 'global', 'version', '4.0.29'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'auto_login_after_reg', '1'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '2'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '8'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '150'), 
('sys', 'define', 'nv_gfx_height', '40'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, s, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'Trang thông tin điện tử'), 
('vi', 'global', 'site_logo', 'uploads/banners/logo.png'), 
('vi', 'global', 'site_banner', ''), 
('vi', 'global', 'site_favicon', ''), 
('vi', 'global', 'site_description', 'Trang thông tin điện tử'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'theme_type', 'r'), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '0'), 
('vi', 'global', 'upload_logo', ''), 
('vi', 'global', 'upload_logo_pos', 'bottomRight'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1492943010'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'global', 'ssl_https_modules', ''), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_two_column'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '70'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', ''), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'top'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '0'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Y'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '0'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('vi', 'freecontent', 'next_execute', '0'), 
('vi', 'work-schedules', 'group_add', '1'), 
('vi', 'work-schedules', 'group_edit', '1'), 
('vi', 'work-schedules', 'display_element', '1'), 
('vi', 'work-schedules', 'display_location', '1'), 
('vi', 'contact', 'bodytext', 'Để không ngừng nâng cao chất lượng dịch vụ và đáp ứng tốt hơn nữa các yêu cầu của Quý khách, chúng tôi mong muốn nhận được các thông tin phản hồi. Nếu Quý khách có bất kỳ thắc mắc hoặc đóng góp nào, xin vui lòng liên hệ với chúng tôi theo thông tin dưới đây. Chúng tôi sẽ phản hồi lại Quý khách trong thời gian sớm nhất.'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'nndesign.coltd@gmail.com'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'nndesign.coltd@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', '127.0.0.1'), 
('sys', 'global', 'cookie_prefix', 'nv4c_h1qvm'), 
('sys', 'global', 'session_prefix', 'nv4s_w57Af0'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'KN1LkoJgZTOl5JIGag88-yjdS5KCYGUzpeSSBmoPPPs,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'work-schedules', 'display_host', '1'), 
('vi', 'work-schedules', 'display_note', '0'), 
('vi', 'work-schedules', 'require_element', '1'), 
('vi', 'work-schedules', 'require_location', '1'), 
('vi', 'work-schedules', 'require_host', '1'), 
('vi', 'work-schedules', 'require_note', '0'), 
('vi', 'work-schedules', 'show_type', 'week'), 
('vi', 'work-schedules', 'auto_delete', '0'), 
('vi', 'work-schedules', 'auto_delete_time', '604800'), 
('vi', 'work-schedules', 'cron_next_check', '0'), 
('vi', 'work-schedules', 'cron_interval', '300');


-- ---------------------------------------


--
-- Table structure for table `nn1_cookies`
--

DROP TABLE IF EXISTS `nn1_cookies`;
CREATE TABLE `nn1_cookies` (
  `name` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_cookies`
--

INSERT INTO `nn1_cookies` VALUES
('nv4c_b1Spx_ctr', 'MTEzXzE2NV81MF8yMS5WTg==', '.api.nukeviet.vn', '/', 1524452653, 0), 
('nv4c_b1Spx_u_lang', '3KI,', '.api.nukeviet.vn', '/', 1524020653, 0), 
('nv4c_b1Spx_statistic_vi', 'l21tlZ6XZmxqZQ,,', '.api.nukeviet.vn', '/', 1492918453, 0), 
('nv4c_b1Spx_nvvithemever', 'deleted', '.api.nukeviet.vn', '/', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_counter`
--

DROP TABLE IF EXISTS `nn1_counter`;
CREATE TABLE `nn1_counter` (
  `c_type` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_val` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_counter`
--

INSERT INTO `nn1_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1492942554, 0), 
('total', 'hits', 1492942554, 89, 89), 
('year', '2017', 1492942554, 89, 89), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('year', '2024', 0, 0, 0), 
('year', '2025', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 1492942554, 89, 89), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 0, 0, 0), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 0, 0, 0), 
('day', '07', 0, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 0, 0, 0), 
('day', '10', 0, 0, 0), 
('day', '11', 0, 0, 0), 
('day', '12', 0, 0, 0), 
('day', '13', 0, 0, 0), 
('day', '14', 0, 0, 0), 
('day', '15', 0, 0, 0), 
('day', '16', 0, 0, 0), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 0, 0, 0), 
('day', '21', 0, 0, 0), 
('day', '22', 1492875408, 20, 20), 
('day', '23', 1492942554, 69, 69), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 0, 0, 0), 
('day', '27', 0, 0, 0), 
('day', '28', 0, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 1492942554, 69, 69), 
('dayofweek', 'Monday', 0, 0, 0), 
('dayofweek', 'Tuesday', 0, 0, 0), 
('dayofweek', 'Wednesday', 0, 0, 0), 
('dayofweek', 'Thursday', 0, 0, 0), 
('dayofweek', 'Friday', 0, 0, 0), 
('dayofweek', 'Saturday', 1492875408, 20, 20), 
('hour', '00', 0, 0, 0), 
('hour', '01', 0, 0, 0), 
('hour', '02', 0, 0, 0), 
('hour', '03', 0, 0, 0), 
('hour', '04', 0, 0, 0), 
('hour', '05', 0, 0, 0), 
('hour', '06', 1492904679, 3, 3), 
('hour', '07', 1492907205, 4, 4), 
('hour', '08', 1492911663, 4, 4), 
('hour', '09', 1492916260, 7, 7), 
('hour', '10', 1492919767, 6, 6), 
('hour', '11', 1492922889, 4, 4), 
('hour', '12', 1492926850, 9, 9), 
('hour', '13', 1492930267, 6, 6), 
('hour', '14', 1492930862, 1, 1), 
('hour', '15', 1492937423, 13, 13), 
('hour', '16', 1492941549, 9, 9), 
('hour', '17', 1492942554, 3, 3), 
('hour', '18', 0, 0, 0), 
('hour', '19', 1492865806, 0, 0), 
('hour', '20', 1492869193, 0, 0), 
('hour', '21', 1492872400, 0, 0), 
('hour', '22', 1492875408, 0, 0), 
('hour', '23', 0, 0, 0), 
('bot', 'googlebot', 0, 0, 0), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 1492942554, 39, 39), 
('browser', 'edge', 0, 0, 0), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1492914173, 3, 3), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 0, 0, 0), 
('browser', 'iphone', 0, 0, 0), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1492942262, 47, 47), 
('browser', 'cococ', 0, 0, 0), 
('browser', 'android', 0, 0, 0), 
('browser', 'googlebot', 0, 0, 0), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('os', 'unknown', 0, 0, 0), 
('os', 'win', 0, 0, 0), 
('os', 'win10', 0, 0, 0), 
('os', 'win8', 0, 0, 0), 
('os', 'win7', 1492942554, 89, 89), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 0, 0, 0), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 0, 0, 0), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1492942554, 89, 89), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_cronjobs`
--

DROP TABLE IF EXISTS `nn1_cronjobs`;
CREATE TABLE `nn1_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_func` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_cronjobs`
--

INSERT INTO `nn1_cronjobs` VALUES
(1, 1492855769, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1492942710, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1492855769, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1492856048, 1, 'Tự động lưu CSDL'), 
(3, 1492855769, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1492941829, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1492855769, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1492940514, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1492855769, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1492856048, 1, 'Xóa các file error_log quá hạn'), 
(6, 1492855769, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1492855769, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1492941829, 1, 'Xóa các referer quá hạn'), 
(8, 1492855769, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1492941829, 1, 'Kiểm tra phiên bản NukeViet'), 
(9, 1492855769, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1492856048, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `nn1_extension_files`
--

DROP TABLE IF EXISTS `nn1_extension_files`;
CREATE TABLE `nn1_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  AUTO_INCREMENT=477  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_extension_files`
--

INSERT INTO `nn1_extension_files` VALUES
(1, 'module', 'work-schedules', 'modules/work-schedules/action_mysql.php', 1492916685, 0), 
(2, 'module', 'work-schedules', 'modules/work-schedules/admin/config-display.php', 1492916685, 0), 
(3, 'module', 'work-schedules', 'modules/work-schedules/admin/config-sys.php', 1492916685, 0), 
(4, 'module', 'work-schedules', 'modules/work-schedules/admin/config.php', 1492916685, 0), 
(5, 'module', 'work-schedules', 'modules/work-schedules/admin/index.html', 1492916685, 0), 
(6, 'module', 'work-schedules', 'modules/work-schedules/admin/main.php', 1492916685, 0), 
(7, 'module', 'work-schedules', 'modules/work-schedules/admin.functions.php', 1492916685, 0), 
(8, 'module', 'work-schedules', 'modules/work-schedules/admin.menu.php', 1492916685, 0), 
(9, 'module', 'work-schedules', 'modules/work-schedules/funcs/add.php', 1492916685, 0), 
(10, 'module', 'work-schedules', 'modules/work-schedules/funcs/edit.php', 1492916685, 0), 
(11, 'module', 'work-schedules', 'modules/work-schedules/funcs/index.html', 1492916685, 0), 
(12, 'module', 'work-schedules', 'modules/work-schedules/funcs/main.php', 1492916685, 0), 
(13, 'module', 'work-schedules', 'modules/work-schedules/funcs/manager.php', 1492916685, 0), 
(14, 'module', 'work-schedules', 'modules/work-schedules/functions.php', 1492916685, 0), 
(15, 'module', 'work-schedules', 'modules/work-schedules/global.functions.php', 1492916685, 0), 
(16, 'module', 'work-schedules', 'modules/work-schedules/index.html', 1492916685, 0), 
(17, 'module', 'work-schedules', 'modules/work-schedules/language/admin_vi.php', 1492916685, 0), 
(18, 'module', 'work-schedules', 'modules/work-schedules/language/data_vi.php', 1492916685, 0), 
(19, 'module', 'work-schedules', 'modules/work-schedules/language/index.html', 1492916685, 0), 
(20, 'module', 'work-schedules', 'modules/work-schedules/language/vi.php', 1492916685, 0), 
(21, 'module', 'work-schedules', 'modules/work-schedules/theme.php', 1492916685, 0), 
(22, 'module', 'work-schedules', 'modules/work-schedules/version.php', 1492916685, 0), 
(23, 'module', 'work-schedules', 'themes/admin_default/css/work-schedules.css', 1492916685, 0), 
(24, 'module', 'work-schedules', 'themes/admin_default/js/work-schedules.js', 1492916685, 0), 
(25, 'module', 'work-schedules', 'themes/admin_default/modules/work-schedules/cfgDisplay.tpl', 1492916685, 0), 
(26, 'module', 'work-schedules', 'themes/admin_default/modules/work-schedules/config-sys.tpl', 1492916685, 0), 
(27, 'module', 'work-schedules', 'themes/admin_default/modules/work-schedules/config.tpl', 1492916685, 0), 
(28, 'module', 'work-schedules', 'themes/admin_default/modules/work-schedules/index.html', 1492916685, 0), 
(29, 'module', 'work-schedules', 'themes/admin_default/modules/work-schedules/main.tpl', 1492916685, 0), 
(30, 'module', 'work-schedules', 'themes/default/css/work-schedules.css', 1492916685, 0), 
(31, 'module', 'work-schedules', 'themes/default/js/work-schedules.js', 1492916685, 0), 
(32, 'module', 'work-schedules', 'themes/default/modules/work-schedules/add.tpl', 1492916685, 0), 
(33, 'module', 'work-schedules', 'themes/default/modules/work-schedules/index.html', 1492916685, 0), 
(34, 'module', 'work-schedules', 'themes/default/modules/work-schedules/info.tpl', 1492916685, 0), 
(35, 'module', 'work-schedules', 'themes/default/modules/work-schedules/main.tpl', 1492916685, 0), 
(36, 'module', 'work-schedules', 'themes/default/modules/work-schedules/manager-list.tpl', 1492916685, 0), 
(37, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-EUC-H.bcmap', 1492917099, 0), 
(38, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-EUC-V.bcmap', 1492917099, 0), 
(39, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-H.bcmap', 1492917099, 0), 
(40, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-RKSJ-H.bcmap', 1492917099, 0), 
(41, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-RKSJ-V.bcmap', 1492917099, 0), 
(42, 'module', 'laws', 'assets/js/pdf.js/cmaps/78-V.bcmap', 1492917099, 0), 
(43, 'module', 'laws', 'assets/js/pdf.js/cmaps/78ms-RKSJ-H.bcmap', 1492917099, 0), 
(44, 'module', 'laws', 'assets/js/pdf.js/cmaps/78ms-RKSJ-V.bcmap', 1492917099, 0), 
(45, 'module', 'laws', 'assets/js/pdf.js/cmaps/83pv-RKSJ-H.bcmap', 1492917099, 0), 
(46, 'module', 'laws', 'assets/js/pdf.js/cmaps/90ms-RKSJ-H.bcmap', 1492917099, 0), 
(47, 'module', 'laws', 'assets/js/pdf.js/cmaps/90ms-RKSJ-V.bcmap', 1492917099, 0), 
(48, 'module', 'laws', 'assets/js/pdf.js/cmaps/90msp-RKSJ-H.bcmap', 1492917099, 0), 
(49, 'module', 'laws', 'assets/js/pdf.js/cmaps/90msp-RKSJ-V.bcmap', 1492917099, 0), 
(50, 'module', 'laws', 'assets/js/pdf.js/cmaps/90pv-RKSJ-H.bcmap', 1492917099, 0), 
(51, 'module', 'laws', 'assets/js/pdf.js/cmaps/90pv-RKSJ-V.bcmap', 1492917099, 0), 
(52, 'module', 'laws', 'assets/js/pdf.js/cmaps/Add-H.bcmap', 1492917099, 0), 
(53, 'module', 'laws', 'assets/js/pdf.js/cmaps/Add-RKSJ-H.bcmap', 1492917099, 0), 
(54, 'module', 'laws', 'assets/js/pdf.js/cmaps/Add-RKSJ-V.bcmap', 1492917099, 0), 
(55, 'module', 'laws', 'assets/js/pdf.js/cmaps/Add-V.bcmap', 1492917099, 0), 
(56, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-0.bcmap', 1492917099, 0), 
(57, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-1.bcmap', 1492917099, 0), 
(58, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-2.bcmap', 1492917099, 0), 
(59, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-3.bcmap', 1492917099, 0), 
(60, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-4.bcmap', 1492917099, 0), 
(61, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-5.bcmap', 1492917099, 0), 
(62, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-6.bcmap', 1492917099, 0), 
(63, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-CNS1-UCS2.bcmap', 1492917099, 0), 
(64, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-0.bcmap', 1492917099, 0), 
(65, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-1.bcmap', 1492917099, 0), 
(66, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-2.bcmap', 1492917099, 0), 
(67, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-3.bcmap', 1492917099, 0), 
(68, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-4.bcmap', 1492917099, 0), 
(69, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-5.bcmap', 1492917099, 0), 
(70, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-GB1-UCS2.bcmap', 1492917099, 0), 
(71, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-0.bcmap', 1492917099, 0), 
(72, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-1.bcmap', 1492917099, 0), 
(73, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-2.bcmap', 1492917099, 0), 
(74, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-3.bcmap', 1492917099, 0), 
(75, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-4.bcmap', 1492917099, 0), 
(76, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-5.bcmap', 1492917099, 0), 
(77, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-6.bcmap', 1492917099, 0), 
(78, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Japan1-UCS2.bcmap', 1492917099, 0), 
(79, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Korea1-0.bcmap', 1492917099, 0), 
(80, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Korea1-1.bcmap', 1492917099, 0), 
(81, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Korea1-2.bcmap', 1492917099, 0), 
(82, 'module', 'laws', 'assets/js/pdf.js/cmaps/Adobe-Korea1-UCS2.bcmap', 1492917099, 0), 
(83, 'module', 'laws', 'assets/js/pdf.js/cmaps/B5-H.bcmap', 1492917099, 0), 
(84, 'module', 'laws', 'assets/js/pdf.js/cmaps/B5-V.bcmap', 1492917099, 0), 
(85, 'module', 'laws', 'assets/js/pdf.js/cmaps/B5pc-H.bcmap', 1492917099, 0), 
(86, 'module', 'laws', 'assets/js/pdf.js/cmaps/B5pc-V.bcmap', 1492917099, 0), 
(87, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS-EUC-H.bcmap', 1492917099, 0), 
(88, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS-EUC-V.bcmap', 1492917099, 0), 
(89, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS1-H.bcmap', 1492917099, 0), 
(90, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS1-V.bcmap', 1492917099, 0), 
(91, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS2-H.bcmap', 1492917099, 0), 
(92, 'module', 'laws', 'assets/js/pdf.js/cmaps/CNS2-V.bcmap', 1492917099, 0), 
(93, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETen-B5-H.bcmap', 1492917099, 0), 
(94, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETen-B5-V.bcmap', 1492917099, 0), 
(95, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETenms-B5-H.bcmap', 1492917099, 0), 
(96, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETenms-B5-V.bcmap', 1492917099, 0), 
(97, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETHK-B5-H.bcmap', 1492917099, 0), 
(98, 'module', 'laws', 'assets/js/pdf.js/cmaps/ETHK-B5-V.bcmap', 1492917099, 0), 
(99, 'module', 'laws', 'assets/js/pdf.js/cmaps/EUC-H.bcmap', 1492917099, 0), 
(100, 'module', 'laws', 'assets/js/pdf.js/cmaps/EUC-V.bcmap', 1492917099, 0), 
(101, 'module', 'laws', 'assets/js/pdf.js/cmaps/Ext-H.bcmap', 1492917099, 0), 
(102, 'module', 'laws', 'assets/js/pdf.js/cmaps/Ext-RKSJ-H.bcmap', 1492917099, 0), 
(103, 'module', 'laws', 'assets/js/pdf.js/cmaps/Ext-RKSJ-V.bcmap', 1492917099, 0), 
(104, 'module', 'laws', 'assets/js/pdf.js/cmaps/Ext-V.bcmap', 1492917099, 0), 
(105, 'module', 'laws', 'assets/js/pdf.js/cmaps/GB-EUC-H.bcmap', 1492917099, 0), 
(106, 'module', 'laws', 'assets/js/pdf.js/cmaps/GB-EUC-V.bcmap', 1492917099, 0), 
(107, 'module', 'laws', 'assets/js/pdf.js/cmaps/GB-H.bcmap', 1492917099, 0), 
(108, 'module', 'laws', 'assets/js/pdf.js/cmaps/GB-V.bcmap', 1492917099, 0), 
(109, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBK-EUC-H.bcmap', 1492917099, 0), 
(110, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBK-EUC-V.bcmap', 1492917099, 0), 
(111, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBK2K-H.bcmap', 1492917099, 0), 
(112, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBK2K-V.bcmap', 1492917099, 0), 
(113, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBKp-EUC-H.bcmap', 1492917099, 0), 
(114, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBKp-EUC-V.bcmap', 1492917099, 0), 
(115, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBpc-EUC-H.bcmap', 1492917099, 0), 
(116, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBpc-EUC-V.bcmap', 1492917099, 0), 
(117, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBT-EUC-H.bcmap', 1492917099, 0), 
(118, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBT-EUC-V.bcmap', 1492917099, 0), 
(119, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBT-H.bcmap', 1492917099, 0), 
(120, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBT-V.bcmap', 1492917099, 0), 
(121, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBTpc-EUC-H.bcmap', 1492917099, 0), 
(122, 'module', 'laws', 'assets/js/pdf.js/cmaps/GBTpc-EUC-V.bcmap', 1492917099, 0), 
(123, 'module', 'laws', 'assets/js/pdf.js/cmaps/H.bcmap', 1492917099, 0), 
(124, 'module', 'laws', 'assets/js/pdf.js/cmaps/Hankaku.bcmap', 1492917099, 0), 
(125, 'module', 'laws', 'assets/js/pdf.js/cmaps/Hiragana.bcmap', 1492917099, 0), 
(126, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKdla-B5-H.bcmap', 1492917099, 0), 
(127, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKdla-B5-V.bcmap', 1492917099, 0), 
(128, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKdlb-B5-H.bcmap', 1492917099, 0), 
(129, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKdlb-B5-V.bcmap', 1492917099, 0), 
(130, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKgccs-B5-H.bcmap', 1492917099, 0), 
(131, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKgccs-B5-V.bcmap', 1492917099, 0), 
(132, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKm314-B5-H.bcmap', 1492917099, 0), 
(133, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKm314-B5-V.bcmap', 1492917099, 0), 
(134, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKm471-B5-H.bcmap', 1492917099, 0), 
(135, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKm471-B5-V.bcmap', 1492917099, 0), 
(136, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKscs-B5-H.bcmap', 1492917099, 0), 
(137, 'module', 'laws', 'assets/js/pdf.js/cmaps/HKscs-B5-V.bcmap', 1492917099, 0), 
(138, 'module', 'laws', 'assets/js/pdf.js/cmaps/Katakana.bcmap', 1492917099, 0), 
(139, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-EUC-H.bcmap', 1492917099, 0), 
(140, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-EUC-V.bcmap', 1492917099, 0), 
(141, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-H.bcmap', 1492917099, 0), 
(142, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-Johab-H.bcmap', 1492917099, 0), 
(143, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-Johab-V.bcmap', 1492917099, 0), 
(144, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSC-V.bcmap', 1492917099, 0), 
(145, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCms-UHC-H.bcmap', 1492917099, 0), 
(146, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCms-UHC-HW-H.bcmap', 1492917099, 0), 
(147, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCms-UHC-HW-V.bcmap', 1492917099, 0), 
(148, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCms-UHC-V.bcmap', 1492917099, 0), 
(149, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCpc-EUC-H.bcmap', 1492917099, 0), 
(150, 'module', 'laws', 'assets/js/pdf.js/cmaps/KSCpc-EUC-V.bcmap', 1492917099, 0), 
(151, 'module', 'laws', 'assets/js/pdf.js/cmaps/LICENSE', 1492917099, 0), 
(152, 'module', 'laws', 'assets/js/pdf.js/cmaps/NWP-H.bcmap', 1492917099, 0), 
(153, 'module', 'laws', 'assets/js/pdf.js/cmaps/NWP-V.bcmap', 1492917099, 0), 
(154, 'module', 'laws', 'assets/js/pdf.js/cmaps/RKSJ-H.bcmap', 1492917099, 0), 
(155, 'module', 'laws', 'assets/js/pdf.js/cmaps/RKSJ-V.bcmap', 1492917099, 0), 
(156, 'module', 'laws', 'assets/js/pdf.js/cmaps/Roman.bcmap', 1492917099, 0), 
(157, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UCS2-H.bcmap', 1492917099, 0), 
(158, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UCS2-V.bcmap', 1492917099, 0), 
(159, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF16-H.bcmap', 1492917099, 0), 
(160, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF16-V.bcmap', 1492917099, 0), 
(161, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF32-H.bcmap', 1492917099, 0), 
(162, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF32-V.bcmap', 1492917099, 0), 
(163, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF8-H.bcmap', 1492917099, 0), 
(164, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniCNS-UTF8-V.bcmap', 1492917099, 0), 
(165, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UCS2-H.bcmap', 1492917099, 0), 
(166, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UCS2-V.bcmap', 1492917099, 0), 
(167, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF16-H.bcmap', 1492917099, 0), 
(168, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF16-V.bcmap', 1492917099, 0), 
(169, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF32-H.bcmap', 1492917099, 0), 
(170, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF32-V.bcmap', 1492917099, 0), 
(171, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF8-H.bcmap', 1492917099, 0), 
(172, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniGB-UTF8-V.bcmap', 1492917099, 0), 
(173, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UCS2-H.bcmap', 1492917099, 0), 
(174, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UCS2-HW-H.bcmap', 1492917099, 0), 
(175, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UCS2-HW-V.bcmap', 1492917099, 0), 
(176, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UCS2-V.bcmap', 1492917099, 0), 
(177, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF16-H.bcmap', 1492917099, 0), 
(178, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF16-V.bcmap', 1492917099, 0), 
(179, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF32-H.bcmap', 1492917099, 0), 
(180, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF32-V.bcmap', 1492917099, 0), 
(181, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF8-H.bcmap', 1492917099, 0), 
(182, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS-UTF8-V.bcmap', 1492917099, 0), 
(183, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF16-H.bcmap', 1492917099, 0), 
(184, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF16-V.bcmap', 1492917099, 0), 
(185, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF32-H.bcmap', 1492917099, 0), 
(186, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF32-V.bcmap', 1492917099, 0), 
(187, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF8-H.bcmap', 1492917099, 0), 
(188, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJIS2004-UTF8-V.bcmap', 1492917099, 0), 
(189, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISPro-UCS2-HW-V.bcmap', 1492917099, 0), 
(190, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISPro-UCS2-V.bcmap', 1492917099, 0), 
(191, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISPro-UTF8-V.bcmap', 1492917099, 0), 
(192, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISX0213-UTF32-H.bcmap', 1492917099, 0), 
(193, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISX0213-UTF32-V.bcmap', 1492917099, 0), 
(194, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISX02132004-UTF32-H.bcmap', 1492917099, 0), 
(195, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniJISX02132004-UTF32-V.bcmap', 1492917099, 0), 
(196, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UCS2-H.bcmap', 1492917099, 0), 
(197, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UCS2-V.bcmap', 1492917099, 0), 
(198, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF16-H.bcmap', 1492917099, 0), 
(199, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF16-V.bcmap', 1492917099, 0), 
(200, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF32-H.bcmap', 1492917099, 0), 
(201, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF32-V.bcmap', 1492917099, 0), 
(202, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF8-H.bcmap', 1492917099, 0), 
(203, 'module', 'laws', 'assets/js/pdf.js/cmaps/UniKS-UTF8-V.bcmap', 1492917099, 0), 
(204, 'module', 'laws', 'assets/js/pdf.js/cmaps/V.bcmap', 1492917099, 0), 
(205, 'module', 'laws', 'assets/js/pdf.js/cmaps/WP-Symbol.bcmap', 1492917099, 0), 
(206, 'module', 'laws', 'assets/js/pdf.js/compatibility.js', 1492917099, 0), 
(207, 'module', 'laws', 'assets/js/pdf.js/debugger.js', 1492917099, 0), 
(208, 'module', 'laws', 'assets/js/pdf.js/images/annotation-check.svg', 1492917099, 0), 
(209, 'module', 'laws', 'assets/js/pdf.js/images/annotation-comment.svg', 1492917099, 0), 
(210, 'module', 'laws', 'assets/js/pdf.js/images/annotation-help.svg', 1492917099, 0), 
(211, 'module', 'laws', 'assets/js/pdf.js/images/annotation-insert.svg', 1492917099, 0), 
(212, 'module', 'laws', 'assets/js/pdf.js/images/annotation-key.svg', 1492917099, 0), 
(213, 'module', 'laws', 'assets/js/pdf.js/images/annotation-newparagraph.svg', 1492917099, 0), 
(214, 'module', 'laws', 'assets/js/pdf.js/images/annotation-noicon.svg', 1492917099, 0), 
(215, 'module', 'laws', 'assets/js/pdf.js/images/annotation-note.svg', 1492917099, 0), 
(216, 'module', 'laws', 'assets/js/pdf.js/images/annotation-paragraph.svg', 1492917099, 0), 
(217, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-next-rtl.png', 1492917099, 0), 
(218, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-next-rtl@2x.png', 1492917099, 0), 
(219, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-next.png', 1492917099, 0), 
(220, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-next@2x.png', 1492917099, 0), 
(221, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-previous-rtl.png', 1492917099, 0), 
(222, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-previous-rtl@2x.png', 1492917099, 0), 
(223, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-previous.png', 1492917099, 0), 
(224, 'module', 'laws', 'assets/js/pdf.js/images/findbarButton-previous@2x.png', 1492917099, 0), 
(225, 'module', 'laws', 'assets/js/pdf.js/images/grab.cur', 1492917099, 0), 
(226, 'module', 'laws', 'assets/js/pdf.js/images/grabbing.cur', 1492917099, 0), 
(227, 'module', 'laws', 'assets/js/pdf.js/images/loading-icon.gif', 1492917099, 0), 
(228, 'module', 'laws', 'assets/js/pdf.js/images/loading-small.png', 1492917099, 0), 
(229, 'module', 'laws', 'assets/js/pdf.js/images/loading-small@2x.png', 1492917099, 0), 
(230, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-documentProperties.png', 1492917099, 0), 
(231, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-documentProperties@2x.png', 1492917099, 0), 
(232, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-firstPage.png', 1492917099, 0), 
(233, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-firstPage@2x.png', 1492917099, 0), 
(234, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-handTool.png', 1492917099, 0), 
(235, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-handTool@2x.png', 1492917099, 0), 
(236, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-lastPage.png', 1492917099, 0), 
(237, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-lastPage@2x.png', 1492917099, 0), 
(238, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-rotateCcw.png', 1492917099, 0), 
(239, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-rotateCcw@2x.png', 1492917099, 0), 
(240, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-rotateCw.png', 1492917099, 0), 
(241, 'module', 'laws', 'assets/js/pdf.js/images/secondaryToolbarButton-rotateCw@2x.png', 1492917099, 0), 
(242, 'module', 'laws', 'assets/js/pdf.js/images/shadow.png', 1492917099, 0), 
(243, 'module', 'laws', 'assets/js/pdf.js/images/texture.png', 1492917099, 0), 
(244, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-bookmark.png', 1492917099, 0), 
(245, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-bookmark@2x.png', 1492917099, 0), 
(246, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-download.png', 1492917099, 0), 
(247, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-download@2x.png', 1492917099, 0), 
(248, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-menuArrows.png', 1492917099, 0), 
(249, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-menuArrows@2x.png', 1492917099, 0), 
(250, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-openFile.png', 1492917099, 0), 
(251, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-openFile@2x.png', 1492917099, 0), 
(252, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageDown-rtl.png', 1492917099, 0), 
(253, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageDown-rtl@2x.png', 1492917099, 0), 
(254, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageDown.png', 1492917099, 0), 
(255, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageDown@2x.png', 1492917099, 0), 
(256, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageUp-rtl.png', 1492917099, 0), 
(257, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageUp-rtl@2x.png', 1492917099, 0), 
(258, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageUp.png', 1492917099, 0), 
(259, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-pageUp@2x.png', 1492917099, 0), 
(260, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-presentationMode.png', 1492917099, 0), 
(261, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-presentationMode@2x.png', 1492917099, 0), 
(262, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-print.png', 1492917099, 0), 
(263, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-print@2x.png', 1492917099, 0), 
(264, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-search.png', 1492917099, 0), 
(265, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-search@2x.png', 1492917099, 0), 
(266, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-secondaryToolbarToggle-rtl.png', 1492917099, 0), 
(267, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-secondaryToolbarToggle-rtl@2x.png', 1492917099, 0), 
(268, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-secondaryToolbarToggle.png', 1492917099, 0), 
(269, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-secondaryToolbarToggle@2x.png', 1492917099, 0), 
(270, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-sidebarToggle-rtl.png', 1492917099, 0), 
(271, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-sidebarToggle-rtl@2x.png', 1492917099, 0), 
(272, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-sidebarToggle.png', 1492917099, 0), 
(273, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-sidebarToggle@2x.png', 1492917099, 0), 
(274, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewAttachments.png', 1492917099, 0), 
(275, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewAttachments@2x.png', 1492917099, 0), 
(276, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewOutline-rtl.png', 1492917099, 0), 
(277, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewOutline-rtl@2x.png', 1492917099, 0), 
(278, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewOutline.png', 1492917099, 0), 
(279, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewOutline@2x.png', 1492917099, 0), 
(280, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewThumbnail.png', 1492917099, 0), 
(281, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-viewThumbnail@2x.png', 1492917099, 0), 
(282, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-zoomIn.png', 1492917099, 0), 
(283, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-zoomIn@2x.png', 1492917099, 0), 
(284, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-zoomOut.png', 1492917099, 0), 
(285, 'module', 'laws', 'assets/js/pdf.js/images/toolbarButton-zoomOut@2x.png', 1492917099, 0), 
(286, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-collapsed-rtl.png', 1492917099, 0), 
(287, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-collapsed-rtl@2x.png', 1492917099, 0), 
(288, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-collapsed.png', 1492917099, 0), 
(289, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-collapsed@2x.png', 1492917099, 0), 
(290, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-expanded.png', 1492917099, 0), 
(291, 'module', 'laws', 'assets/js/pdf.js/images/treeitem-expanded@2x.png', 1492917099, 0), 
(292, 'module', 'laws', 'assets/js/pdf.js/l10n.js', 1492917099, 0), 
(293, 'module', 'laws', 'assets/js/pdf.js/LICENSE', 1492917099, 0), 
(294, 'module', 'laws', 'assets/js/pdf.js/locale/en-GB/viewer.properties', 1492917099, 0), 
(295, 'module', 'laws', 'assets/js/pdf.js/locale/en-US/viewer.properties', 1492917099, 0), 
(296, 'module', 'laws', 'assets/js/pdf.js/locale/fr/viewer.properties', 1492917099, 0), 
(297, 'module', 'laws', 'assets/js/pdf.js/locale/locale.properties', 1492917099, 0), 
(298, 'module', 'laws', 'assets/js/pdf.js/locale/vi/viewer.properties', 1492917099, 0), 
(299, 'module', 'laws', 'assets/js/pdf.js/pdf.js', 1492917099, 0), 
(300, 'module', 'laws', 'assets/js/pdf.js/pdf.worker.js', 1492917099, 0), 
(301, 'module', 'laws', 'assets/js/pdf.js/viewer.css', 1492917099, 0), 
(302, 'module', 'laws', 'assets/js/pdf.js/viewer.js', 1492917099, 0), 
(303, 'module', 'laws', 'assets/js/pdf.js/viewer.tpl', 1492917099, 0), 
(304, 'module', 'laws', 'modules/laws/action_mysql.php', 1492917099, 0), 
(305, 'module', 'laws', 'modules/laws/admin/area.php', 1492917099, 0), 
(306, 'module', 'laws', 'modules/laws/admin/cat.php', 1492917099, 0), 
(307, 'module', 'laws', 'modules/laws/admin/change_cat.php', 1492917099, 0), 
(308, 'module', 'laws', 'modules/laws/admin/config.php', 1492917099, 0), 
(309, 'module', 'laws', 'modules/laws/admin/getlid.php', 1492917099, 0), 
(310, 'module', 'laws', 'modules/laws/admin/main.php', 1492917099, 0), 
(311, 'module', 'laws', 'modules/laws/admin/scontent.php', 1492917099, 0), 
(312, 'module', 'laws', 'modules/laws/admin/signer.php', 1492917099, 0), 
(313, 'module', 'laws', 'modules/laws/admin/subject.php', 1492917099, 0), 
(314, 'module', 'laws', 'modules/laws/admin.functions.php', 1492917099, 0), 
(315, 'module', 'laws', 'modules/laws/admin.menu.php', 1492917099, 0), 
(316, 'module', 'laws', 'modules/laws/blocks/.htaccess', 1492917099, 0), 
(317, 'module', 'laws', 'modules/laws/blocks/global.block_cat.ini', 1492917099, 0), 
(318, 'module', 'laws', 'modules/laws/blocks/global.block_cat.php', 1492917099, 0), 
(319, 'module', 'laws', 'modules/laws/blocks/global.block_new_law.ini', 1492917099, 0), 
(320, 'module', 'laws', 'modules/laws/blocks/global.block_new_law.php', 1492917099, 0), 
(321, 'module', 'laws', 'modules/laws/blocks/global.block_subject.ini', 1492917099, 0), 
(322, 'module', 'laws', 'modules/laws/blocks/global.block_subject.php', 1492917099, 0), 
(323, 'module', 'laws', 'modules/laws/blocks/index.html', 1492917099, 0), 
(324, 'module', 'laws', 'modules/laws/blocks/module.block_area.php', 1492917099, 0), 
(325, 'module', 'laws', 'modules/laws/blocks/module.block_area_top10_center.php', 1492917099, 0), 
(326, 'module', 'laws', 'modules/laws/blocks/module.block_search.ini', 1492917099, 0), 
(327, 'module', 'laws', 'modules/laws/blocks/module.block_search.php', 1492917099, 0), 
(328, 'module', 'laws', 'modules/laws/blocks/module.block_signer.php', 1492917099, 0), 
(329, 'module', 'laws', 'modules/laws/blocks/module.block_top_down.php', 1492917099, 0), 
(330, 'module', 'laws', 'modules/laws/blocks/module.block_top_view.php', 1492917099, 0), 
(331, 'module', 'laws', 'modules/laws/funcs/.htaccess', 1492917099, 0), 
(332, 'module', 'laws', 'modules/laws/funcs/area.php', 1492917099, 0), 
(333, 'module', 'laws', 'modules/laws/funcs/cat.php', 1492917099, 0), 
(334, 'module', 'laws', 'modules/laws/funcs/detail.php', 1492917099, 0), 
(335, 'module', 'laws', 'modules/laws/funcs/index.html', 1492917099, 0), 
(336, 'module', 'laws', 'modules/laws/funcs/main.php', 1492917099, 0), 
(337, 'module', 'laws', 'modules/laws/funcs/rss.php', 1492917099, 0), 
(338, 'module', 'laws', 'modules/laws/funcs/search.php', 1492917099, 0), 
(339, 'module', 'laws', 'modules/laws/funcs/signer.php', 1492917099, 0), 
(340, 'module', 'laws', 'modules/laws/funcs/sitemap.php', 1492917099, 0), 
(341, 'module', 'laws', 'modules/laws/funcs/subject.php', 1492917099, 0), 
(342, 'module', 'laws', 'modules/laws/functions.php', 1492917099, 0), 
(343, 'module', 'laws', 'modules/laws/index.html', 1492917099, 0), 
(344, 'module', 'laws', 'modules/laws/language/.htaccess', 1492917099, 0), 
(345, 'module', 'laws', 'modules/laws/language/admin_en.php', 1492917099, 0), 
(346, 'module', 'laws', 'modules/laws/language/admin_vi.php', 1492917099, 0), 
(347, 'module', 'laws', 'modules/laws/language/data_vi.php', 1492917099, 0), 
(348, 'module', 'laws', 'modules/laws/language/en.php', 1492917099, 0), 
(349, 'module', 'laws', 'modules/laws/language/index.html', 1492917099, 0), 
(350, 'module', 'laws', 'modules/laws/language/vi.php', 1492917099, 0), 
(351, 'module', 'laws', 'modules/laws/menu.php', 1492917099, 0), 
(352, 'module', 'laws', 'modules/laws/rssdata.php', 1492917099, 0), 
(353, 'module', 'laws', 'modules/laws/search.php', 1492917099, 0), 
(354, 'module', 'laws', 'modules/laws/siteinfo.php', 1492917099, 0), 
(355, 'module', 'laws', 'modules/laws/sitemap.php', 1492917099, 0), 
(356, 'module', 'laws', 'modules/laws/theme.php', 1492917099, 0), 
(357, 'module', 'laws', 'modules/laws/version.php', 1492917099, 0), 
(358, 'module', 'laws', 'themes/admin_default/css/laws.css', 1492917099, 0), 
(359, 'module', 'laws', 'themes/admin_default/images/laws/index.html', 1492917099, 0), 
(360, 'module', 'laws', 'themes/admin_default/js/laws.js', 1492917099, 0), 
(361, 'module', 'laws', 'themes/admin_default/modules/laws/.htaccess', 1492917099, 0), 
(362, 'module', 'laws', 'themes/admin_default/modules/laws/area.tpl', 1492917099, 0), 
(363, 'module', 'laws', 'themes/admin_default/modules/laws/cat.tpl', 1492917099, 0), 
(364, 'module', 'laws', 'themes/admin_default/modules/laws/config.tpl', 1492917099, 0), 
(365, 'module', 'laws', 'themes/admin_default/modules/laws/getlid.tpl', 1492917099, 0), 
(366, 'module', 'laws', 'themes/admin_default/modules/laws/index.html', 1492917099, 0), 
(367, 'module', 'laws', 'themes/admin_default/modules/laws/main.tpl', 1492917099, 0), 
(368, 'module', 'laws', 'themes/admin_default/modules/laws/signer_content.tpl', 1492917099, 0), 
(369, 'module', 'laws', 'themes/admin_default/modules/laws/signer_list.tpl', 1492917099, 0), 
(370, 'module', 'laws', 'themes/admin_default/modules/laws/subject.tpl', 1492917099, 0), 
(371, 'module', 'laws', 'themes/default/css/laws.css', 1492917099, 0), 
(372, 'module', 'laws', 'themes/default/images/laws/arrow2_green.gif', 1492917099, 0), 
(373, 'module', 'laws', 'themes/default/images/laws/big-icon-pack.png', 1492917099, 0), 
(374, 'module', 'laws', 'themes/default/images/laws/button.png', 1492917099, 0), 
(375, 'module', 'laws', 'themes/default/images/laws/down.gif', 1492917099, 0), 
(376, 'module', 'laws', 'themes/default/images/laws/index.html', 1492917099, 0), 
(377, 'module', 'laws', 'themes/default/images/laws/item-bottom-shadow.png', 1492917099, 0), 
(378, 'module', 'laws', 'themes/default/images/laws/no-avatar.jpg', 1492917099, 0), 
(379, 'module', 'laws', 'themes/default/images/laws/right.gif', 1492917099, 0), 
(380, 'module', 'laws', 'themes/default/images/laws/small-icon-pack.png', 1492917099, 0), 
(381, 'module', 'laws', 'themes/default/images/laws/ul-bull.png', 1492917099, 0), 
(382, 'module', 'laws', 'themes/default/js/laws.js', 1492917099, 0), 
(383, 'module', 'laws', 'themes/default/js/laws_jquery.marquee.js', 1492917099, 0), 
(384, 'module', 'laws', 'themes/default/modules/laws/.htaccess', 1492917099, 0), 
(385, 'module', 'laws', 'themes/default/modules/laws/area.tpl', 1492917099, 0), 
(386, 'module', 'laws', 'themes/default/modules/laws/block_area.tpl', 1492917099, 0), 
(387, 'module', 'laws', 'themes/default/modules/laws/block_cat.tpl', 1492917099, 0), 
(388, 'module', 'laws', 'themes/default/modules/laws/block_new_law.tpl', 1492917099, 0), 
(389, 'module', 'laws', 'themes/default/modules/laws/block_search_center.tpl', 1492917099, 0), 
(390, 'module', 'laws', 'themes/default/modules/laws/block_search_vertical.tpl', 1492917099, 0), 
(391, 'module', 'laws', 'themes/default/modules/laws/block_signer.tpl', 1492917099, 0), 
(392, 'module', 'laws', 'themes/default/modules/laws/block_subject.tpl', 1492917099, 0), 
(393, 'module', 'laws', 'themes/default/modules/laws/block_top10_area.tpl', 1492917099, 0), 
(394, 'module', 'laws', 'themes/default/modules/laws/block_topdown.tpl', 1492917099, 0), 
(395, 'module', 'laws', 'themes/default/modules/laws/block_topview.tpl', 1492917099, 0), 
(396, 'module', 'laws', 'themes/default/modules/laws/cat.tpl', 1492917099, 0), 
(397, 'module', 'laws', 'themes/default/modules/laws/detail.tpl', 1492917099, 0), 
(398, 'module', 'laws', 'themes/default/modules/laws/index.html', 1492917099, 0), 
(399, 'module', 'laws', 'themes/default/modules/laws/list_other.tpl', 1492917099, 0), 
(400, 'module', 'laws', 'themes/default/modules/laws/main.tpl', 1492917099, 0), 
(401, 'module', 'laws', 'themes/default/modules/laws/main_subject.tpl', 1492917099, 0), 
(402, 'module', 'laws', 'themes/default/modules/laws/search.tpl', 1492917099, 0), 
(403, 'module', 'laws', 'themes/default/modules/laws/signer.tpl', 1492917099, 0), 
(404, 'module', 'laws', 'themes/default/modules/laws/subject.tpl', 1492917099, 0), 
(405, 'module', 'weblinks', 'modules/weblinks/action_mysql.php', 1492921177, 0), 
(406, 'module', 'weblinks', 'modules/weblinks/admin/.htaccess', 1492921177, 0), 
(407, 'module', 'weblinks', 'modules/weblinks/admin/alias.php', 1492921177, 0), 
(408, 'module', 'weblinks', 'modules/weblinks/admin/brokenlink.php', 1492921177, 0), 
(409, 'module', 'weblinks', 'modules/weblinks/admin/cat.php', 1492921177, 0), 
(410, 'module', 'weblinks', 'modules/weblinks/admin/change_cat.php', 1492921177, 0), 
(411, 'module', 'weblinks', 'modules/weblinks/admin/checklink.php', 1492921177, 0), 
(412, 'module', 'weblinks', 'modules/weblinks/admin/config.php', 1492921177, 0), 
(413, 'module', 'weblinks', 'modules/weblinks/admin/content.php', 1492921177, 0), 
(414, 'module', 'weblinks', 'modules/weblinks/admin/delbroken.php', 1492921177, 0), 
(415, 'module', 'weblinks', 'modules/weblinks/admin/del_cat.php', 1492921177, 0), 
(416, 'module', 'weblinks', 'modules/weblinks/admin/del_link.php', 1492921177, 0), 
(417, 'module', 'weblinks', 'modules/weblinks/admin/index.html', 1492921177, 0), 
(418, 'module', 'weblinks', 'modules/weblinks/admin/main.php', 1492921177, 0), 
(419, 'module', 'weblinks', 'modules/weblinks/admin.functions.php', 1492921177, 0), 
(420, 'module', 'weblinks', 'modules/weblinks/admin.menu.php', 1492921177, 0), 
(421, 'module', 'weblinks', 'modules/weblinks/blocks/.htaccess', 1492921177, 0), 
(422, 'module', 'weblinks', 'modules/weblinks/blocks/index.html', 1492921177, 0), 
(423, 'module', 'weblinks', 'modules/weblinks/blocks/module.block_category.php', 1492921177, 0), 
(424, 'module', 'weblinks', 'modules/weblinks/checkurl.class.php', 1492921177, 0), 
(425, 'module', 'weblinks', 'modules/weblinks/funcs/.htaccess', 1492921177, 0), 
(426, 'module', 'weblinks', 'modules/weblinks/funcs/detail.php', 1492921177, 0), 
(427, 'module', 'weblinks', 'modules/weblinks/funcs/index.html', 1492921177, 0), 
(428, 'module', 'weblinks', 'modules/weblinks/funcs/main.php', 1492921177, 0), 
(429, 'module', 'weblinks', 'modules/weblinks/funcs/reportlink.php', 1492921177, 0), 
(430, 'module', 'weblinks', 'modules/weblinks/funcs/rss.php', 1492921177, 0), 
(431, 'module', 'weblinks', 'modules/weblinks/funcs/sitemap.php', 1492921177, 0), 
(432, 'module', 'weblinks', 'modules/weblinks/funcs/viewcat.php', 1492921177, 0), 
(433, 'module', 'weblinks', 'modules/weblinks/funcs/visitlink.php', 1492921177, 0), 
(434, 'module', 'weblinks', 'modules/weblinks/functions.php', 1492921177, 0), 
(435, 'module', 'weblinks', 'modules/weblinks/global.functions.php', 1492921177, 0), 
(436, 'module', 'weblinks', 'modules/weblinks/index.html', 1492921177, 0), 
(437, 'module', 'weblinks', 'modules/weblinks/language/.htaccess', 1492921177, 0), 
(438, 'module', 'weblinks', 'modules/weblinks/language/admin_en.php', 1492921177, 0), 
(439, 'module', 'weblinks', 'modules/weblinks/language/admin_vi.php', 1492921177, 0), 
(440, 'module', 'weblinks', 'modules/weblinks/language/en.php', 1492921177, 0), 
(441, 'module', 'weblinks', 'modules/weblinks/language/vi.php', 1492921177, 0), 
(442, 'module', 'weblinks', 'modules/weblinks/rssdata.php', 1492921177, 0), 
(443, 'module', 'weblinks', 'modules/weblinks/search.php', 1492921177, 0), 
(444, 'module', 'weblinks', 'modules/weblinks/siteinfo.php', 1492921177, 0), 
(445, 'module', 'weblinks', 'modules/weblinks/theme.php', 1492921177, 0), 
(446, 'module', 'weblinks', 'modules/weblinks/version.php', 1492921177, 0), 
(447, 'module', 'weblinks', 'themes/admin_default/js/weblinks.js', 1492921177, 0), 
(448, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/cat.tpl', 1492921177, 0), 
(449, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/checklink.tpl', 1492921177, 0), 
(450, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/config.tpl', 1492921177, 0), 
(451, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/content.tpl', 1492921177, 0), 
(452, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/index.html', 1492921177, 0), 
(453, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/link_broken.tpl', 1492921177, 0), 
(454, 'module', 'weblinks', 'themes/admin_default/modules/weblinks/main.tpl', 1492921177, 0), 
(455, 'module', 'weblinks', 'themes/default/css/weblinks.css', 1492921177, 0), 
(456, 'module', 'weblinks', 'themes/default/images/weblinks/bg_linked_mod.png', 1492921177, 0), 
(457, 'module', 'weblinks', 'themes/default/images/weblinks/bg_link_mod.png', 1492921177, 0), 
(458, 'module', 'weblinks', 'themes/default/images/weblinks/FolderWindows.png', 1492921177, 0), 
(459, 'module', 'weblinks', 'themes/default/images/weblinks/icon-cat.gif', 1492921177, 0), 
(460, 'module', 'weblinks', 'themes/default/images/weblinks/icons.gif', 1492921177, 0), 
(461, 'module', 'weblinks', 'themes/default/images/weblinks/index.html', 1492921177, 0), 
(462, 'module', 'weblinks', 'themes/default/images/weblinks/no_image.gif', 1492921177, 0), 
(463, 'module', 'weblinks', 'themes/default/images/weblinks/OpenWeb.png', 1492921177, 0), 
(464, 'module', 'weblinks', 'themes/default/images/weblinks/report-hover.png', 1492921177, 0), 
(465, 'module', 'weblinks', 'themes/default/images/weblinks/report.png', 1492921177, 0), 
(466, 'module', 'weblinks', 'themes/default/images/weblinks/weblinks.gif', 1492921177, 0), 
(467, 'module', 'weblinks', 'themes/default/modules/weblinks/block_category.tpl', 1492921177, 0), 
(468, 'module', 'weblinks', 'themes/default/modules/weblinks/detail.tpl', 1492921177, 0), 
(469, 'module', 'weblinks', 'themes/default/modules/weblinks/index.html', 1492921177, 0), 
(470, 'module', 'weblinks', 'themes/default/modules/weblinks/main.tpl', 1492921177, 0), 
(471, 'module', 'weblinks', 'themes/default/modules/weblinks/main_page.tpl', 1492921177, 0), 
(472, 'module', 'weblinks', 'themes/default/modules/weblinks/report.tpl', 1492921177, 0), 
(473, 'module', 'weblinks', 'themes/default/modules/weblinks/viewcat.tpl', 1492921177, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_googleplus`
--

DROP TABLE IF EXISTS `nn1_googleplus`;
CREATE TABLE `nn1_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `idprofile` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_language`
--

DROP TABLE IF EXISTS `nn1_language`;
CREATE TABLE `nn1_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_language_file`
--

DROP TABLE IF EXISTS `nn1_language_file`;
CREATE TABLE `nn1_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_file` varchar(200)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `langtype` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_logs`
--

DROP TABLE IF EXISTS `nn1_logs`;
CREATE TABLE `nn1_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_name` varchar(150)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_action` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_acess` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=231  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_logs`
--

INSERT INTO `nn1_logs` VALUES
(1, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492856067), 
(2, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492857216), 
(3, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492865103), 
(4, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492865299), 
(5, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492865328), 
(6, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492865760), 
(7, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492865803), 
(8, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492866134), 
(9, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492866832), 
(10, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492866835), 
(11, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492867418), 
(12, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492867422), 
(13, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492867601), 
(14, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492867787), 
(15, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492867790), 
(16, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492868028), 
(17, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492868138), 
(18, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492868338), 
(19, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492868342), 
(20, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492868465), 
(21, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1492870785), 
(22, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1492870828), 
(23, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1492870851), 
(24, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492871250), 
(25, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492871254), 
(26, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492871861), 
(27, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492871865), 
(28, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1492872073), 
(29, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492872377), 
(30, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492872380), 
(31, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492872383), 
(32, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492873238), 
(33, 'vi', 'news', 'log_del_source', 'VINADES.,JSC', '', 1, 1492873279), 
(34, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thông cáo báo chí', '', 1, 1492873957), 
(35, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Bản tin nội bộ', '', 1, 1492873964), 
(36, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin công nghệ', '', 1, 1492873971), 
(37, 'vi', 'news', 'log_del_source', 'Báo Hà Nội Mới', '', 1, 1492873999), 
(38, 'vi', 'news', 'log_del_source', 'Báo điện tử Dân Trí', '', 1, 1492874001), 
(39, 'vi', 'news', 'log_del_source', 'Bộ Thông tin và Truyền thông', '', 1, 1492874004), 
(40, 'vi', 'themes', 'Thêm block', 'Name : Tin tuc', '', 1, 1492874211), 
(41, 'vi', 'themes', 'Sửa block', 'Name : Tin tuc', '', 1, 1492874237), 
(42, 'vi', 'news', 'Sửa bài viết', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', '', 1, 1492874394), 
(43, 'vi', 'news', 'Sửa bài viết', 'NukeViet 4.0 có gì mới?', '', 1, 1492874433), 
(44, 'vi', 'news', 'Sửa bài viết', 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', '', 1, 1492874548), 
(45, 'vi', 'news', 'Sửa bài viết', 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', '', 1, 1492874569), 
(46, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492875040), 
(47, 'vi', 'about', 'Delete', 'ID: 2', '', 1, 1492875114), 
(48, 'vi', 'about', 'Delete', 'ID: 8', '', 1, 1492875118), 
(49, 'vi', 'login', '[superadmin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1492875141), 
(50, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492903534), 
(51, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492903548), 
(52, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492903552), 
(53, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492903588), 
(54, 'vi', 'themes', 'Sửa block', 'Name : Feedback', '', 1, 1492903975), 
(55, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1492903991), 
(56, 'vi', 'themes', 'Sửa block', 'Name : Copyright', '', 1, 1492904177), 
(57, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492904691), 
(58, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492904695), 
(59, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492905403), 
(60, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492905407), 
(61, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492905552), 
(62, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492905555), 
(63, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906077), 
(64, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906081), 
(65, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906527), 
(66, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906533), 
(67, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906536), 
(68, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906737), 
(69, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906740), 
(70, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906743), 
(71, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906979), 
(72, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492906982), 
(73, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492907173), 
(74, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492907175), 
(75, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492907178), 
(76, 'vi', 'login', '[superadmin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1492908978), 
(77, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492909547), 
(78, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910167), 
(79, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910171), 
(80, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910582), 
(81, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910598), 
(82, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910601), 
(83, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910605), 
(84, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910617), 
(85, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910621), 
(86, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910744), 
(87, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492910748), 
(88, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492910803), 
(89, 'vi', 'login', '[superadmin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1492911035), 
(90, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492911058), 
(91, 'vi', 'themes', 'Thêm block', 'Name : global html', '', 1, 1492911319), 
(92, 'vi', 'themes', 'Sửa block', 'Name : global html', '', 1, 1492911389), 
(93, 'vi', 'themes', 'Sửa block', 'Name : global html', '', 1, 1492911636), 
(94, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492914147), 
(95, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492914162), 
(96, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492914166), 
(97, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492914168), 
(98, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492914203), 
(99, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492914249), 
(100, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492914265), 
(101, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492914908), 
(102, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492915304), 
(103, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492915308), 
(104, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492915372), 
(105, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492915375), 
(106, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492915377), 
(107, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1492915558), 
(108, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492916072), 
(109, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492916075), 
(110, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492916237), 
(111, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492916240), 
(112, 'vi', 'modules', 'Thiết lập module mới work-schedules', '', '', 1, 1492916699), 
(113, 'vi', 'modules', 'Sửa module &ldquo;work-schedules&rdquo;', '', '', 1, 1492916721), 
(114, 'vi', 'modules', 'Thiết lập module mới laws', '', '', 1, 1492917108), 
(115, 'vi', 'modules', 'Sửa module &ldquo;laws&rdquo;', '', '', 1, 1492917171), 
(116, 'vi', 'laws', 'Thêm Lĩnh vực', 'Id: 1', '', 1, 1492917614), 
(117, 'vi', 'laws', 'Thêm Lĩnh vực', 'Id: 2', '', 1, 1492917631), 
(118, 'vi', 'laws', 'Sửa Lĩnh vực', 'Id: 2', '', 1, 1492917641), 
(119, 'vi', 'laws', 'Thêm Lĩnh vực', 'Id: 3', '', 1, 1492917651), 
(120, 'vi', 'laws', 'Thêm Lĩnh vực', 'Id: 4', '', 1, 1492917681), 
(121, 'vi', 'laws', 'Thêm Thể loại', 'Id: 1', '', 1, 1492917853), 
(122, 'vi', 'laws', 'Thêm Cơ quan ban hành', 'Id: ', '', 1, 1492917895), 
(123, 'vi', 'laws', 'Thêm Cơ quan ban hành', 'Id: ', '', 1, 1492917907), 
(124, 'vi', 'laws', 'Thêm người ký văn bản', 'Hồ Quốc Dũng', '', 1, 1492917974), 
(125, 'vi', 'users', 'Xóa nhóm', 'group_id: 10', '', 1, 1492918012), 
(126, 'vi', 'users', 'Xóa nhóm', 'group_id: 12', '', 1, 1492918016), 
(127, 'vi', 'users', 'Xóa nhóm', 'group_id: 11', '', 1, 1492918020), 
(128, 'vi', 'laws', 'Thêm Lĩnh vực', 'Id: 5', '', 1, 1492918127), 
(129, 'vi', 'laws', 'Thêm Thể loại', 'Id: 2', '', 1, 1492918134), 
(130, 'vi', 'laws', 'Thêm Thể loại', 'Id: 3', '', 1, 1492918145), 
(131, 'vi', 'laws', 'Thêm Thể loại', 'Id: 4', '', 1, 1492918156), 
(132, 'vi', 'laws', 'Thêm Thể loại', 'Id: 5', '', 1, 1492918171), 
(133, 'vi', 'about', 'Edit', 'ID: 1', '', 1, 1492918358), 
(134, 'vi', 'about', 'Delete', 'ID: 7', '', 1, 1492918438), 
(135, 'vi', 'about', 'Delete', 'ID: 6', '', 1, 1492918442), 
(136, 'vi', 'about', 'Delete', 'ID: 5', '', 1, 1492918445), 
(137, 'vi', 'about', 'Edit', 'ID: 4', '', 1, 1492918476), 
(138, 'vi', 'about', 'Edit', 'ID: 3', '', 1, 1492918665), 
(139, 'vi', 'banners', 'log_del_banner', 'bannerid 4', '', 1, 1492919137), 
(140, 'vi', 'banners', 'log_del_banner', 'bannerid 2', '', 1, 1492919144), 
(141, 'vi', 'banners', 'log_edit_plan', 'planid 2', '', 1, 1492919207), 
(142, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1492919230), 
(143, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1492919361), 
(144, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1492919389), 
(145, 'vi', 'contact', 'log_del_row', 'rowid 2', '', 1, 1492919447), 
(146, 'vi', 'upload', 'Upload file', 'uploads/laws/65-tb-ubnd.pdf', '', 1, 1492920075), 
(147, 'vi', 'laws', 'Thêm Văn bản', 'Id: 1', '', 1, 1492920150), 
(148, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492920285), 
(149, 'vi', 'laws', 'Thêm người ký văn bản', 'Lê Nhuận', '', 1, 1492920305), 
(150, 'vi', 'laws', 'Thêm người ký văn bản', 'Trần Châu', '', 1, 1492920322), 
(151, 'vi', 'laws', 'Thêm người ký văn bản', 'Nguyễn Tuấn Thanh', '', 1, 1492920358), 
(152, 'vi', 'laws', 'Sửa người ký văn bản', '&nbsp;=&gt;&nbsp;Trần Châu', '', 1, 1492920380), 
(153, 'vi', 'laws', 'Thêm người ký văn bản', 'Nguyễn Đức Thi', '', 1, 1492920405), 
(154, 'vi', 'laws', 'Sửa Thông tin Văn bản', 'Id: 1', '', 1, 1492920446), 
(155, 'vi', 'modules', 'Sửa module &ldquo;laws&rdquo;', '', '', 1, 1492920483), 
(156, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492921022), 
(157, 'vi', 'modules', 'Thiết lập module mới weblinks', '', '', 1, 1492921183), 
(158, 'vi', 'modules', 'Sửa module &ldquo;weblinks&rdquo;', '', '', 1, 1492921205), 
(159, 'vi', 'extensions', 'Cài đặt ứng dụng', 'Block_JavaScript_CSS_HTML_NV_4_x.zip', '', 1, 1492921656), 
(160, 'vi', 'themes', 'Thêm block', 'Name : Thư viện ảnh', '', 1, 1492922163), 
(161, 'vi', 'upload', 'Tạo folder', 'uploads/gallery', '', 1, 1492922221), 
(162, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922357), 
(163, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922418), 
(164, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922518), 
(165, 'vi', 'extensions', 'Cài đặt ứng dụng', 'nv4_block_global.block_photos_new.php.zip', '', 1, 1492922643), 
(166, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922708), 
(167, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922887), 
(168, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492922930), 
(169, 'vi', 'login', '[superadmin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1492924830), 
(170, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492925091), 
(171, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492925212), 
(172, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492925229), 
(173, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492925241), 
(174, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492925266), 
(175, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492925862), 
(176, 'vi', 'themes', 'Thêm block', 'Name : global company info', '', 1, 1492926888), 
(177, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1492926922), 
(178, 'vi', 'themes', 'Sửa block', 'Name : Thông tin website', '', 1, 1492927291), 
(179, 'vi', 'upload', 'Upload file', 'uploads/banners/logo.png', '', 1, 1492927468), 
(180, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492927527), 
(181, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492927530), 
(182, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492927785), 
(183, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492928012), 
(184, 'vi', 'themes', 'Thêm block', 'Name : Liên kết', '', 1, 1492928069), 
(185, 'vi', 'modules', 'Xóa module \"weblinks\"', '', '', 1, 1492928177), 
(186, 'vi', 'modules', 'Xóa module \"siteterms\"', '', '', 1, 1492928192), 
(187, 'vi', 'upload', 'Upload file', 'uploads/banners/2b65bacd1ad861cdvbqppl.jpg', '', 1, 1492928858), 
(188, 'vi', 'upload', 'Upload file', 'uploads/banners/d6cbcdc4319c19adcongbaodiap.jpg', '', 1, 1492928887), 
(189, 'vi', 'upload', 'Upload file', 'uploads/banners/d9f72d038079069dthudt.jpg', '', 1, 1492928909), 
(190, 'vi', 'upload', 'Upload file', 'uploads/banners/fc04b6668bf4a56dtthc.jpg', '', 1, 1492928932), 
(191, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1492929022), 
(192, 'vi', 'themes', 'Thêm block', 'Name : Danh mục', '', 1, 1492929217), 
(193, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492929298), 
(194, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492929541), 
(195, 'vi', 'work-schedules', 'Add Work: ', 'Họp giao ban', '', 1, 1492929687), 
(196, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492934622), 
(197, 'vi', 'themes', 'Sửa block', 'Name : Thư viện ảnh', '', 1, 1492934668), 
(198, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492934698), 
(199, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492935046), 
(200, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1492935205), 
(201, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492936361), 
(202, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492936364), 
(203, 'vi', 'login', '[superadmin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1492936428), 
(204, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492937469), 
(205, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492937484), 
(206, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492937552), 
(207, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492938273), 
(208, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492938858), 
(209, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492938861), 
(210, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492938864), 
(211, 'vi', 'login', '[superadmin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1492939274), 
(212, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939290), 
(213, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939293), 
(214, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939449), 
(215, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939452), 
(216, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939818), 
(217, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492939821), 
(218, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492940048), 
(219, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492940051), 
(220, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492940603), 
(221, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492940669), 
(222, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492940742), 
(223, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492940804), 
(224, 'vi', 'themes', 'Sửa block', 'Name : Danh mục', '', 1, 1492940918), 
(225, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492940979), 
(226, 'vi', 'modules', 'Sửa module &ldquo;comment&rdquo;', '', '', 1, 1492941177), 
(227, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492941377), 
(228, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492941380), 
(229, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492942512), 
(230, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1492942514);


-- ---------------------------------------


--
-- Table structure for table `nn1_notification`
--

DROP TABLE IF EXISTS `nn1_notification`;
CREATE TABLE `nn1_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_plugin`
--

DROP TABLE IF EXISTS `nn1_plugin`;
CREATE TABLE `nn1_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_plugin`
--

INSERT INTO `nn1_plugin` VALUES
(1, 'qrcode.php', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_sessions`
--

DROP TABLE IF EXISTS `nn1_sessions`;
CREATE TABLE `nn1_sessions` (
  `session_id` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_sessions`
--

INSERT INTO `nn1_sessions` VALUES
('nrcng7opcneb17qpteut7lcia6', 1, 'superadmin', 1492942517), 
('pt6sv7itjt2ba1a7lvmfli3593', 0, 'guest', 1492942710);


-- ---------------------------------------


--
-- Table structure for table `nn1_setup`
--

DROP TABLE IF EXISTS `nn1_setup`;
CREATE TABLE `nn1_setup` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tables` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_setup_extensions`
--

DROP TABLE IF EXISTS `nn1_setup_extensions`;
CREATE TABLE `nn1_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_prefix` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_setup_extensions`
--

INSERT INTO `nn1_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(324, 'module', 'work-schedules', 0, 1, 'work-schedules', 'work_schedules', '4.1.00 1492916685', 1492916685, 'hoaquynhtim99 (phantandung92@gmail.com)', 'Module lịch công tác tuần. Quản lý và hiển thị lịch công tác, hỗ trợ cả trình duyệt desktop, mobile, tablet.'), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 1, 'users', 'users', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(312, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(307, 'theme', 'default', 0, 0, 'default', 'default', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(311, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.29 1463652000', 1492855769, 'VINADES (contact@vinades.vn)', ''), 
(254, 'module', 'laws', 0, 1, 'laws', 'laws', '4.1.01 1492917099', 1492917099, 'webnhanh (webnhanh@vinades.vn)', 'Modules văn bản pháp luật giúp các cơ quan, ban ngành trong lĩnh vực pháp luật quản lý thông tin, tra cứu các văn bản 1 cách hệ thống.Modules dùng cho các cơ quan khác cần quản lý văn bản, quy định.'), 
(26, 'module', 'weblinks', 0, 1, 'weblinks', 'weblinks', '4.1.00 1492921177', 1492921177, 'VINADES.,JSC (nukeviet.store@vinades.vn)', 'Module weblinks của hệ thống NukeViet');


-- ---------------------------------------


--
-- Table structure for table `nn1_setup_language`
--

DROP TABLE IF EXISTS `nn1_setup_language`;
CREATE TABLE `nn1_setup_language` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_setup_language`
--

INSERT INTO `nn1_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_upload_dir`
--

DROP TABLE IF EXISTS `nn1_upload_dir`;
CREATE TABLE `nn1_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=22  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_upload_dir`
--

INSERT INTO `nn1_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads', 1492922185, 0, 0, 0, 0), 
(2, 'uploads/about', 0, 0, 0, 0, 0), 
(3, 'uploads/banners', 1492922879, 0, 0, 0, 0), 
(4, 'uploads/contact', 1492922881, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 1492922881, 0, 0, 0, 0), 
(6, 'uploads/menu', 1492922395, 0, 0, 0, 0), 
(7, 'uploads/news', 1492922396, 0, 0, 0, 0), 
(8, 'uploads/news/2016_01', 1492922485, 0, 0, 0, 0), 
(9, 'uploads/news/source', 0, 0, 0, 0, 0), 
(10, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(11, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(12, 'uploads/page', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(15, 'uploads/users/groups', 0, 0, 0, 0, 0), 
(16, 'uploads/news/2017_04', 0, 0, 0, 0, 0), 
(17, 'uploads/work-schedules', 0, 0, 0, 0, 0), 
(18, 'uploads/laws', 1492920040, 0, 0, 0, 0), 
(21, 'uploads/gallery', 1492922221, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_upload_file`
--

DROP TABLE IF EXISTS `nn1_upload_file`;
CREATE TABLE `nn1_upload_file` (
  `name` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ext` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alt` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_upload_file`
--

INSERT INTO `nn1_upload_file` VALUES
('65-tb-ubnd.pdf', 'pdf', 'file', 90002, 'assets/images/pdf.png', 32, 32, '|', 1, 1492920075, 18, '65-tb-ubnd.pdf', '65 tb ubnd'), 
('chuc-mung-...jpg', 'jpg', 'image', 130708, 'assets/news/chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 80, 62, '461|360', 1, 1463601738, 7, 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'chuc mung nukeviet thong tu 20 bo tttt'), 
('hoc-viec-t...jpg', 'jpg', 'image', 167193, 'assets/news/hoc-viec-tai-cong-ty-vinades.jpg', 80, 63, '460|360', 1, 1463601738, 7, 'hoc-viec-tai-cong-ty-vinades.jpg', 'hoc viec tai cong ty vinades'), 
('hoptac.jpg', 'jpg', 'image', 12871, 'assets/news/hoptac.jpg', 80, 66, '382|314', 1, 1463601738, 7, 'hoptac.jpg', 'hoptac'), 
('nangly.jpg', 'jpg', 'image', 34802, 'assets/news/nangly.jpg', 80, 53, '500|332', 1, 1463601738, 7, 'nangly.jpg', 'nangly'), 
('nukeviet-cms.jpg', 'jpg', 'image', 83489, 'assets/news/nukeviet-cms.jpg', 80, 55, '500|345', 1, 1463601738, 7, 'nukeviet-cms.jpg', 'nukeviet cms'), 
('nukeviet-n...jpg', 'jpg', 'image', 18611, 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 1, 1463601738, 7, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'), 
('tap-huan-p...jpg', 'jpg', 'image', 132379, 'assets/news/tap-huan-pgd-ha-dong-2015.jpg', 80, 52, '460|295', 1, 1463601738, 7, 'tap-huan-pgd-ha-dong-2015.jpg', 'tap huan pgd ha dong 2015'), 
('thuc-tap-sinh.jpg', 'jpg', 'image', 71135, 'assets/news/thuc-tap-sinh.jpg', 80, 63, '460|360', 1, 1463601738, 7, 'thuc-tap-sinh.jpg', 'thuc tap sinh'), 
('tuyen-dung...png', 'png', 'image', 118910, 'assets/news/tuyen-dung-nvkd.png', 80, 56, '400|279', 1, 1463601738, 7, 'tuyen-dung-nvkd.png', 'tuyen dung nvkd'), 
('tuyendung-...jpg', 'jpg', 'image', 83783, 'assets/news/tuyendung-kythuat.jpg', 80, 80, '300|300', 1, 1463601738, 7, 'tuyendung-kythuat.jpg', 'tuyendung kythuat'), 
('123host-ne...jpg', 'jpg', 'image', 65162, 'assets/news/2016_01/123host-network-security.jpg', 80, 46, '540|310', 1, 1463601738, 8, '123host-network-security.jpg', '123host network security'), 
('cc-by-nc-sa.png', 'png', 'image', 417, 'assets/news/2016_01/cc-by-nc-sa.png', 80, 15, '80|15', 1, 1463601738, 8, 'cc-by-nc-sa.png', 'cc by nc sa'), 
('cloudlinux...jpg', 'jpg', 'image', 66150, 'assets/news/2016_01/cloudlinux-security.jpg', 80, 46, '540|312', 1, 1463601738, 8, 'cloudlinux-security.jpg', 'cloudlinux security'), 
('cpanel-ddo...jpg', 'jpg', 'image', 82476, 'assets/news/2016_01/cpanel-ddos-protection-malware-scanner.jpg', 80, 45, '540|300', 1, 1463601738, 8, 'cpanel-ddos-protection-malware-scanner.jpg', 'cpanel ddos protection malware scanner'), 
('hosting-12...jpg', 'jpg', 'image', 45292, 'assets/news/2016_01/hosting-123host-nukeviet.jpg', 80, 45, '540|298', 1, 1463601738, 8, 'hosting-123host-nukeviet.jpg', 'hosting 123host nukeviet'), 
('how-to-cho...jpg', 'jpg', 'image', 55022, 'assets/news/2016_01/how-to-choose-hosting.jpg', 80, 50, '540|338', 1, 1463601738, 8, 'how-to-choose-hosting.jpg', 'how to choose hosting'), 
('litespeed-...jpg', 'jpg', 'image', 36867, 'assets/news/2016_01/litespeed-benchmark.jpg', 80, 43, '540|292', 1, 1463601738, 8, 'litespeed-benchmark.jpg', 'litespeed benchmark'), 
('support247.jpg', 'jpg', 'image', 39576, 'assets/news/2016_01/support247.jpg', 80, 22, '540|151', 1, 1463601738, 8, 'support247.jpg', 'support247'), 
('webnhanh.jpg', 'jpg', 'image', 74347, 'assets/banners/webnhanh.jpg', 80, 10, '572|72', 1, 1463601738, 3, 'webnhanh.jpg', 'webnhanh'), 
('cms.jpg', 'jpg', 'image', 29026, 'assets/freecontent/cms.jpg', 80, 44, '130|71', 1, 1463601738, 5, 'cms.jpg', 'cms'), 
('edugate.jpg', 'jpg', 'image', 28008, 'assets/freecontent/edugate.jpg', 80, 44, '130|71', 1, 1463601738, 5, 'edugate.jpg', 'edugate'), 
('portal.jpg', 'jpg', 'image', 25973, 'assets/freecontent/portal.jpg', 80, 44, '130|71', 1, 1463601738, 5, 'portal.jpg', 'portal'), 
('shop.jpg', 'jpg', 'image', 26352, 'assets/freecontent/shop.jpg', 80, 44, '130|71', 1, 1463601738, 5, 'shop.jpg', 'shop'), 
('toa-soan-d...jpg', 'jpg', 'image', 28737, 'assets/freecontent/toa-soan-dien-tu.jpg', 80, 44, '130|71', 1, 1463601738, 5, 'toa-soan-dien-tu.jpg', 'toa soan dien tu'), 
('logo.png', 'png', 'image', 21350, 'assets/banners/logo.png', 80, 18, '482|102', 1, 1492927468, 3, 'logo.png', 'logo'), 
('2b65bacd1a...jpg', 'jpg', 'image', 54859, 'assets/banners/2b65bacd1ad861cdvbqppl.jpg', 80, 18, '298|68', 1, 1492928859, 3, '2b65bacd1ad861cdvbqppl.jpg', 'H1'), 
('d6cbcdc431...jpg', 'jpg', 'image', 55198, 'assets/banners/d6cbcdc4319c19adcongbaodiap.jpg', 80, 18, '298|68', 1, 1492928888, 3, 'd6cbcdc4319c19adcongbaodiap.jpg', 'H2'), 
('d9f72d0380...jpg', 'jpg', 'image', 47174, 'assets/banners/d9f72d038079069dthudt.jpg', 80, 18, '298|68', 1, 1492928910, 3, 'd9f72d038079069dthudt.jpg', 'H3'), 
('fc04b6668b...jpg', 'jpg', 'image', 56419, 'assets/banners/fc04b6668bf4a56dtthc.jpg', 80, 18, '298|68', 1, 1492928933, 3, 'fc04b6668bf4a56dtthc.jpg', 'H4');


-- ---------------------------------------


--
-- Table structure for table `nn1_users`
--

DROP TABLE IF EXISTS `nn1_users`;
CREATE TABLE `nn1_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `photo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text  COLLATE utf8mb4_unicode_ci,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passlostkey` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_openid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users`
--

INSERT INTO `nn1_users` VALUES
(1, 1, 'superadmin', '17c4520f6cfd1ab53d8745e84681eb49', '{SSHA}1PjNOpeS9Pfm5PI7N6g3/9gm0cRRbkVD', 'nndesign.coltd@gmail.com', 'superadmin', '', '', '', 0, '', 1492856031, 'Bạn đến từ đâu ?', 'quynhon', '', 0, 1, '', 1, '', 1492856031, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nn1_users_config`
--

DROP TABLE IF EXISTS `nn1_users_config`;
CREATE TABLE `nn1_users_config` (
  `config` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users_config`
--

INSERT INTO `nn1_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|11223344|654321|696969|1234567|12345678|87654321|123456789|23456789|1234567890|66666666|68686868|66668888|88888888|99999999|999999999|1234569|12345679|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman|hoilamgi|khongbiet|khongco|khongcopass', 1492855769), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1492855769), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1492855769), 
('avatar_width', '80', 1492855769), 
('avatar_height', '80', 1492855769), 
('active_group_newusers', '0', 1492855769), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nn1_users_field`
--

DROP TABLE IF EXISTS `nn1_users_field`;
CREATE TABLE `nn1_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_users_groups`
--

DROP TABLE IF EXISTS `nn1_users_groups`;
CREATE TABLE `nn1_users_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `group_type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0:Sys, 1:approval, 2:public',
  `group_color` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_avatar` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `config` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users_groups`
--

INSERT INTO `nn1_users_groups` VALUES
(1, 'Super admin', '', 'Super Admin', '', 0, '', '', 0, 1492855769, 0, 1, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(2, 'General admin', '', 'General Admin', '', 0, '', '', 0, 1492855769, 0, 2, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(3, 'Module admin', '', 'Module Admin', '', 0, '', '', 0, 1492855769, 0, 3, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(4, 'Users', '', 'Users', '', 0, '', '', 0, 1492855769, 0, 4, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(7, 'New Users', '', 'New Users', '', 0, '', '', 0, 1492855769, 0, 5, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(5, 'Guest', '', 'Guest', '', 0, '', '', 0, 1492855769, 0, 6, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(6, 'All', '', 'All', '', 0, '', '', 0, 1492855769, 0, 7, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}');


-- ---------------------------------------


--
-- Table structure for table `nn1_users_groups_users`
--

DROP TABLE IF EXISTS `nn1_users_groups_users`;
CREATE TABLE `nn1_users_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `is_leader` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `approved` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users_groups_users`
--

INSERT INTO `nn1_users_groups_users` VALUES
(1, 1, 1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `nn1_users_info`
--

DROP TABLE IF EXISTS `nn1_users_info`;
CREATE TABLE `nn1_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users_info`
--

INSERT INTO `nn1_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `nn1_users_openid`
--

DROP TABLE IF EXISTS `nn1_users_openid`;
CREATE TABLE `nn1_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opid` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_users_question`
--

DROP TABLE IF EXISTS `nn1_users_question`;
CREATE TABLE `nn1_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_users_question`
--

INSERT INTO `nn1_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nn1_users_reg`
--

DROP TABLE IF EXISTS `nn1_users_reg`;
CREATE TABLE `nn1_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checknum` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `users_info` text  COLLATE utf8mb4_unicode_ci,
  `openid_info` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_about`
--

DROP TABLE IF EXISTS `nn1_vi_about`;
CREATE TABLE `nn1_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_about`
--

INSERT INTO `nn1_vi_about` VALUES
(1, 'Lời chào mừng', 'Loi-chao-mung', '', '', 0, '', '<h2><span style=\"font-size:20px;\"><strong>Giới thiệu khái quát</strong></span></h2>  <p>NukeViet là một ứng dụng trên nền web có thể sử dụng vào nhiều mục đích khác nhau. Phiên bản đang được phát hành theo giấy phép phần mềm tự do nguồn mở có tên gọi đầy đủ là <a href=\"/about/Gioi-thieu-ve-NukeViet-CMS.html\"><b>NukeViet CMS</b></a> gồm 2 phần chính là phần nhân (core) của hệ thống NukeViet và nhóm chức năng quản trị nội dung của CMS thường được sử dụng để xây dựng các website tin tức do đó người dùng thường nghĩ rằng NukeViet mạnh về hệ thống tin tức. Tuy nhiên, đội ngũ phát triển NukeViet đã phát triển nhiều hệ thống khác nhau cho NukeViet, nổi bật nhất là:</p>  <ul> 	<li>NukeViet Portal: Cổng thông tin hai chiều dùng cho doanh nghiệp.</li> 	<li><a href=\"http://edu.nukeviet.vn\" target=\"_blank\">NukeViet Edu Gate</a>: Cổng thông tin tích hợp nhiều website, sử dụng cho phòng giáo dục, sở giáo dục.</li> 	<li><a href=\"http://toasoandientu.vn\" target=\"_blank\">NukeViet Tòa Soạn Điện Tử</a>: Sử dụng cho các tòa soạn báo điện tử, trang tin điện tử.</li> </ul> Theo định hướng phát triển của NukeViet, ngoài NukeViet CMS đã được phát hành theo giấy phép tự do nguồn mở trong nhiều năm qua, NukeViet sẽ có thêm 2 nhóm ứng dụng nữa là:  <ul> 	<li>NukeViet Blog: Dành cho các website và người dùng tạo các trang nhật ký cá nhân.</li> 	<li>NukeViet Shop: dành cho các website thương mại điện tử với hoạt động chính là bán hàng trực tuyến, hiện đã có thể sử dụng bằng cách cài bổ sung <a href=\"https://github.com/nukeviet/module-shops\" target=\"_blank\">module Shop</a> lên NukeViet CMS.</li> </ul> &nbsp;  <h2><span style=\"font-size:20px;\"><strong>Video giới thiệu</strong></span></h2> <span style=\"font-size:14px;\">Video clip &quot;Giới thiệu mã nguồn mở NukeViet&quot; trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br  /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</span>  <div style=\"text-align: center;\"> <div style=\"text-align: center;\"> <div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden;\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"480\" src=\"//www.youtube.com/embed/Cxp1kCyVhqY?rel=0&amp;autoplay=1\" style=\"position: absolute;top: 0;left: 0;width: 100%;height: 100%;\" width=\"640\"></iframe></div> <br  /> <span style=\"font-size:12px;\"><em>Video clip &quot;Giới thiệu mã nguồn mở NukeViet&quot;</em></span></div> </div>  <h2><br  /> <span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\".E1.BB.A8ng_d.E1.BB.A5ng\">Lịch sử phát triển</span></strong></span></h2> NukeViet ra đời từ năm 2004, bắt đầu từ việc sử dụng sản phẩm PHP-Nuke để làm cho website cá nhân, anh Nguyễn Anh Tú - một lưu học sinh người Việt tại Nga - đã cùng cộng đồng Việt hóa, cải tiến theo nhu cầu sử dụng của người Việt. Được sự đón nhận của đông đảo người sử dụng, NukeViet đã liên tục được phát triển và trở thành một ứng dụng thuần Việt. Cho đến phiên bản 3.0, NukeViet đã được phát triển thành một ứng dụng khác biệt hoàn toàn, và không chỉ là một CMS, NukeViet được định hướng để trở thành phần mềm đa chức năng trên nền web.<br  /> <br  /> Kể từ năm 2010, NukeViet đã phát triển theo mô hình chuyên nghiệp, đội ngũ quản trị đã thành lập doanh nghiệp chuyên quản và đạt được những tiến bộ vượt bậc. NukeViet đã trở thành hệ quản trị nội dung nguồn mở duy nhất của Việt Nam được Bộ GD&amp;ĐT khuyến khích sử dụng trong giáo dục (thông tư 08/2010/TT-BGDĐT). Tiếp đó, NukeViet CMS đã được trao giải Nhân Tài Đất Việt 2011 và trở thành phần mềm nguồn mở đầu tiên đạt giải thưởng cao quý này. <h2><br  /> <span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\"Di.E1.BB.85n_.C4.91.C3.A0n_NukeViet.vn\">Diễn đàn NukeViet.vn</span></strong></span></h2>  <p>Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn\">http://nukeviet.vn</a>, đây là kênh chính thức và hữu hiệu cho các bạn đam mê về NukeViet có thể chia sẻ các kiến thức về NukeViet với nhau. Tính đến tháng 12 năm 2015 diễn đàn đã có trên 34.500 thành viên tham gia, bao gồm học sinh, sinh viên &amp; nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước.</p>  <p>Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng, văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an..</p>  <h2><br  /> <span style=\"font-size:20px;\"><span class=\"mw-headline\" id=\"Th.C3.A0nh_t.C3.ADch_.26_gi.E1.BA.A3i_th.C6.B0.E1.BB.9Fng\"><strong>Thành tích &amp; giải thưởng</strong></span></span></h2>  <h3><span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\"Khen_th.C6.B0.E1.BB.9Fng_.26_Th.C3.A0nh_t.C3.ADch\">Khen thưởng &amp; Thành tích</span></strong></em></span></h3>  <ul> 	<li>Giải Ba Nhân tài Đất Việt 2011 ở Lĩnh vực Công nghệ thông tin/Sản phẩm đã ứng dụng rộng rãi (không có giải nhất, nhì).</li> 	<li>Bằng khen của Hội Tin học Việt Nam vì những đóng góp xuất sắc cho sự phát triển của cộng đồng nguồn mở tại Việt Nam.</li> </ul> <span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\".C4.90.C6.B0.E1.BB.A3c_B.E1.BB.99_gi.C3.A1o_d.E1.BB.A5c_.26_.C4.90.C3.A0o_t.E1.BA.A1o_.E1.BB.A7ng_h.E1.BB.99\">Được Bộ giáo dục &amp; Đào tạo ủng hộ</span></strong></em></span>  <p>NukeViet CMS là hệ quản trị nội dung nguồn mở duy nhất của Việt Nam nằm trong danh mục các sản phẩm phần mềm nguồn mở được khuyến khích sử dụng trong thông tư số 08/2010/TT-BGDĐT do Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục). Trong bài thuyết trình &quot;Hiện trạng triển khai nội dung thông tư 08/2010/TT-BGDĐT về sử dụng PMNM trong các cơ sở giáo dục và định hướng cho thời gian tới&quot;<sup> </sup>tại Hội thảo phần mềm nguồn mở trong các cơ quan, tổ chức nhà nước năm 2012, Cục trưởng cục CNTT Quách Tuấn Ngọc cho biết: &quot;NukeViet có thể thay thế SharePoint server&quot;, &quot;NukeViet được nhiều cơ sở giáo dục thích dùng&quot;<sup> </sup>NukeViet được Bộ GD&amp;ĐT đưa vào văn bản hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016. Trong văn bản số 4983/BGDĐT-CNTT của Bộ Giáo dục và Đào tạo (Bộ GDĐT) hướng dẫn việc triển khai nhiệm vụ công nghệ thông tin (CNTT) cho năm học 2015 - 2016 có những nội dung như sau liên quan đến NukeViet:</p>  <ul> 	<li>Nhiệm vụ số &quot;5. Công tác bồi dưỡng ứng dụng CNTT cho giáo viên và cán bộ quản lý giáo dục&quot;, mục &quot;5.1 Một số nội dung cần bồi dưỡng&quot; có ghi &quot;Tập huấn sử dụng phần mềm nguồn mở NukeViet.&quot;</li> 	<li>Nhiệm vụ số &quot; 10. Khai thác, sử dụng và dạy học bằng phần mềm nguồn mở&quot; có ghi: &quot;Khai thác và áp dụng phần mềm nguồn mở NukeViet trong giáo dục.&quot;</li> 	<li>Phụ lục văn bản, có trong nội dung &quot;Khuyến cáo khi sử dụng các hệ thống CNTT&quot;, hạng mục số 3 ghi rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.</li> </ul>  <h3><span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\".C4.90.C6.B0.E1.BB.A3c_.C6.B0u_ti.C3.AAn_mua_s.E1.BA.AFm_s.E1.BB.AD_d.E1.BB.A5ng_trong_ch.C3.ADnh_ph.E1.BB.A7\">Được ưu tiên mua sắm sử dụng trong chính phủ</span></strong></em></span></h3>  <p>NukeViet CMS là hệ quản trị nội dung nguồn mở được quy định ưu tiên mua sắm, sử dụng trong các cơ quan, tổ chức nhà nước Việt Nam theo thông tư 20/2014/TT-BTTTT ký ngày 05/12/2014 và có hiệu lực từ ngày 20/1/2015 quy định về các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước</p>  <h2><br  /> <span style=\"font-size:20px;\"><span class=\"mw-headline\" id=\"T.C3.ADnh_n.C4.83ng\"><strong>Tính năng</strong></span></span></h2>  <h3><span style=\"font-size:14px;\"><strong>NukeViet CMS 3.0 bản gốc có các module cơ bản là:</strong></span></h3>  <ul> 	<li>Quản lý Tin tức (<i>News</i>: Tạo bản tin chủ đề đa cấp, phân quyền theo chủ đề, hẹn giờ đăng tin, tạo bản in, bản tải về, thảo luận bản tin),</li> 	<li>Giới thiệu (<i>About</i>),</li> 	<li>Quản lý quảng cáo thương mại (banners),</li> 	<li>Quản lý người dùng (<i>users</i>),</li> 	<li>Liên hệ qua site (<i>Contact</i>),</li> 	<li>Cấp tin RSS (<i>RSS feeds</i>) và thu thập tin RSS (&quot;RSS reader&quot;),</li> 	<li>Bình chọn (thăm dò ý kiến - <i>Voting</i>),</li> 	<li>Thư viện file (<i>Download</i>),</li> 	<li>Thư viện Web (<i>Weblinks</i>),</li> 	<li>Hỏi nhanh đáp gọn(<i>Faq</i>),</li> 	<li>Thống kê truy cập (<i>statistics</i>),</li> 	<li>Tìm kiếm trong site (<i>Search</i>),</li> 	<li>Bán hàng trực tuyến (<i>Shop</i>) (có từ NukeViet 3.1)...</li> </ul>  <h3><span style=\"font-size:14px;\"><strong>Tính năng hệ thống:</strong></span></h3>  <ul> 	<li>Cài đặt, nâng cấp và đóng gói tự động.</li> 	<li>Hỗ trợ đa ngôn ngữ giao diện và đa ngôn ngữ Cơ sở dữ liệu 100%, cho phép người sử dụng tự xây dựng ngôn ngữ mới.</li> 	<li>Thay đổi &amp; tùy biến giao diện nhiều cấp độ, cho phép người sử dụng có thể cài thêm giao diện mới hoặc tùy biến giao diện trên site theo ý thích. Người sử dụng có thể tùy biến bố cục giao diện theo layout, theo block ở các khu vực khác nhau của website.</li> 	<li>Quản lý module với khả năng xử lý đa nhân module (ảo hóa module).</li> 	<li>Cho phép phân nhóm thành viên và phân quyền người quản trị theo nhiều cấp độ khác nhau.</li> 	<li>Hỗ trợ tối ưu hóa cho các công cụ tìm kiếm (SEO): Rewrite, tạo Sitemap, Ping sitemap, chẩn đoán site, phân tích từ khóa, tạo keyword, quản lý máy chủ tìm kiếm (Bot)...</li> 	<li>Quản lý và sao lưu cơ sở dữ liệu.</li> 	<li>Cấu hình tùy biến, tường lửa đa cấp, xử lý tiến trình tự động...</li> 	<li>Hỗ trợ thiết bị di động (mobile), cho phép thay đổi giao diện tương thích (từ phiên bản 3.3)</li> 	<li>...</li> </ul>  <h2><span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\".E1.BB.A8ng_d.E1.BB.A5ng\">Ứng dụng</span></strong></span></h2>  <p>NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... Trước đây, NukeViet chủ yếu được sử dụng làm trang tin tức nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. Kể từ phiên bản NukeViet 3, đội ngũ phát triển NukeViet đã định nghĩa lại NukeViet, theo đó, NukeViet được coi như phần mềm trực tuyến mà chức năng CMS chỉ là một module của NukeViet. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích.<br  /> <br  /> NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: &quot;hệ thống Portal dành cho người Việt&quot;. Kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế.</p>  <ul> 	<li>Các cổng thông tin điện tử</li> 	<li>Các tập đoàn kinh tế</li> 	<li>Giải trí trực tuyến, văn hóa, nghệ thuật.</li> 	<li>Báo điện tử, tạp chí điện tử</li> 	<li>Website của các doanh nghiệp vừa và nhỏ</li> 	<li>Website của các cơ quan, tổ chức chính phủ</li> 	<li>Website giáo dục, trường học</li> 	<li>Website của gia đình, cá nhân, nhóm sở thích...</li> </ul>  <p><br  /> Ngoài các ứng dụng website ở trên, thực tế NukeViet đã được ứng dụng làm rất nhiều phần mềm khác như: Phần mềm quản lý kho hàng, phần mềm bán hàng, phần mềm quản lý quán BI-A trợ giúp bật tắt điện đèn bàn bóng, phần mềm tòa soạn điện tử, phần mềm quản lý hồ sơ, quản lý nhân sự trực tuyến, phần mềm tra cứu điểm thi hỗ trợ SMS...</p>', '', 0, '4', '', 0, 1, 1, 1492855769, 1492918358, 1), 
(3, 'Cơ cấu tổ chức', 'Co-cau-to-chuc', '', '', 0, '', '<p style=\"text-align: justify;\"><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Tên gọi:</strong></span></span><br  /> <strong>NukeViet </strong>phát âm là <strong>&#91;Nu-Ke-Việt</strong>&#93;, đây là cách đọc riêng, không phải là cách phát âm chuẩn của tiếng Anh.<br  /> <br  /> <strong>Ý nghĩa:</strong><br  /> NukeViet là từ ghép từ chữ <strong>Nuke </strong>và <strong>Việt Nam</strong>.<br  /> <br  /> Sở dĩ có tên gọi này là vì phiên bản 1.0 và 2.0 của NukeViet được phát triển từ mã nguồn mở<strong> PHP-Nuke</strong>.</p>  <p style=\"text-align: justify;\">Mặc dù từ phiên bản 3.0, NukeViet được viết mới hoàn toàn và trong quá trình phát triển của mình, nhiều cái tên đã được đưa ra để thay thế nhưng cuối cùng cái tên NukeViet đã được giữ lại để nhớ rằng <strong>NukeViet </strong>được khởi đầu từ <strong>PHP-Nuke</strong> và để cảm ơn <strong>Franscisco Burzi</strong> - Tác giả PHP-Nuke - vì chính ông là nhân tố để có một cộng đồng mã nguồn mở NukeViet với hàng chục ngàn người dùng như hiện nay.</p>  <p style=\"text-align: justify;\"><strong>Nuke</strong> trong tiếng Anh (từ lóng) có nghĩa là &quot;<strong>vũ khí hạt nhân</strong>&quot; (nuclear weapons). Xem: <a href=\"http://vi.wiktionary.org/wiki/nuke\" target=\"_blank\">http://vi.wiktionary.org/wiki/nuke</a></p>  <p style=\"text-align: justify;\">Đội ngũ phát triển cũng hy vọng rằng <strong>NukeViet </strong>sẽ phát triển bùng nổ như đúng tên gọi của nó.</p>  <p style=\"text-align: justify;\"><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Logo NukeViet 3.0:</strong></span></span><br  /> Sau thời gian dài lựa chọn từ hàng chục mẫu thiết kế của thành viên diễn đàn NukeViet.VN và các nhà thiết kế đồ họa chuyên nghiệp... logo chính thức của NukeViet 3.0 đã được Ban Quản Trị chọn lựa đúng trước ngày Offline phát hành bản NukeViet 3.0 một ngày.<br  /> <br  /> Logo NukeViet 3.0 được lấy hình tượng từ Biển, Đêm, và Ánh Trăng trong khung hình giọt nước:</p>  <p style=\"text-align:center\"><img alt=\"w\" height=\"143\" src=\"/egov/uploads/about/w.png\" style=\"width: 288px; height: 143px; border-width: 0px; border-style: solid;\" width=\"288\" /></p>  <p style=\"text-align: justify;\">Dưới nền trắng, cả logo nhìn như cảnh biển đêm huyền ảo, tĩnh mịch với mặt nước biển, bầu trời, thuyền buồm và ánh trăng. Đây là những hình ảnh biểu tượng cho sự thanh bình mà bất cứ ai cũng mong ước được thấy khi ngắm biển về đêm.<br  /> <br  /> Màu xanh thẫm là màu hòa quyện của của mặt biển, bầu trời về đêm, màu này cũng gần với màu xanh tượng trưng cho hòa bình.<br  /> Hai vệt khuyết chính là ánh trăng sáng màu bạc phản chiếu lên giọt nước.<br  /> <br  /> Giọt nước còn là biểu tượng cho sự sống, cho khát khao bất diệt của vạn vật trên trái đất này.<br  /> <br  /> <strong>Thông số chuẩn của màu logo:</strong><br  /> -&nbsp;&nbsp;&nbsp; Màu xanh: C80, M60, Y0, K0<br  /> <br  /> <strong>Tác giả mẫu thiết kế:</strong> Lê Thanh Xuân, chuyên viên thiết kế đồ họa của VINADES.,JSC</p>  <p style=\"text-align: justify;\"><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Slogan NukeViet 3.0:</strong></span></span> “Chia sẻ thành công, kết nối đam mê”, Tiếng Anh: “Sharing success, connect passions”</p>  <p style=\"text-align: justify;\">Slogan này của tác giả HoaiNamDr, đây là slogan đã đoạt giải trong cuộc thi sáng tác slogan trên diễn đàn NukeViet.VN</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms 180x84\" height=\"84\" src=\"/egov/uploads/about/nukevietcms-180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS (180x84px)<br  /> Tải về mẫu kích thước lớn <a href=\"/egov/uploads/about/nukevietcms.png\">logo-nukeviet-cms.png</a> (1500x700px)</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms mu noel 180x84\" height=\"84\" src=\"/egov/uploads/about/nukevietcms_mu_noel_180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS với chiếc mũ ông già Noel (184x84px)<br  /> &nbsp;</p>  <div style=\"text-align:center\"><img alt=\"logo nukeviet3 flag 180x75\" height=\"75\" src=\"/egov/uploads/about/logo-nukeviet3-flag-180x75.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS cắm cờ Việt Nam (180x75px)<br  /> &nbsp;</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms laco 180x57\" height=\"57\" src=\"/egov/uploads/about/nukevietcms_laco_180x57.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS với chiếc ruy băng cờ Việt Nam (180x57px)</p>  <div style=\"text-align:center\"><img alt=\"nukevietvn 180x84\" height=\"84\" src=\"/egov/uploads/about/nukevietvn_180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet.VN (180x84px)<br  /> Tải về mẫu kích thước lớn <a href=\"/egov/uploads/about/nukevietvn.png\">logo-nukeviet-big.png</a> (1500x700px)</p>  <p><br  /> <strong>Tải về file đồ họa gốc:</strong><br  /> - <a href=\"http://nukeviet.vn/vi/download/Tai-lieu/NukeViet-logo/\">NukeViet logo</a> - hình ảnh gốc có độ phân giải cao, bao gồm cả font chữ, có thể sử dụng cho in ấn sticker, in logo lên áo hoặc in Backdrop, Standy khổ lớn.</p>', '', 0, '4', '', 0, 2, 1, 1492855769, 1492918665, 1), 
(4, 'Bản đồ hành chính', 'Ban-do-hanh-chin', '', '', 0, 'Giấy phép công cộng GNU (tiếng Anh: GNU General Public License, viết tắt GNU GPL hay chỉ GPL) là giấy phép phần mềm tự do được sử dụng để phân phối mã nguồn mở NukeViet.', '<p><strong>Bản dịch tiếng Việt của Giấy phép Công cộng GNU</strong></p>  <p>Người dịch&nbsp;<a href=\"mailto:dangtuan@vietkey.net\">Đặng Minh Tuấn &lt;dangtuan@vietkey.net&gt;</a></p>  <p>Đây là bản dịch tiếng Việt không chính thức của Giấy phép Công cộng GNU. Bản dịch này không phải do Tổ chức Phần mềm Tự do ấn hành, và nó không quy định về mặt pháp lý các điều khoản cho các phần mềm sử dụng giấy phép GNU GPL -- chỉ có bản tiếng Anh gốc của GNU GPL mới có tính pháp lý. Tuy nhiên, chúng tôi hy vọng rằng bản dịch này sẽ giúp cho những người nói tiếng Việt hiểu rõ hơn về GNU GPL.</p>  <p>This is an unofficial translation of the GNU General Public License into Vietnamese. It was not published by the Free Software Foundation, and does not legally state the distribution terms for software that uses the GNU GPL--only the original English text of the GNU GPL does that. However, we hope that this translation will help Vietnamese speakers understand the GNU GPL better.</p>  <hr  /> <h3>GIẤY PHÉP CÔNG CỘNG GNU (GPL)</h3> Giấy phép công cộng GNU<br  /> Phiên bản 2, tháng 6/1991<br  /> Copyright (C) 1989, 1991 Free Software Foundation, Inc. &nbsp;<br  /> 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA <p>Mọi người đều được phép sao chép và lưu hành bản sao nguyên bản nhưng không được phép thay đổi nội dung của giấy phép này.<br  /> <br  /> <strong>Lời nói đầu</strong><br  /> <br  /> Giấy phép sử dụng của hầu hết các phần mềm đều được đưa ra nhằm hạn chế bạn tự do chia sẻ và thay đổi nó. Ngược lại, Giấy phép Công cộng của GNU có mục đích đảm bảo cho bạn có thể tự do chia sẻ và thay đổi phần mềm tự do - tức là đảm bảo rằng phần mềm đó là tự do đối với mọi người sử dụng. Giấy phép Công cộng này áp dụng cho hầu hết các phần mềm của Tổ chức Phần mềm Tự do và cho tất cả các chương trình khác mà tác giả cho phép sử dụng. (Đối với một số phần mềm khác của Tổ chức Phần Mềm Tự do, áp dụng Giấy phép Công cộng Hạn chế của GNU thay cho giấy phép công cộng). Bạn cũng có thể áp dụng nó cho các chương trình của mình.<br  /> <br  /> Khi nói đến phần mềm tự do, chúng ta nói đến sự tự do sử dụng chứ không quan tâm về giá cả. Giấy phép Công cộng của chúng tôi được thiết kế để đảm bảo rằng bạn hoàn toàn tự do cung cấp các bản sao của phần mềm tự do (cũng như kinh doanh dịch vụ này nếu bạn muốn), rằng bạn có thể nhận được mã nguồn nếu bạn có yêu cầu, rằng bạn có thể thay đổi phần mềm hoặc sử dụng các thành phần của phần mềm đó cho những chương trình tự do mới; và rằng bạn biết chắc là bạn có thể làm được những điều này.<br  /> <br  /> Để bảo vệ bản quyền của bạn, chúng tôi cần đưa ra những hạn chế để ngăn chặn những ai chối bỏ quyền của bạn, hoặc yêu cầu bạn chối bỏ quyền của mình. Những hạn chế này cũng có nghĩa là những trách nhiệm nhất định của bạn khi cung cấp các bản sao phần mềm hoặc khi chỉnh sửa phần mềm đó.<br  /> <br  /> Ví dụ, nếu bạn cung cấp các bản sao của một chương trình, dù miễn phí hay không, bạn phải cho người nhận tất cả các quyền mà bạn có. Bạn cũng phải đảm bảo rằng họ cũng nhận được hoặc tiếp cận được mã nguồn. Và bạn phải thông báo những điều khoản này cho họ để họ biết rõ về quyền của mình.<br  /> <br  /> Chúng tôi bảo vệ quyền của bạn với hai bước: (1) bảo vệ bản quyền phần mềm, và (2) cung cấp giấy phép này để bạn có thể sao chép, lưu hành và/hoặc chỉnh sửa phần mềm một cách hợp pháp.<br  /> <br  /> Ngoài ra, để bảo vệ các tác giả cũng như để bảo vệ chính mình, chúng tôi muốn chắc chắn rằng tất cả mọi người đều hiểu rõ rằng không hề có bảo hành đối với phần mềm tự do này. Nếu phần mềm được chỉnh sửa thay đổi bởi một người khác và sau đó lưu hành, thì chúng tôi muốn những người sử dụng biết rằng phiên bản họ đang có không phải là bản gốc, do đó tất cả những trục trặc do những người khác gây ra hoàn toàn không ảnh hưởng tới uy tín của tác giả ban đầu.<br  /> <br  /> Cuối cùng, bất kỳ một chương trình tự do nào cũng đều thường xuyên có nguy cơ bị đe doạ về giấy phép bản quyền. Chúng tôi muốn tránh nguy cơ khi những người cung cấp lại một chương trình tự do có thể có được giấy phép bản quyền cho bản thân họ, từ đó trở thành độc quyền đối với chương trình đó. Để ngăn ngừa trường hợp này, chúng tôi đã nêu rõ rằng mỗi giấy phép bản quyền hoặc phải được cấp cho tất cả mọi người sử dụng một cách tự do hoặc hoàn toàn không cấp phép.<br  /> <br  /> Dưới đây là những điều khoản và điều kiện rõ ràng đối với việc sao chép, lưu hành và chỉnh sửa.<br  /> <br  /> <strong>Những điều khoản và điều kiện đối với việc sao chép, lưu hành và chỉnh sửa</strong><br  /> <br  /> <strong>0.</strong>&nbsp;Giấy phép này áp dụng cho bất kỳ một chương trình hay sản phẩm nào mà người giữ bản quyền công bố rằng nó có thể được cung cấp trong khuôn khổ những điều khoản của Giấy phép Công cộng này. Từ “Chương trình” dưới đây có nghĩa là tất cả các chương trình hay sản phẩm như vậy, và “sản phẩm dựa trên Chương trình” có nghĩa là Chương trình hoặc bất kỳ một sản phẩm nào bắt nguồn từ chương trình đó tuân theo luật bản quyền, nghĩa là một sản phẩm dựa trên Chương trình hoặc một phần của nó, đúng nguyên bản hoặc có một số chỉnh sửa và/hoặc được dịch ra một ngôn ngữ khác. (Dưới đây, việc dịch cũng được hiểu trong khái niệm “chỉnh sửa”). Mỗi người được cấp phép được gọi là “bạn”.<br  /> <br  /> Trong Giấy phép này không đề cập tới các hoạt động khác ngoài việc sao chép, lưu hành và chỉnh sửa; chúng nằm ngoài phạm vi của giấy phép này. Hành động chạy chương trình không bị hạn chế, và những kết quả từ việc chạy chương trình chỉ được đề cập tới nếu nội dung của nó tạo thành một sản phẩm dựa trên chương trình (độc lập với việc chạy chương trình). Điều này đúng hay không là phụ thuộc vào Chương trình.<br  /> <br  /> <strong>1.</strong>&nbsp;Bạn có thể sao chép và lưu hành những phiên bản nguyên bản của mã nguồn Chương trình đúng như khi bạn nhận được, qua bất kỳ phương tiện phân phối nào, với điều kiện trên mỗi bản sao bạn đều kèm theo một ghi chú bản quyền rõ ràng và từ chối bảo hành; giữ nguyên tất cả các ghi chú về Giấy phép và về việc không có bất kỳ một sự bảo hành nào; và cùng với Chương trình bạn cung cấp cho người sử dụng một bản sao của Giấy phép này.<br  /> <br  /> Bạn có thể tính phí cho việc chuyển giao bản sao, và tuỳ theo quyết định của mình bạn có thể cung cấp bảo hành để đổi lại với chi phí mà bạn đã tính.<br  /> <br  /> <strong>2.</strong>&nbsp;Bạn có thể chỉnh sửa bản sao của bạn hoặc các bản sao của Chương trình hoặc của bất kỳ phần nào của nó, từ đó hình thành một sản phẩm dựa trên Chương trình, và sao chép cũng như lưu hành sản phẩm đó hoặc những chỉnh sửa đó theo điều khoản trong Mục 1 ở trên, với điều kiện bạn đáp ứng được những điều kiện dưới đây:<br  /> •&nbsp;&nbsp; &nbsp;a) Bạn phải có ghi chú rõ ràng trong những tập tin đã chỉnh sửa là bạn đã chỉnh sửa nó, và ngày tháng của bất kỳ một thay đổi nào.<br  /> •&nbsp;&nbsp; &nbsp;b) Bạn phải cấp phép miễn phí cho tất cả các bên thứ ba đối với các sản phẩm bạn cung cấp hoặc phát hành, bao gồm Chương trình nguyên bản, từng phần của nó hay các sản phẩm dựa trên Chương trình hay dựa trên từng phần của Chương trình, theo những điều khoản của Giấy phép này.<br  /> •&nbsp;&nbsp; &nbsp;c) Nếu chương trình đã chỉnh sửa thường đọc lệnh tương tác trong khi chạy, bạn phải thực hiện sao cho khi bắt đầu chạy để sử dụng tương tác theo cách thông thường nhất phải có một thông báo bao gồm bản quyền và thông báo về việc không có bảo hành (hoặc thông báo bạn là người cung cấp bảo hành), và rằng người sử dụng có thể cung cấp lại Chương trình theo những điều kiện này, và thông báo để người sử dụng có thể xem bản sao của Giấy phép này. (Ngoại lệ: nếu bản thân Chương trình là tương tác nhưng không có một thông báo nào như trên, thì sản phẩm của bạn dựa trên Chương trình đó cũng không bắt buộc phải có thông báo như vậy).<br  /> <br  /> Những yêu cầu trên áp dụng cho toàn bộ các sản phẩm chỉnh sửa. Nếu có những phần của sản phẩm rõ ràng không bắt nguồn từ Chương trình, và có thể được xem là độc lập và riêng biệt, thì Giấy phép này và các điều khoản của nó sẽ không áp dụng cho những phần đó khi bạn cung cấp chúng như những sản phẩm riêng biệt. Nhưng khi bạn cung cấp những phần đó như những phần nhỏ trong cả một sản phẩm dựa trên Chương trình, thì việc cung cấp này phải tuân theo những điều khoản của Giấy phép này, cho phép những người được cấp phép có quyền đối với toàn bộ sản phẩm, cũng như đối với từng phần trong đó, bất kể ai đã viết nó.<br  /> <br  /> Như vậy, điều khoản này không nhằm mục đích xác nhận quyền hoặc tranh giành quyền của bạn đối với những sản phẩm hoàn toàn do bạn viết; mà mục đích của nó là nhằm thi hành quyền kiểm soát đối với việc cung cấp những sản phẩm bắt nguồn hoặc tổng hợp dựa trên Chương trình.<br  /> <br  /> Ngoài ra, việc kết hợp thuần tuý Chương trình (hoặc một sản phẩm dựa trên Chương trình) với một sản phẩm không dựa trên Chương trình với mục đích lưu trữ hoặc quảng bá không đưa sản phẩm đó vào trong phạm vi áp dụng của Giấy phép này.<br  /> <br  /> <strong>3.</strong>&nbsp;Bạn có thể sao chép và cung cấp Chương trình (hoặc một sản phẩm dựa trên Chương trình, nêu trong Mục 2) dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được trong khuôn khổ các điều khoản nêu trong Mục 1 và 2 ở trên, nếu như bạn:<br  /> •&nbsp;&nbsp; &nbsp;a) Kèm theo đó một bản mã nguồn dạng đầy đủ có thể biên dịch được theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc,<br  /> •&nbsp;&nbsp; &nbsp;b) Kèm theo đó một đề nghị có hạn trong ít nhất 3 năm, theo đó cung cấp cho bất kỳ một bên thứ ba nào một bản sao đầy đủ của mã nguồn tương ứng, và phải được cung cấp với giá chi phí không cao hơn giá chi phí vật lý của việc cung cấp theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc<br  /> •&nbsp;&nbsp; &nbsp;c) Kèm theo đó thông tin bạn đã nhận được để đề nghị cung cấp mã nguồn tương ứng. (Phương án này chỉ được phép đối với việc cung cấp phi thương mại và chỉ với điều kiện nếu bạn nhận được Chương trình dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được cùng với lời đề nghị như vậy, theo phần b trong điều khoản nêu trên).<br  /> <br  /> Mã nguồn của một sản phẩm là một dạng ưu tiên của sản phẩm dành cho việc chỉnh sửa nó. Với một sản phẩm có thể thi hành, mã nguồn hoàn chỉnh có nghĩa là tất cả các mã nguồn cho các môđun trong sản phẩm đó, cộng với tất cả các tệp tin định nghĩa giao diện đi kèm với nó, cộng với các hướng dẫn dùng để kiểm soát việc biên dịch và cài đặt các tệp thi hành. Tuy nhiên, một ngoại lệ đặc biệt là mã nguồn không cần chứa bất kỳ một thứ gì mà bình thường được cung cấp (từ nguồn khác hoặc hình thức nhị phân) cùng với những thành phần chính (chương trình biên dịch, nhân, và những phần tương tự) của hệ điều hành mà các chương trình chạy trong đó, trừ khi bản thân thành phần đó lại đi kèm với một tệp thi hành.<br  /> <br  /> Nếu việc cung cấp lưu hành mã đã biên dịch hoặc tập tin thi hành được thực hiện qua việc cho phép tiếp cận và sao chép từ một địa điểm được chỉ định, thì việc cho phép tiếp cận tương đương tới việc sao chép mã nguồn từ cùng địa điểm cũng được tính như việc cung cấp mã nguồn, mặc dù thậm chí các bên thứ ba không bị buộc phải sao chép mã nguồn cùng với mã đã biên dịch.<br  /> <br  /> <strong>4.</strong>&nbsp;Bạn không được phép sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình trừ phi phải tuân thủ một cách chính xác các điều khoản trong Giấy phép. Bất kỳ ý định sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình theo cách khác đều làm mất hiệu lực và tự động huỷ bỏ quyền của bạn trong khuôn khổ Giấy phép này. Tuy nhiên, các bên đã nhận được bản sao hoặc quyền từ bạn với Giấy phép này sẽ không bị huỷ bỏ giấy phép nếu các bên đó vẫn tuân thủ đầy đủ các điều khoản của giấy phép.<br  /> <br  /> <strong>5.</strong>&nbsp;Bạn không bắt buộc phải chấp nhận Giấy phép này khi bạn chưa ký vào đó. Tuy nhiên, không có gì khác đảm bảo cho bạn được phép chỉnh sửa hoặc cung cấp Chương trình hoặc các sản phẩm bắt nguồn từ Chương trình. Những hành động này bị luật pháp nghiêm cấm nếu bạn không chấp nhận Giấy phép này. Do vậy, bằng việc chỉnh sửa hoặc cung cấp Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), bạn đã thể hiện sự chấp thuận đối với Giấy phép này, cùng với tất cả các điều khoản và điều kiện đối với việc sao chép, cung cấp hoặc chỉnh sửa Chương trình hoặc các sản phẩm dựa trên nó.<br  /> <br  /> <strong>6.</strong> Mỗi khi bạn cung cấp lại Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), người nhận sẽ tự động nhận được giấy phép từ người cấp phép đầu tiên cho phép sao chép, cung cấp và chỉnh sửa Chương trình theo các điều khoản và điều kiện này. Bạn không thể áp đặt bất cứ hạn chế nào khác đối với việc thực hiện quyền của người nhận đã được cấp phép từ thời điểm đó. Bạn cũng không phải chịu trách nhiệm bắt buộc các bên thứ ba tuân thủ theo Giấy phép này.<br  /> <br  /> <strong>7.</strong>&nbsp;Nếu như, theo quyết định của toà án hoặc với những bằng chứng về việc vi phạm bản quyền hoặc vì bất kỳ lý do nào khác (không giới hạn trong các vấn đề về bản quyền), mà bạn phải tuân theo các điều kiện (nêu ra trong lệnh của toà án, biên bản thoả thuận hoặc ở nơi khác) trái với các điều kiện của Giấy phép này, thì chúng cũng không thể miễn cho bạn khỏi những điều kiện của Giấy phép này. Nếu bạn không thể đồng thời thực hiện các nghĩa vụ của mình trong khuôn khổ Giấy phép này và các nghĩa vụ thích đáng khác, thì hậu quả là bạn hoàn toàn không được cung cấp Chương trình. Ví dụ, nếu trong giấy phép bản quyền không cho phép những người nhận được bản sao trực tiếp hoặc gián tiếp qua bạn có thể cung cấp lại Chương trình thì trong trường hợp này cách duy nhất bạn có thể thoả mãn cả hai điều kiện là hoàn toàn không cung cấp Chương trình.<br  /> <br  /> Nếu bất kỳ một phần nào trong điều khoản này không có hiệu lực hoặc không thể thi hành trong một hoàn cảnh cụ thể, thì sẽ cân đối áp dụng các điều khoản, và toàn bộ điều khoản sẽ được áp dụng trong những hoàn cảnh khác.<br  /> <br  /> Mục đích của điều khoản này không nhằm buộc bạn phải vi phạm bất kỳ một bản quyền nào hoặc các quyền sở hữu khác hoặc tranh luận về giá trị hiệu lực của bất kỳ quyền hạn nào như vậy; mục đích duy nhất của điều khoản này là nhằm bảo vệ sự toàn vẹn của hệ thống cung cấp phần mềm tự do đang được thực hiện với giấy phép công cộng. Nhiều người đã đóng góp rất nhiều vào sự đa dạng của các phần mềm tự do được cung cấp thông qua hệ thống này với sự tin tưởng rằng hệ thống được sử dụng một cách thống nhất; tác giả/người cung cấp có quyền quyết định rằng họ có mong muốn cung cấp phần mềm thông qua hệ thống nào khác hay không, và người được cấp phép không thể có ảnh hưởng tới sự lựa chọn này.<br  /> <br  /> Điều khoản này nhằm làm rõ những hệ quả của các phần còn lại của Giấy phép này.<br  /> <br  /> <strong>8.</strong>&nbsp;Nếu việc cung cấp và/hoặc sử dụng Chương trình bị cấm ở một số nước nhất định bởi quy định về bản quyền, người giữ bản quyền gốc đã đưa Chương trình vào dưới Giấy phép này có thể bổ sung một điều khoản hạn chế việc cung cấp ở những nước đó, nghĩa là việc cung cấp chỉ được phép ở các nước không bị liệt kê trong danh sách hạn chế. Trong trường hợp này, Giấy phép đưa vào những hạn chế được ghi trong nội dung của nó.<br  /> <br  /> <strong>9.&nbsp;</strong>Tổ chức Phần mềm Tự do có thể theo thời gian công bố những phiên bản chỉnh sửa và/hoặc phiên bản mới của Giấy phép Công cộng. Những phiên bản đó sẽ đồng nhất với tinh thần của phiên bản hiện này, nhưng có thể khác ở một số chi tiết nhằm giải quyết những vấn đề hay những lo ngại mới.<br  /> <br  /> Mỗi phiên bản sẽ có một mã số phiên bản riêng. Nếu Chương trình và &quot;bất kỳ một phiên bản nào sau đó&quot; có áp dụng một phiên bản Giấy phép cụ thể, bạn có quyền lựa chọn tuân theo những điều khoản và điều kiện của phiên bản giấy phép đó hoặc của bất kỳ một phiên bản nào sau đó do Tổ chức Phần mềm Tự do công bố. Nếu Chương trình không nêu cụ thể mã số phiên bản giấy phép, bạn có thể lựa chọn bất kỳ một phiên bản nào đã từng được công bố bởi Tổ chức Phần mềm Tự do.<br  /> <br  /> <strong>10.</strong>&nbsp;Nếu bạn muốn kết hợp các phần của Chương trình vào các chương trình tự do khác mà điều kiện cung cấp khác với chương trình này, hãy viết cho tác giả để được phép. Đối với các phần mềm được cấp bản quyền bởi Tổ chức Phầm mềm Tự do, hãy đề xuất với tổ chức này; đôi khi chúng tôi cũng có những ngoại lệ. Quyết định của chúng tôi sẽ dựa trên hai mục tiêu là bảo hộ tình trạng tự do của tất cả các sản phẩm bắt nguồn từ phần mềm tự do của chúng tôi, và thúc đẩy việc chia sẻ và tái sử dụng phần mềm nói chung.<br  /> <br  /> <strong>KHÔNG BẢO HÀNH</strong><br  /> DO CHƯƠNG TRÌNH ĐƯỢC CẤP PHÉP MIỄN PHÍ NÊN KHÔNG CÓ MỘT CHẾ ĐỘ BẢO HÀNH NÀO TRONG MỨC ĐỘ CHO PHÉP CỦA LUẬT PHÁP. TRỪ KHI ĐƯỢC CÔNG BỐ KHÁC ĐI BẰNG VĂN BẢN, NHỮNG NGƯỜI GIỮ BẢN QUYỀN VÀ/HOẶC CÁC BÊN CUNG CẤP CHƯƠNG TRÌNH NGUYÊN BẢN SẼ KHÔNG BẢO HÀNH DƯỚI BẤT KỲ HÌNH THỨC NÀO, BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG CÁC HÌNH THỨC BẢO HÀNH ĐỐI VỚI TÍNH THƯƠNG MẠI CŨNG NHƯ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. BẠN LÀ NGƯỜI CHỊU TOÀN BỘ RỦI RO VỀ CHẤT LƯỢNG CŨNG NHƯ VIỆC VẬN HÀNH CHƯƠNG TRÌNH. TRONG TRƯỜNG HỢP CHƯƠNG TRÌNH CÓ KHIẾM KHUYẾT, BẠN PHẢI CHỊU TOÀN BỘ CHI PHÍ CHO NHỮNG DỊCH VỤ SỬA CHỮA CẦN THIẾT.<br  /> <br  /> TRONG TẤT CẢ CÁC TRƯỜNG HỢP TRỪ KHI CÓ YÊU CẦU CỦA LUẬT PHÁP HOẶC CÓ THOẢ THUẬN BẰNG VĂN BẢN, NHỮNG NGƯỜI CÓ BẢN QUYỀN HOẶC BẤT KỲ MỘT BÊN NÀO CHỈNH SỬA VÀ/HOẶC CUNG CẤP LẠI CHƯƠNG TRÌNH TRONG CÁC ĐIỀU KIỆN NHƯ ĐÃ NÊU TRÊN ĐỀU KHÔNG CÓ TRÁCH NHIỆM VỚI BẠN VỀ CÁC LỖI HỎNG HÓC, BAO GỒM CÁC LỖI CHUNG HAY ĐẶC BIỆT, NGẪU NHIÊN HAY TẤT YẾU NẢY SINH DO VIỆC SỬ DỤNG HOẶC KHÔNG SỬ DỤNG ĐƯỢC CHƯƠNG TRÌNH (BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG VIỆC MẤT DỮ LIỆU, DỮ LIỆU THIẾU CHÍNH XÁC HOẶC CHƯƠNG TRÌNH KHÔNG VẬN HÀNH ĐƯỢC VỚI CÁC CHƯƠNG TRÌNH KHÁC), THẬM CHÍ CẢ KHI NGƯỜI CÓ BẢN QUYỀN VÀ CÁC BÊN KHÁC ĐÃ ĐƯỢC THÔNG BÁO VỀ KHẢ NĂNG XẢY RA NHỮNG THIỆT HẠI ĐÓ.<br  /> <br  /> <strong>KẾT THÚC CÁC ĐIỀU KIỆN VÀ ĐIỀU KHOẢN.</strong></p>  <p><strong>Áp dụng những điều khoản trên như thế nào đối với chương trình của bạn</strong><br  /> <br  /> Nếu bạn xây dựng một chương trình mới, và bạn muốn cung cấp một cách tối đa cho công chúng sử dụng, thì biện pháp tốt nhất để đạt được điều này là phát triển chương trình đó thành phần mềm tự do để ai cũng có thể cung cấp lại và thay đổi theo những điều khoản như trên.<br  /> <br  /> Để làm được việc này, hãy đính kèm những thông báo như sau cùng với chương trình của mình. An toàn nhất là đính kèm chúng trong phần đầu của tập tin mã nguồn để thông báo một cách hiệu quả nhất về việc không có bảo hành; và mỗi tệp tin đều phải có ít nhất một dòng về “bản quyền” và trỏ đến toàn bộ thông báo.</p>  <blockquote> <p>&nbsp; &nbsp; &nbsp; &nbsp; <strong>Một dòng đề tên chương trình và nội dung của nó.<br  /> &nbsp; &nbsp; &nbsp; &nbsp; Bản quyền (C) năm,&nbsp; tên tác giả.</strong><br  /> <br  /> Chương trình này là phần mềm tự do, bạn có thể cung cấp lại và/hoặc chỉnh sửa nó theo những điều khoản của Giấy phép Công cộng của GNU do Tổ chức Phần mềm Tự do công bố; phiên bản 2 của Giấy phép, hoặc bất kỳ một phiên bản sau đó (tuỳ sự lựa chọn của bạn).<br  /> <br  /> Chương trình này được cung cấp với hy vọng nó sẽ hữu ích, tuy nhiên KHÔNG CÓ BẤT KỲ MỘT BẢO HÀNH NÀO; thậm chí kể cả bảo hành về KHẢ NĂNG THƯƠNG MẠI hoặc TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. Xin xem Giấy phép Công cộng của GNU để biết thêm chi tiết.<br  /> <br  /> Bạn phải nhận được một bản sao của Giấy phép Công cộng của GNU kèm theo chương trình này; nếu bạn chưa nhận được, xin gửi thư về Tổ chức Phần mềm Tự do, 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA.<br  /> <br  /> Xin hãy bổ sung thông tin về địa chỉ liên lạc của bạn (thư điện tử và bưu điện).</p> </blockquote>  <p>Nếu chương trình chạy tương tác, hãy đưa một thông báo ngắn khi bắt đầu chạy chương trình như sau:</p>  <blockquote> <p>Gnomovision phiên bản 69, Copyright (C) năm, tên tác giả.<br  /> <br  /> Gnomovision HOÀN TOÀN KHÔNG CÓ BẢO HÀNH; để xem chi tiết hãy gõ `show w&#039;.&nbsp; Đây là một phần mềm miễn phí, bạn có thể cung cấp lại với những điều kiện nhất định, gõ ‘show c’ để xem chi tiết.<br  /> Giả thiết lệnh `show w&#039; và `show c&#039; cho xem những phần tương ứng trong Giấy phép Công cộng. Tất nhiên những lệnh mà bạn dùng có thể khác với ‘show w&#039; và `show c&#039;; những lệnh này có thể là nhấn chuột hoặc lệnh trong thanh công cụ - tuỳ theo chương trình của bạn.</p> </blockquote>  <p>Bạn cũng cần phải lấy chữ ký của người phụ trách (nếu bạn là người lập trình) hoặc của trường học (nếu có) xác nhận từ chối bản quyền đối với chương trình. Sau đây là ví dụ:</p>  <blockquote> <p>Yoyodyne, Inc., tại đây từ chối tất cả các quyền lợi bản quyền đối với chương trình `Gnomovision&#039; viết bởi James Hacker.<br  /> <br  /> chữ ký của Ty Coon, 1 April 1989<br  /> Ty Coon, Phó Tổng Giám đốc.</p> </blockquote>  <p>Giấy phép Công cộng này không cho phép đưa chương trình của bạn vào trong các chương trình độc quyền. Nếu chương trình của bạn là một thư viện thủ tục phụ, bạn có thể thấy nó hữu ích hơn nếu cho thư viện liên kết với các ứng dụng độc quyền. Nếu đây là việc bạn muốn làm, hãy sử dụng Giấy phép Công cộng Hạn chế của GNU thay cho Giấy phép này.</p>  <hr  /> <p><strong>Bản gốc của giấy phép bằng tiếng Anh có tại các địa chỉ sau:</strong></p>  <ol> 	<li>GNU General Public License, version 1, February 1989:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt</a></li> 	<li>GNU General Public License, version 2, June 1991:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-2.0.html\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-2.0.html</a></li> 	<li>GNU General Public License, version 3, 29 June 2007:&nbsp;<a href=\"http://www.gnu.org/licenses/gpl-3.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/gpl-3.0.txt</a></li> </ol>  <p><strong>Tài liệu tham khảo:</strong></p>  <ol> 	<li>Bản dịch tiếng Việt của Giấy phép Công cộng GNU tại OpenOffice.org:&nbsp;<br  /> 	<a href=\"http://vi.openoffice.org/gplv.html\" target=\"_blank\">http://vi.openoffice.org/gplv.html</a></li> 	<li>GPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/GPL\" target=\"_blank\">http://vi.wikisource.org/wiki/GPL</a></li> </ol>  <p><strong>Xem thêm:</strong></p>  <ol> 	<li>LGPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/LGPL\" target=\"_blank\">http://vi.wikisource.org/wiki/LGPL</a></li> 	<li>Giấy phép Công cộng GNU - WikiPedia:&nbsp;<br  /> 	<a href=\"http://vi.wikipedia.org/wiki/Gi%E1%BA%A5y_ph%C3%A9p_C%C3%B4ng_c%E1%BB%99ng_GNU\" target=\"_blank\">http://vi.wikipedia.org/wiki/Giấy_phép_Công_cộng_GNU</a></li> 	<li>Thảo luận giấy phép GNU GPL - HVA:<br  /> 	&nbsp;<a href=\"http://www.hvaonline.net/hvaonline/posts/list/7120.hva\" target=\"_blank\">http://www.hvaonline.net/hvaonline/posts/list/7120.hva</a></li> 	<li>Thảo luận tại diễn đàn:&nbsp;<a href=\"http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591\" target=\"_blank\">http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591</a></li> </ol>', 'giấy phép,công cộng,tiếng anh,gnu general,public license,gnu gpl,phần mềm,là tự,sử dụng,mã nguồn,bản dịch,tiếng việt,của gnu,đây là,này không,do tổ,chức tự,hành và,các điều,cho các,có bản,tuy nhiên,chúng tôi,cho những,phiên bản,mọi người,được phép,sao chép,lưu hành,bản sao,nguyên bản,nhưng không,và thay,nội dung,của này,hạn chế,tự do,chia sẻ,nukeviet,portal,mysql,php,cms,mã nguồn mở,thiết kế website', 0, '4', '', 0, 3, 1, 1492855769, 1492918476, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_about_config`
--

DROP TABLE IF EXISTS `nn1_vi_about_config`;
CREATE TABLE `nn1_vi_about_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_about_config`
--

INSERT INTO `nn1_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nn1_vi_blocks_groups`;
CREATE TABLE `nn1_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10)  COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=37  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_blocks_groups`
--

INSERT INTO `nn1_vi_blocks_groups` VALUES
(1, 'default', 'news', 'module.block_headline.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:3:\"top\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(2, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(5, 'default', 'banners', 'global.banners.php', 'Quảng cáo cột trái', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(6, 'default', 'statistics', 'global.counter.php', 'Thống kê', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 3, ''), 
(7, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'border', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''), 
(10, 'default', 'news', 'global.block_tophits.php', 'Tin xem nhiều', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 2, 'a:6:{s:10:\"number_day\";i:3650;s:6:\"numrow\";i:10;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:7:\"nocatid\";a:2:{i:0;i:10;i:1;i:11;}}'), 
(11, 'default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:3:\"YUE\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:40:\"/egov/index.php?language=vi&nv=siteterms\";}'), 
(12, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '', 1, '6', 1, 2, ''), 
(13, 'default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 1, 'a:3:{s:5:\"level\";s:1:\"M\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(14, 'default', 'statistics', 'global.counter_button.php', 'Online button', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 2, ''), 
(15, 'default', 'users', 'global.user_button.php', 'Đăng nhập thành viên', '', 'no_title', '[PERSONALAREA]', 0, '1', 1, '6', 1, 1, ''), 
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(18, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', 1, '6', 1, 1, ''), 
(19, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '', 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(22, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(23, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(24, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''), 
(25, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''), 
(26, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(27, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(28, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:44:\"/egov/index.php?language=vi&amp;nv=siteterms\";}'), 
(29, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(30, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.984516000000013;s:20:\"company_mapcenterlng\";d:105.795475;s:14:\"company_maplat\";d:20.984515999999999;s:14:\"company_maplng\";d:105.79547500000001;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(32, 'default', 'about', 'global.html.php', 'global html', '', 'no_title', '[FEATURED_PRODUCT]', 0, '1', 1, '6', 0, 1, 'a:1:{s:11:\"htmlcontent\";s:382:\"<div style=\"text-align: center;\">Địa chỉ: Số 124/6/12,&nbsp;Đường Võ Văn Hát, Phường Long Trường, Quận 9, TP.HCM<br  />Giấy phép thành lập cấp ngày 19/05/2016 &nbsp;Điện thoại: 0888 777 713 - 0862 764 888&nbsp;<br  />Giấy phép số 000/GP-STTTT, Sở Thông tin Truyền thông cấp ngày 00/00/2017 Ghi rõ nguồn khi trích dẫn tin</div>\";}'), 
(34, 'default', 'about', 'global.html.php', 'Thông tin website', '', 'no_title', '[COMPANY_INFO]', 0, '1', 1, '6', 0, 1, 'a:1:{s:11:\"htmlcontent\";s:382:\"<div style=\"text-align: center;\">Địa chỉ: Số 124/6/12,&nbsp;Đường Võ Văn Hát, Phường Long Trường, Quận 9, TP.HCM<br  />Giấy phép thành lập cấp ngày 19/05/2016 &nbsp;Điện thoại: 0888 777 713 - 0862 764 888&nbsp;<br  />Giấy phép số 000/GP-STTTT, Sở Thông tin Truyền thông cấp ngày 00/00/2017 Ghi rõ nguồn khi trích dẫn tin</div>\";}'), 
(36, 'default', 'theme', 'global.html_css_javascript.php', 'Danh mục', '', 'border', '[RIGHT]', 0, '1', 1, '6', 0, 4, 'a:5:{s:5:\"jsurl\";s:0:\"\";s:5:\"jscon\";s:0:\"\";s:6:\"cssurl\";s:0:\"\";s:6:\"csscon\";s:0:\"\";s:5:\"htmlc\";s:397:\"<div style=\"text-align:center\"><img alt=\"H4\" height=\"65\" src=\"/egov/uploads/banners/fc04b6668bf4a56dtthc.jpg\" width=\"285\" /></div>
<div style=\"text-align:center\"><img alt=\"H3\" height=\"65\" src=\"/egov/uploads/banners/d9f72d038079069dthudt.jpg\" width=\"285\" /></div>
<div style=\"text-align:center\"><img alt=\"H1\" height=\"65\" src=\"/egov/uploads/banners/2b65bacd1ad861cdvbqppl.jpg\" width=\"285\" /></div>\";}');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nn1_vi_blocks_weight`;
CREATE TABLE `nn1_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_blocks_weight`
--

INSERT INTO `nn1_vi_blocks_weight` VALUES
(18, 1, 1), 
(18, 37, 1), 
(18, 38, 1), 
(18, 39, 1), 
(18, 40, 1), 
(18, 46, 1), 
(18, 47, 1), 
(18, 48, 1), 
(18, 49, 1), 
(18, 56, 1), 
(18, 59, 1), 
(18, 4, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 8, 1), 
(18, 9, 1), 
(18, 10, 1), 
(18, 11, 1), 
(18, 12, 1), 
(18, 50, 1), 
(18, 58, 1), 
(18, 53, 1), 
(18, 54, 1), 
(18, 30, 1), 
(18, 31, 1), 
(18, 32, 1), 
(18, 33, 1), 
(18, 34, 1), 
(18, 35, 1), 
(18, 36, 1), 
(18, 18, 1), 
(18, 19, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 22, 1), 
(18, 23, 1), 
(18, 24, 1), 
(18, 25, 1), 
(18, 26, 1), 
(18, 27, 1), 
(18, 28, 1), 
(18, 57, 1), 
(11, 1, 1), 
(11, 37, 1), 
(11, 38, 1), 
(11, 39, 1), 
(11, 40, 1), 
(11, 46, 1), 
(11, 47, 1), 
(11, 48, 1), 
(11, 49, 1), 
(11, 56, 1), 
(11, 59, 1), 
(11, 4, 1), 
(11, 5, 1), 
(11, 6, 1), 
(11, 7, 1), 
(11, 8, 1), 
(11, 9, 1), 
(11, 10, 1), 
(11, 11, 1), 
(11, 12, 1), 
(11, 50, 1), 
(11, 58, 1), 
(11, 53, 1), 
(11, 54, 1), 
(11, 30, 1), 
(11, 31, 1), 
(11, 32, 1), 
(11, 33, 1), 
(11, 34, 1), 
(11, 35, 1), 
(11, 36, 1), 
(11, 18, 1), 
(11, 19, 1), 
(11, 20, 1), 
(11, 21, 1), 
(11, 22, 1), 
(11, 23, 1), 
(11, 24, 1), 
(11, 25, 1), 
(11, 26, 1), 
(11, 27, 1), 
(11, 28, 1), 
(11, 57, 1), 
(12, 1, 2), 
(12, 37, 2), 
(12, 38, 2), 
(12, 39, 2), 
(12, 40, 2), 
(12, 46, 2), 
(12, 47, 2), 
(12, 48, 2), 
(12, 49, 2), 
(12, 56, 2), 
(12, 59, 2), 
(12, 4, 2), 
(12, 5, 2), 
(12, 6, 2), 
(12, 7, 2), 
(12, 8, 2), 
(12, 9, 2), 
(12, 10, 2), 
(12, 11, 2), 
(12, 12, 2), 
(12, 50, 2), 
(12, 58, 2), 
(12, 53, 2), 
(12, 54, 2), 
(12, 30, 2), 
(12, 31, 2), 
(12, 32, 2), 
(12, 33, 2), 
(12, 34, 2), 
(12, 35, 2), 
(12, 36, 2), 
(12, 18, 2), 
(12, 19, 2), 
(12, 20, 2), 
(12, 21, 2), 
(12, 22, 2), 
(12, 23, 2), 
(12, 24, 2), 
(12, 25, 2), 
(12, 26, 2), 
(12, 27, 2), 
(12, 28, 2), 
(12, 57, 2), 
(3, 4, 1), 
(3, 5, 1), 
(3, 6, 1), 
(3, 7, 1), 
(3, 8, 1), 
(3, 9, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 12, 1), 
(4, 18, 1), 
(4, 19, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 22, 1), 
(4, 23, 1), 
(4, 24, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 27, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 35, 1), 
(4, 36, 1), 
(5, 1, 1), 
(5, 37, 1), 
(5, 38, 1), 
(5, 39, 1), 
(5, 40, 1), 
(5, 46, 1), 
(5, 47, 1), 
(5, 48, 1), 
(5, 49, 1), 
(5, 56, 1), 
(5, 59, 1), 
(5, 4, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 8, 2), 
(5, 9, 2), 
(5, 10, 2), 
(5, 11, 2), 
(5, 12, 2), 
(5, 50, 1), 
(5, 58, 1), 
(5, 53, 1), 
(5, 54, 1), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 35, 2), 
(5, 36, 2), 
(5, 18, 2), 
(5, 19, 2), 
(5, 20, 2), 
(5, 21, 2), 
(5, 22, 2), 
(5, 23, 2), 
(5, 24, 2), 
(5, 25, 2), 
(5, 26, 2), 
(5, 27, 2), 
(5, 28, 1), 
(5, 57, 1), 
(6, 1, 3), 
(6, 37, 3), 
(6, 38, 3), 
(6, 39, 3), 
(6, 40, 3), 
(6, 46, 3), 
(6, 47, 3), 
(6, 48, 3), 
(6, 49, 3), 
(6, 56, 3), 
(6, 59, 3), 
(6, 4, 4), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 8, 3), 
(6, 9, 3), 
(6, 10, 3), 
(6, 11, 3), 
(6, 12, 3), 
(6, 50, 3), 
(6, 58, 3), 
(6, 53, 2), 
(6, 54, 2), 
(6, 30, 3), 
(6, 31, 3), 
(6, 32, 3), 
(6, 33, 3), 
(6, 34, 3), 
(6, 35, 3), 
(6, 36, 3), 
(6, 18, 3), 
(6, 19, 3), 
(6, 20, 3), 
(6, 21, 3), 
(6, 22, 3), 
(6, 23, 3), 
(6, 24, 3), 
(6, 25, 3), 
(6, 26, 3), 
(6, 27, 3), 
(6, 28, 3), 
(6, 57, 3), 
(17, 1, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 40, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 49, 1), 
(17, 56, 1), 
(17, 59, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 50, 1), 
(17, 58, 1), 
(17, 53, 1), 
(17, 54, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 36, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 28, 1), 
(17, 57, 1), 
(15, 1, 1), 
(15, 37, 1), 
(15, 38, 1), 
(15, 39, 1), 
(15, 40, 1), 
(15, 46, 1), 
(15, 47, 1), 
(15, 48, 1), 
(15, 49, 1), 
(15, 56, 1), 
(15, 59, 1), 
(15, 4, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 8, 1), 
(15, 9, 1), 
(15, 10, 1), 
(15, 11, 1), 
(15, 12, 1), 
(15, 50, 1), 
(15, 58, 1), 
(15, 53, 1), 
(15, 54, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 35, 1), 
(15, 36, 1), 
(15, 18, 1), 
(15, 19, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 22, 1), 
(15, 23, 1), 
(15, 24, 1), 
(15, 25, 1), 
(15, 26, 1), 
(15, 27, 1), 
(15, 28, 1), 
(15, 57, 1), 
(13, 1, 1), 
(13, 37, 1), 
(13, 38, 1), 
(13, 39, 1), 
(13, 40, 1), 
(13, 46, 1), 
(13, 47, 1), 
(13, 48, 1), 
(13, 49, 1), 
(13, 56, 1), 
(13, 59, 1), 
(13, 4, 1), 
(13, 5, 1), 
(13, 6, 1), 
(13, 7, 1), 
(13, 8, 1), 
(13, 9, 1), 
(13, 10, 1), 
(13, 11, 1), 
(13, 12, 1), 
(13, 50, 1), 
(13, 58, 1), 
(13, 53, 1), 
(13, 54, 1), 
(13, 30, 1), 
(13, 31, 1), 
(13, 32, 1), 
(13, 33, 1), 
(13, 34, 1), 
(13, 35, 1), 
(13, 36, 1), 
(13, 18, 1), 
(13, 19, 1), 
(13, 20, 1), 
(13, 21, 1), 
(13, 22, 1), 
(13, 23, 1), 
(13, 24, 1), 
(13, 25, 1), 
(13, 26, 1), 
(13, 27, 1), 
(13, 28, 1), 
(13, 57, 1), 
(14, 1, 2), 
(14, 37, 2), 
(14, 38, 2), 
(14, 39, 2), 
(14, 40, 2), 
(14, 46, 2), 
(14, 47, 2), 
(14, 48, 2), 
(14, 49, 2), 
(14, 56, 2), 
(14, 59, 2), 
(14, 4, 2), 
(14, 5, 2), 
(14, 6, 2), 
(14, 7, 2), 
(14, 8, 2), 
(14, 9, 2), 
(14, 10, 2), 
(14, 11, 2), 
(14, 12, 2), 
(14, 50, 2), 
(14, 58, 2), 
(14, 53, 2), 
(14, 54, 2), 
(14, 30, 2), 
(14, 31, 2), 
(14, 32, 2), 
(14, 33, 2), 
(14, 34, 2), 
(14, 35, 2), 
(14, 36, 2), 
(14, 18, 2), 
(14, 19, 2), 
(14, 20, 2), 
(14, 21, 2), 
(14, 22, 2), 
(14, 23, 2), 
(14, 24, 2), 
(14, 25, 2), 
(14, 26, 2), 
(14, 27, 2), 
(14, 28, 2), 
(14, 57, 2), 
(7, 1, 1), 
(7, 37, 1), 
(7, 38, 1), 
(7, 39, 1), 
(7, 40, 1), 
(7, 46, 1), 
(7, 47, 1), 
(7, 48, 1), 
(7, 49, 1), 
(7, 56, 1), 
(7, 59, 1), 
(7, 4, 1), 
(7, 5, 1), 
(7, 6, 1), 
(7, 7, 1), 
(7, 8, 1), 
(7, 9, 1), 
(7, 10, 1), 
(7, 11, 1), 
(7, 12, 1), 
(7, 50, 1), 
(7, 58, 1), 
(7, 30, 1), 
(7, 31, 1), 
(7, 32, 1), 
(7, 33, 1), 
(7, 34, 1), 
(7, 35, 1), 
(7, 36, 1), 
(7, 18, 1), 
(7, 19, 1), 
(7, 20, 1), 
(7, 21, 1), 
(7, 22, 1), 
(7, 23, 1), 
(7, 24, 1), 
(7, 25, 1), 
(7, 26, 1), 
(7, 27, 1), 
(7, 28, 1), 
(7, 57, 1), 
(10, 1, 2), 
(10, 37, 2), 
(10, 38, 2), 
(10, 39, 2), 
(10, 40, 2), 
(10, 46, 2), 
(10, 47, 2), 
(10, 48, 2), 
(10, 49, 2), 
(10, 56, 2), 
(10, 59, 2), 
(10, 4, 2), 
(10, 5, 2), 
(10, 6, 2), 
(10, 7, 2), 
(10, 8, 2), 
(10, 9, 2), 
(10, 10, 2), 
(10, 11, 2), 
(10, 12, 2), 
(10, 50, 2), 
(10, 58, 2), 
(10, 53, 1), 
(10, 54, 1), 
(10, 30, 2), 
(10, 31, 2), 
(10, 32, 2), 
(10, 33, 2), 
(10, 34, 2), 
(10, 35, 2), 
(10, 36, 2), 
(10, 18, 2), 
(10, 19, 2), 
(10, 20, 2), 
(10, 21, 2), 
(10, 22, 2), 
(10, 23, 2), 
(10, 24, 2), 
(10, 25, 2), 
(10, 26, 2), 
(10, 27, 2), 
(10, 28, 2), 
(10, 57, 2), 
(19, 1, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 40, 1), 
(19, 46, 1), 
(19, 47, 1), 
(19, 48, 1), 
(19, 49, 1), 
(19, 56, 1), 
(19, 59, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 50, 1), 
(19, 58, 1), 
(19, 53, 1), 
(19, 54, 1), 
(19, 30, 1), 
(19, 31, 1), 
(19, 32, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 36, 1), 
(19, 18, 1), 
(19, 19, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 28, 1), 
(19, 57, 1), 
(1, 4, 1), 
(2, 4, 2), 
(30, 1, 1), 
(30, 37, 1), 
(30, 38, 1), 
(30, 39, 1), 
(30, 40, 1), 
(30, 46, 1), 
(30, 47, 1), 
(30, 48, 1), 
(30, 49, 1), 
(30, 56, 1), 
(30, 59, 1), 
(30, 4, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 8, 1), 
(30, 9, 1), 
(30, 10, 1), 
(30, 11, 1), 
(30, 12, 1), 
(30, 50, 1), 
(30, 58, 1), 
(30, 53, 1), 
(30, 54, 1), 
(30, 30, 1), 
(30, 31, 1), 
(30, 32, 1), 
(30, 33, 1), 
(30, 34, 1), 
(30, 35, 1), 
(30, 36, 1), 
(30, 18, 1), 
(30, 19, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 22, 1), 
(30, 23, 1), 
(30, 24, 1), 
(30, 25, 1), 
(30, 26, 1), 
(30, 27, 1), 
(30, 28, 1), 
(30, 57, 1), 
(28, 1, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 40, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 49, 1), 
(28, 56, 1), 
(28, 59, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 50, 1), 
(28, 58, 1), 
(28, 53, 1), 
(28, 54, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 36, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 28, 1), 
(28, 57, 1), 
(29, 1, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 40, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 49, 1), 
(29, 56, 1), 
(29, 59, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 50, 1), 
(29, 58, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 28, 1), 
(29, 57, 1), 
(22, 1, 1), 
(22, 37, 1), 
(22, 38, 1), 
(22, 39, 1), 
(22, 40, 1), 
(22, 46, 1), 
(22, 47, 1), 
(22, 48, 1), 
(22, 49, 1), 
(22, 56, 1), 
(22, 59, 1), 
(22, 4, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 8, 1), 
(22, 9, 1), 
(22, 10, 1), 
(22, 11, 1), 
(22, 12, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 53, 1), 
(22, 54, 1), 
(22, 30, 1), 
(22, 31, 1), 
(22, 32, 1), 
(22, 33, 1), 
(22, 34, 1), 
(22, 35, 1), 
(22, 36, 1), 
(22, 18, 1), 
(22, 19, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 22, 1), 
(22, 23, 1), 
(22, 24, 1), 
(22, 25, 1), 
(22, 26, 1), 
(22, 27, 1), 
(22, 28, 1), 
(22, 57, 1), 
(23, 1, 2), 
(23, 37, 2), 
(23, 38, 2), 
(23, 39, 2), 
(23, 40, 2), 
(23, 46, 2), 
(23, 47, 2), 
(23, 48, 2), 
(23, 49, 2), 
(23, 56, 2), 
(23, 59, 2), 
(23, 4, 2), 
(23, 5, 2), 
(23, 6, 2), 
(23, 7, 2), 
(23, 8, 2), 
(23, 9, 2), 
(23, 10, 2), 
(23, 11, 2), 
(23, 12, 2), 
(23, 50, 2), 
(23, 58, 2), 
(23, 53, 2), 
(23, 54, 2), 
(23, 30, 2), 
(23, 31, 2), 
(23, 32, 2), 
(23, 33, 2), 
(23, 34, 2), 
(23, 35, 2), 
(23, 36, 2), 
(23, 18, 2), 
(23, 19, 2), 
(23, 20, 2), 
(23, 21, 2), 
(23, 22, 2), 
(23, 23, 2), 
(23, 24, 2), 
(23, 25, 2), 
(23, 26, 2), 
(23, 27, 2), 
(23, 28, 2), 
(23, 57, 2), 
(24, 1, 1), 
(24, 37, 1), 
(24, 38, 1), 
(24, 39, 1), 
(24, 40, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 48, 1), 
(24, 49, 1), 
(24, 56, 1), 
(24, 59, 1), 
(24, 4, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 8, 1), 
(24, 9, 1), 
(24, 10, 1), 
(24, 11, 1), 
(24, 12, 1), 
(24, 50, 1), 
(24, 58, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 30, 1), 
(24, 31, 1), 
(24, 32, 1), 
(24, 33, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 18, 1), 
(24, 19, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 22, 1), 
(24, 23, 1), 
(24, 24, 1), 
(24, 25, 1), 
(24, 26, 1), 
(24, 27, 1), 
(24, 28, 1), 
(24, 57, 1), 
(25, 1, 2), 
(25, 37, 2), 
(25, 38, 2), 
(25, 39, 2), 
(25, 40, 2), 
(25, 46, 2), 
(25, 47, 2), 
(25, 48, 2), 
(25, 49, 2), 
(25, 56, 2), 
(25, 59, 2), 
(25, 4, 2), 
(25, 5, 2), 
(25, 6, 2), 
(25, 7, 2), 
(25, 8, 2), 
(25, 9, 2), 
(25, 10, 2), 
(25, 11, 2), 
(25, 12, 2), 
(25, 50, 2), 
(25, 58, 2), 
(25, 53, 2), 
(25, 54, 2), 
(25, 30, 2), 
(25, 31, 2), 
(25, 32, 2), 
(25, 33, 2), 
(25, 34, 2), 
(25, 35, 2), 
(25, 36, 2), 
(25, 18, 2), 
(25, 19, 2), 
(25, 20, 2), 
(25, 21, 2), 
(25, 22, 2), 
(25, 23, 2), 
(25, 24, 2), 
(25, 25, 2), 
(25, 26, 2), 
(25, 27, 2), 
(25, 28, 2), 
(25, 57, 2), 
(26, 1, 3), 
(26, 37, 3), 
(26, 38, 3), 
(26, 39, 3), 
(26, 40, 3), 
(26, 46, 3), 
(26, 47, 3), 
(26, 48, 3), 
(26, 49, 3), 
(26, 56, 3), 
(26, 59, 3), 
(26, 4, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 8, 3), 
(26, 9, 3), 
(26, 10, 3), 
(26, 11, 3), 
(26, 12, 3), 
(26, 50, 3), 
(26, 58, 3), 
(26, 53, 3), 
(26, 54, 3), 
(26, 30, 3), 
(26, 31, 3), 
(26, 32, 3), 
(26, 33, 3), 
(26, 34, 3), 
(26, 35, 3), 
(26, 36, 3), 
(26, 18, 3), 
(26, 19, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 22, 3), 
(26, 23, 3), 
(26, 24, 3), 
(26, 25, 3), 
(26, 26, 3), 
(26, 27, 3), 
(26, 28, 3), 
(26, 57, 3), 
(27, 1, 4), 
(27, 37, 4), 
(27, 38, 4), 
(27, 39, 4), 
(27, 40, 4), 
(27, 46, 4), 
(27, 47, 4), 
(27, 48, 4), 
(27, 49, 4), 
(27, 56, 4), 
(27, 59, 4), 
(27, 4, 4), 
(27, 5, 4), 
(27, 6, 4), 
(27, 7, 4), 
(27, 8, 4), 
(27, 9, 4), 
(27, 10, 4), 
(27, 11, 4), 
(27, 12, 4), 
(27, 50, 4), 
(27, 58, 4), 
(27, 53, 4), 
(27, 54, 4), 
(27, 30, 4), 
(27, 31, 4), 
(27, 32, 4), 
(27, 33, 4), 
(27, 34, 4), 
(27, 35, 4), 
(27, 36, 4), 
(27, 18, 4), 
(27, 19, 4), 
(27, 20, 4), 
(27, 21, 4), 
(27, 22, 4), 
(27, 23, 4), 
(27, 24, 4), 
(27, 25, 4), 
(27, 26, 4), 
(27, 27, 4), 
(27, 28, 4), 
(27, 57, 4), 
(32, 1, 1), 
(32, 4, 1), 
(32, 5, 1), 
(32, 6, 1), 
(32, 7, 1), 
(32, 8, 1), 
(32, 9, 1), 
(32, 10, 1), 
(32, 11, 1), 
(32, 12, 1), 
(32, 18, 1), 
(32, 19, 1), 
(32, 20, 1), 
(32, 21, 1), 
(32, 22, 1), 
(32, 23, 1), 
(32, 24, 1), 
(32, 25, 1), 
(32, 26, 1), 
(32, 27, 1), 
(32, 28, 1), 
(32, 56, 1), 
(32, 30, 1), 
(32, 31, 1), 
(32, 32, 1), 
(32, 33, 1), 
(32, 34, 1), 
(32, 35, 1), 
(32, 36, 1), 
(32, 57, 1), 
(32, 37, 1), 
(32, 38, 1), 
(32, 39, 1), 
(32, 40, 1), 
(32, 58, 1), 
(32, 59, 1), 
(32, 50, 1), 
(32, 46, 1), 
(32, 47, 1), 
(32, 48, 1), 
(32, 49, 1), 
(32, 53, 1), 
(32, 54, 1), 
(18, 62, 1), 
(18, 63, 1), 
(18, 60, 1), 
(18, 61, 1), 
(11, 62, 1), 
(11, 63, 1), 
(11, 60, 1), 
(11, 61, 1), 
(12, 62, 2), 
(12, 63, 2), 
(12, 60, 2), 
(12, 61, 2), 
(5, 62, 1), 
(5, 63, 1), 
(5, 60, 1), 
(5, 61, 1), 
(6, 62, 3), 
(6, 63, 3), 
(6, 60, 3), 
(6, 61, 3), 
(17, 62, 1), 
(17, 63, 1), 
(17, 60, 1), 
(17, 61, 1), 
(15, 62, 1), 
(15, 63, 1), 
(15, 60, 1), 
(15, 61, 1), 
(13, 62, 1), 
(13, 63, 1), 
(13, 60, 1), 
(13, 61, 1), 
(14, 62, 2), 
(14, 63, 2), 
(14, 60, 2), 
(14, 61, 2), 
(7, 62, 1), 
(7, 63, 1), 
(7, 60, 1), 
(7, 61, 1), 
(10, 62, 2), 
(10, 63, 2), 
(10, 60, 2), 
(10, 61, 2), 
(19, 62, 1), 
(19, 63, 1), 
(19, 60, 1), 
(19, 61, 1), 
(30, 62, 1), 
(30, 63, 1), 
(30, 60, 1), 
(30, 61, 1), 
(28, 62, 1), 
(28, 63, 1), 
(28, 60, 1), 
(28, 61, 1), 
(29, 62, 1), 
(29, 63, 1), 
(29, 60, 1), 
(29, 61, 1), 
(22, 62, 1), 
(22, 63, 1), 
(22, 60, 1), 
(22, 61, 1), 
(23, 62, 2), 
(23, 63, 2), 
(23, 60, 2), 
(23, 61, 2), 
(24, 62, 1), 
(24, 63, 1), 
(24, 60, 1), 
(24, 61, 1), 
(25, 62, 2), 
(25, 63, 2), 
(25, 60, 2), 
(25, 61, 2), 
(26, 62, 3), 
(26, 63, 3), 
(26, 60, 3), 
(26, 61, 3), 
(27, 62, 4), 
(27, 63, 4), 
(27, 60, 4), 
(27, 61, 4), 
(18, 67, 1), 
(18, 66, 1), 
(18, 69, 1), 
(18, 64, 1), 
(18, 65, 1), 
(18, 72, 1), 
(18, 70, 1), 
(11, 67, 1), 
(11, 66, 1), 
(11, 69, 1), 
(11, 64, 1), 
(11, 65, 1), 
(11, 72, 1), 
(11, 70, 1), 
(12, 67, 2), 
(12, 66, 2), 
(12, 69, 2), 
(12, 64, 2), 
(12, 65, 2), 
(12, 72, 2), 
(12, 70, 2), 
(5, 67, 1), 
(5, 66, 1), 
(5, 69, 1), 
(5, 64, 1), 
(5, 65, 1), 
(5, 72, 1), 
(5, 70, 1), 
(6, 67, 3), 
(6, 66, 3), 
(6, 69, 3), 
(6, 64, 3), 
(6, 65, 3), 
(6, 72, 3), 
(6, 70, 3), 
(17, 67, 1), 
(17, 66, 1), 
(17, 69, 1), 
(17, 64, 1), 
(17, 65, 1), 
(17, 72, 1), 
(17, 70, 1), 
(15, 67, 1), 
(15, 66, 1), 
(15, 69, 1), 
(15, 64, 1), 
(15, 65, 1), 
(15, 72, 1), 
(15, 70, 1), 
(13, 67, 1), 
(13, 66, 1), 
(13, 69, 1), 
(13, 64, 1), 
(13, 65, 1), 
(13, 72, 1), 
(13, 70, 1), 
(14, 67, 2), 
(14, 66, 2), 
(14, 69, 2), 
(14, 64, 2), 
(14, 65, 2), 
(14, 72, 2), 
(14, 70, 2), 
(7, 67, 1), 
(7, 66, 1), 
(7, 69, 1), 
(7, 64, 1), 
(7, 65, 1), 
(7, 72, 1), 
(7, 70, 1), 
(10, 67, 2), 
(10, 66, 2), 
(10, 69, 2), 
(10, 64, 2), 
(10, 65, 2), 
(10, 72, 2), 
(10, 70, 2), 
(19, 67, 1), 
(19, 66, 1), 
(19, 69, 1), 
(19, 64, 1), 
(19, 65, 1), 
(19, 72, 1), 
(19, 70, 1), 
(30, 67, 1), 
(30, 66, 1), 
(30, 69, 1), 
(30, 64, 1), 
(30, 65, 1), 
(30, 72, 1), 
(30, 70, 1), 
(28, 67, 1), 
(28, 66, 1), 
(28, 69, 1), 
(28, 64, 1), 
(28, 65, 1), 
(28, 72, 1), 
(28, 70, 1), 
(29, 67, 1), 
(29, 66, 1), 
(29, 69, 1), 
(29, 64, 1), 
(29, 65, 1), 
(29, 72, 1), 
(29, 70, 1), 
(22, 67, 1), 
(22, 66, 1), 
(22, 69, 1), 
(22, 64, 1), 
(22, 65, 1), 
(22, 72, 1), 
(22, 70, 1), 
(23, 67, 2), 
(23, 66, 2), 
(23, 69, 2), 
(23, 64, 2), 
(23, 65, 2), 
(23, 72, 2), 
(23, 70, 2), 
(24, 67, 1), 
(24, 66, 1), 
(24, 69, 1), 
(24, 64, 1), 
(24, 65, 1), 
(24, 72, 1), 
(24, 70, 1), 
(25, 67, 2), 
(25, 66, 2), 
(25, 69, 2), 
(25, 64, 2), 
(25, 65, 2), 
(25, 72, 2), 
(25, 70, 2), 
(26, 67, 3), 
(26, 66, 3), 
(26, 69, 3), 
(26, 64, 3), 
(26, 65, 3), 
(26, 72, 3), 
(26, 70, 3), 
(27, 67, 4), 
(27, 66, 4), 
(27, 69, 4), 
(27, 64, 4), 
(27, 65, 4), 
(27, 72, 4), 
(27, 70, 4), 
(18, 74, 1), 
(18, 78, 1), 
(18, 73, 1), 
(11, 74, 1), 
(11, 78, 1), 
(11, 73, 1), 
(12, 74, 2), 
(12, 78, 2), 
(12, 73, 2), 
(5, 74, 1), 
(5, 78, 1), 
(5, 73, 1), 
(17, 74, 1), 
(17, 78, 1), 
(17, 73, 1), 
(15, 74, 1), 
(15, 78, 1), 
(15, 73, 1), 
(13, 74, 1), 
(13, 78, 1), 
(13, 73, 1), 
(14, 74, 2), 
(14, 78, 2), 
(14, 73, 2), 
(10, 74, 1), 
(10, 78, 1), 
(10, 73, 1), 
(6, 74, 2), 
(6, 78, 2), 
(6, 73, 2), 
(19, 74, 1), 
(19, 78, 1), 
(19, 73, 1), 
(30, 74, 1), 
(30, 78, 1), 
(30, 73, 1), 
(28, 74, 1), 
(28, 78, 1), 
(28, 73, 1), 
(29, 74, 1), 
(29, 78, 1), 
(29, 73, 1), 
(22, 74, 1), 
(22, 78, 1), 
(22, 73, 1), 
(23, 74, 2), 
(23, 78, 2), 
(23, 73, 2), 
(24, 74, 1), 
(24, 78, 1), 
(24, 73, 1), 
(25, 74, 2), 
(25, 78, 2), 
(25, 73, 2), 
(26, 74, 3), 
(26, 78, 3), 
(26, 73, 3), 
(27, 74, 4), 
(27, 78, 4), 
(27, 73, 4), 
(34, 1, 1), 
(34, 4, 1), 
(34, 5, 1), 
(34, 6, 1), 
(34, 7, 1), 
(34, 8, 1), 
(34, 9, 1), 
(34, 10, 1), 
(34, 11, 1), 
(34, 12, 1), 
(34, 18, 1), 
(34, 19, 1), 
(34, 20, 1), 
(34, 21, 1), 
(34, 22, 1), 
(34, 23, 1), 
(34, 24, 1), 
(34, 25, 1), 
(34, 26, 1), 
(34, 27, 1), 
(34, 28, 1), 
(34, 56, 1), 
(34, 30, 1), 
(34, 31, 1), 
(34, 32, 1), 
(34, 33, 1), 
(34, 34, 1), 
(34, 35, 1), 
(34, 36, 1), 
(34, 57, 1), 
(34, 37, 1), 
(34, 38, 1), 
(34, 39, 1), 
(34, 40, 1), 
(34, 58, 1), 
(34, 59, 1), 
(34, 50, 1), 
(34, 46, 1), 
(34, 47, 1), 
(34, 48, 1), 
(34, 49, 1), 
(34, 53, 1), 
(34, 54, 1), 
(34, 62, 1), 
(34, 63, 1), 
(34, 60, 1), 
(34, 61, 1), 
(34, 67, 1), 
(34, 66, 1), 
(34, 69, 1), 
(34, 64, 1), 
(34, 65, 1), 
(34, 72, 1), 
(34, 70, 1), 
(34, 74, 1), 
(34, 78, 1), 
(34, 73, 1), 
(36, 5, 4), 
(36, 4, 3), 
(36, 1, 4), 
(36, 6, 4), 
(36, 7, 4), 
(36, 8, 4), 
(36, 9, 4), 
(36, 10, 4), 
(36, 11, 4), 
(36, 12, 4), 
(36, 18, 4), 
(36, 19, 4), 
(36, 20, 4), 
(36, 21, 4), 
(36, 22, 4), 
(36, 23, 4), 
(36, 24, 4), 
(36, 25, 4), 
(36, 26, 4), 
(36, 27, 4), 
(36, 28, 4), 
(36, 56, 4), 
(36, 30, 4), 
(36, 31, 4), 
(36, 32, 4), 
(36, 33, 4), 
(36, 34, 4), 
(36, 35, 4), 
(36, 36, 4), 
(36, 57, 4), 
(36, 37, 4), 
(36, 38, 4), 
(36, 39, 4), 
(36, 40, 4), 
(36, 58, 4), 
(36, 59, 4), 
(36, 50, 4), 
(36, 46, 4), 
(36, 47, 4), 
(36, 48, 4), 
(36, 49, 4), 
(36, 62, 4), 
(36, 63, 4), 
(36, 60, 4), 
(36, 61, 4), 
(36, 67, 4), 
(36, 66, 4), 
(36, 69, 4), 
(36, 64, 4), 
(36, 65, 4), 
(36, 72, 4), 
(36, 70, 4);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_comment`
--

DROP TABLE IF EXISTS `nn1_vi_comment`;
CREATE TABLE `nn1_vi_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_contact_department`
--

DROP TABLE IF EXISTS `nn1_vi_contact_department`;
CREATE TABLE `nn1_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_contact_department`
--

INSERT INTO `nn1_vi_contact_department` VALUES
(1, 'Phòng Chăm sóc khách hàng', 'Cham-soc-khach-hang', '', '(08) 38.000.000[+84838000000]', '08 38.000.001', 'customer@mysite.com', '', 'Bộ phận tiếp nhận và giải quyết các yêu cầu, đề nghị, ý kiến liên quan đến hoạt động chính của doanh nghiệp', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Tư vấn|Khiếu nại, phản ánh|Đề nghị hợp tác', '1/1/1/0;', 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_contact_reply`
--

DROP TABLE IF EXISTS `nn1_vi_contact_reply`;
CREATE TABLE `nn1_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text  COLLATE utf8mb4_unicode_ci,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_contact_send`
--

DROP TABLE IF EXISTS `nn1_vi_contact_send`;
CREATE TABLE `nn1_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_freecontent_blocks`
--

DROP TABLE IF EXISTS `nn1_vi_freecontent_blocks`;
CREATE TABLE `nn1_vi_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_freecontent_blocks`
--

INSERT INTO `nn1_vi_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_freecontent_rows`
--

DROP TABLE IF EXISTS `nn1_vi_freecontent_rows`;
CREATE TABLE `nn1_vi_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_freecontent_rows`
--

INSERT INTO `nn1_vi_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'cms.jpg', 1492855769, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'portal.jpg', 1492855769, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'edugate.jpg', 1492855769, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'toa-soan-dien-tu.jpg', 1492855769, 0, 1), 
(5, 1, 'Giải pháp bán hàng trực tuyến', '<ul><li>Tích hợp các tính năng cơ bản bán hàng trực tuyến</li><li>Tích hợp với các cổng thanh toán, ví điện tử trên toàn quốc</li></ul>', 'http://vinades.vn', '_blank', 'shop.jpg', 1492855769, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_area`
--

DROP TABLE IF EXISTS `nn1_vi_laws_area`;
CREATE TABLE `nn1_vi_laws_area` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(249)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(249)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `introduction` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`,`parentid`),
  KEY `weight` (`weight`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_area`
--

INSERT INTO `nn1_vi_laws_area` VALUES
(1, 0, 'Linh-vuc-tu-phap', 'Lĩnh vực tư pháp', '', '', 1492917614, 1), 
(2, 0, 'Linh-vuc-van-hoa', 'Lĩnh vực văn hóa', '', '', 1492917631, 2), 
(3, 0, 'Linh-vuc-xay-dung', 'Lĩnh vực xây dựng', '', '', 1492917651, 3), 
(4, 0, 'Linh-vuc-khieu-nai-to-cao', 'Lĩnh vực khiếu nại tố cáo', '', '', 1492917681, 4), 
(5, 0, 'Linh-vuc-ton-giao', 'Lĩnh vực tôn giáo', '', '', 1492918127, 5);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_cat`
--

DROP TABLE IF EXISTS `nn1_vi_laws_cat`;
CREATE TABLE `nn1_vi_laws_cat` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(249)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(249)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `introduction` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '5',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`,`parentid`),
  KEY `weight` (`weight`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_cat`
--

INSERT INTO `nn1_vi_laws_cat` VALUES
(1, 0, 'Thu-tuc-hanh-chinh', 'Thủ tục hành chính', '', '', 5, 1492917853, 1), 
(2, 0, 'Linh-vuc-tu-phap', 'Lĩnh vực tư pháp', '', '', 5, 1492918134, 2), 
(3, 0, 'Linh-vuc-van-hoa', 'Lĩnh vực văn hóa', '', '', 5, 1492918145, 3), 
(4, 0, 'Linh-vuc-xay-dung', 'Lĩnh vực xây dựng', '', '', 5, 1492918156, 4), 
(5, 0, 'Linh-vuc-khieu-nai-to-cao', 'Lĩnh vực khiếu nại tố cáo', '', '', 5, 1492918171, 5);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_config`
--

DROP TABLE IF EXISTS `nn1_vi_laws_config`;
CREATE TABLE `nn1_vi_laws_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_config`
--

INSERT INTO `nn1_vi_laws_config` VALUES
('nummain', '20'), 
('numsub', '20'), 
('typeview', '0'), 
('down_in_home', '1'), 
('detail_other', 'a:1:{i:0;s:3:\"cat\";}'), 
('detail_hide_empty_field', '1'), 
('detail_show_link_cat', '1'), 
('detail_show_link_area', '1'), 
('detail_show_link_subject', '1'), 
('detail_show_link_signer', '0'), 
('detail_pdf_quick_view', '1'), 
('other_numlinks', '5');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_row`
--

DROP TABLE IF EXISTS `nn1_vi_laws_row`;
CREATE TABLE `nn1_vi_laws_row` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `replacement` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `relatement` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sgid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `introtext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodytext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `groups_download` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `files` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `addtime` int(11) NOT NULL,
  `edittime` int(11) NOT NULL,
  `publtime` int(11) NOT NULL DEFAULT '0',
  `startvalid` int(11) NOT NULL DEFAULT '0',
  `exptime` int(11) NOT NULL DEFAULT '0',
  `view_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `download_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_add` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_edit` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_row`
--

INSERT INTO `nn1_vi_laws_row` VALUES
(1, '', '', 'Nghỉ lễ và treo Quốc kỳ nhân Ngày kỷ niệm giải phóng hoàn toàn miền Nam thống nhất đất nước &#40;30&#x002F;4&#41; và Quốc tế Lao động &#40;01&#x002F;5&#41; năm 2017', 'Nghi-le-va-treo-Quoc-ky-nhan-Ngay-ky-niem-giai-phong-hoan-toan-mien-Nam-thong-nhat-dat-nuoc-30-4-va-Quoc-te-Lao-dong-01-5-nam-2017-1', '65&#x002F;TB-UBND', 3, 1, 2, '', 'Nghỉ lễ và treo Quốc kỳ nhân Ngày kỷ niệm giải phóng hoàn toàn miền Nam thống nhất đất nước &#40;30&#x002F;4&#41; và Quốc tế Lao động &#40;01&#x002F;5&#41; năm 2017', '', 'quốc kỳ,kỷ niệm,giải phóng,hoàn toàn,thống nhất,quốc tế,lao động', '6', '6', '65-tb-ubnd.pdf', 1, 1492920150, 1492920446, 1492534800, 0, 0, 1, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_row_area`
--

DROP TABLE IF EXISTS `nn1_vi_laws_row_area`;
CREATE TABLE `nn1_vi_laws_row_area` (
  `row_id` int(10) unsigned NOT NULL,
  `area_id` smallint(4) unsigned NOT NULL,
  UNIQUE KEY `alias` (`row_id`,`area_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_row_area`
--

INSERT INTO `nn1_vi_laws_row_area` VALUES
(1, 2);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_set_replace`
--

DROP TABLE IF EXISTS `nn1_vi_laws_set_replace`;
CREATE TABLE `nn1_vi_laws_set_replace` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `oid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `nid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_signer`
--

DROP TABLE IF EXISTS `nn1_vi_laws_signer`;
CREATE TABLE `nn1_vi_laws_signer` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `offices` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `positions` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_signer`
--

INSERT INTO `nn1_vi_laws_signer` VALUES
(1, 'Hồ Quốc Dũng', 'UBND tỉnh Bình Định', 'Chủ tịch UBND Tỉnh', 1492917974), 
(2, 'Lê Nhuận', '', '', 1492920305), 
(3, 'Trần Châu', 'UBND tỉnh Bình Định', 'PCT UBND tỉnh', 1492920322), 
(4, 'Nguyễn Tuấn Thanh', 'UBND tỉnh Bình Định', 'PCT UBND tỉnh', 1492920358), 
(5, 'Nguyễn Đức Thi', '', '', 1492920405);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_laws_subject`
--

DROP TABLE IF EXISTS `nn1_vi_laws_subject`;
CREATE TABLE `nn1_vi_laws_subject` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `introduction` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `numcount` int(10) NOT NULL DEFAULT '0',
  `numlink` tinyint(2) NOT NULL DEFAULT '5',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `weight` (`weight`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_laws_subject`
--

INSERT INTO `nn1_vi_laws_subject` VALUES
(1, 'UBND-tinh-Binh-Dinh', 'UBND tỉnh Bình Định', '', '', 1, 5, 1492917895, 1), 
(2, 'UBND-Huyen', 'UBND Huyện', '', '', 0, 5, 1492917907, 2);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_menu`
--

DROP TABLE IF EXISTS `nn1_vi_menu`;
CREATE TABLE `nn1_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_menu`
--

INSERT INTO `nn1_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_menu_rows`
--

DROP TABLE IF EXISTS `nn1_vi_menu_rows`;
CREATE TABLE `nn1_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `op` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=130  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_menu_rows`
--

INSERT INTO `nn1_vi_menu_rows` VALUES
(121, 67, 1, 'Lĩnh vực xây dựng', '/egov/index.php?language=vi&nv=laws&amp;op=Linh-vuc-xay-dung', '', '', 4, 14, 1, '', '6', 'laws', 'Linh-vuc-xay-dung', 1, '', 1, 1), 
(118, 67, 1, 'Thủ tục hành chính', '/egov/index.php?language=vi&nv=laws&amp;op=Thu-tuc-hanh-chinh', '', '', 1, 11, 1, '', '6', 'laws', 'Thu-tuc-hanh-chinh', 1, '', 1, 1), 
(119, 67, 1, 'Lĩnh vực tư pháp', '/egov/index.php?language=vi&nv=laws&amp;op=Linh-vuc-tu-phap', '', '', 2, 12, 1, '', '6', 'laws', 'Linh-vuc-tu-phap', 1, '', 1, 1), 
(120, 67, 1, 'Lĩnh vực văn hóa', '/egov/index.php?language=vi&nv=laws&amp;op=Linh-vuc-van-hoa', '', '', 3, 13, 1, '', '6', 'laws', 'Linh-vuc-van-hoa', 1, '', 1, 1), 
(77, 55, 1, 'Kinh tế', '/egov/index.php?language=vi&nv=news&amp;op=kinh-te', '', '', 3, 8, 1, '', '6', 'news', 'kinh-te', 1, '', 1, 1), 
(122, 67, 1, 'Lĩnh vực khiếu nại tố cáo', '/egov/index.php?language=vi&nv=laws&amp;op=Linh-vuc-khieu-nai-to-cao', '', '', 5, 15, 1, '', '6', 'laws', 'Linh-vuc-khieu-nai-to-cao', 1, '', 1, 1), 
(66, 0, 1, 'Lịch công tác', '/egov/index.php?language=vi&nv=work-schedules', '', '', 5, 17, 0, '', '6', 'work-schedules', '', 1, '', 1, 1), 
(67, 0, 1, 'Văn bản pháp quy', '/egov/index.php?language=vi&nv=laws', '', '', 3, 10, 0, '118,119,120,121,122', '6', 'laws', '', 1, '', 1, 1), 
(61, 0, 1, 'Tìm kiếm', '/egov/index.php?language=vi&nv=seek', '', '', 6, 18, 0, '', '6', 'seek', '', 1, '', 1, 1), 
(78, 55, 1, 'An ninh - Quốc phòng', '/egov/index.php?language=vi&nv=news&amp;op=an-ninh-quoc-phong', '', '', 4, 9, 1, '', '6', 'news', 'an-ninh-quoc-phong', 1, '', 1, 1), 
(75, 55, 1, 'Nông thôn mới', '/egov/index.php?language=vi&nv=news&amp;op=nong-thon-moi', '', '', 1, 6, 1, '', '6', 'news', 'nong-thon-moi', 1, '', 1, 1), 
(76, 55, 1, 'Văn hóa xã hội', '/egov/index.php?language=vi&nv=news&amp;op=van-hoa-xa-hoi', '', '', 2, 7, 1, '', '6', 'news', 'van-hoa-xa-hoi', 1, '', 1, 1), 
(57, 0, 1, 'Liên hệ', '/egov/index.php?language=vi&nv=contact', '', '', 4, 16, 0, '', '6', 'contact', '', 1, '', 1, 1), 
(55, 0, 1, 'Tin Tức', '/egov/index.php?language=vi&nv=news', '', '', 2, 5, 0, '75,76,77,78', '6', 'news', '', 1, '', 1, 1), 
(54, 0, 1, 'Giới thiệu', '/egov/index.php?language=vi&nv=about', '', '', 1, 1, 0, '115,116,117', '6', 'about', '', 1, '', 1, 1), 
(117, 54, 1, 'Bản đồ hành chính', '/egov/index.php?language=vi&nv=about&amp;op=Ban-do-hanh-chin.html', '', '', 3, 4, 1, '', '6', 'about', 'Ban-do-hanh-chin.html', 1, '', 1, 1), 
(116, 54, 1, 'Cơ cấu tổ chức', '/egov/index.php?language=vi&nv=about&amp;op=Co-cau-to-chuc.html', '', '', 2, 3, 1, '', '6', 'about', 'Co-cau-to-chuc.html', 1, '', 1, 1), 
(115, 54, 1, 'Lời chào mừng', '/egov/index.php?language=vi&nv=about&amp;op=Loi-chao-mung.html', '', '', 1, 2, 1, '', '6', 'about', 'Loi-chao-mung.html', 1, '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_modfuncs`
--

DROP TABLE IF EXISTS `nn1_vi_modfuncs`;
CREATE TABLE `nn1_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_custom_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=80  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_modfuncs`
--

INSERT INTO `nn1_vi_modfuncs` VALUES
(1, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', 'about', 0, 0, 0, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Đăng ký', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Khôi phục mật khẩu', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Kích hoạt tài khoản', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Thiếp lập tài khoản', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Thoát', 'users', 1, 1, 10, ''), 
(28, 'groups', 'groups', 'Quản lý nhóm', 'users', 1, 0, 11, ''), 
(29, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(30, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(31, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(32, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(33, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(34, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(35, 'allbots', 'allbots', 'Theo máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(36, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(37, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(38, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(40, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(41, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(42, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(43, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(44, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(45, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(47, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(48, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(49, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(50, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(51, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(52, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''), 
(56, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(59, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(60, 'add', 'add', 'Add', 'work-schedules', 1, 0, 3, ''), 
(61, 'edit', 'edit', 'Edit', 'work-schedules', 1, 0, 4, ''), 
(62, 'main', 'main', 'Main', 'work-schedules', 1, 0, 1, ''), 
(63, 'manager', 'manager', 'Manager', 'work-schedules', 1, 0, 2, ''), 
(64, 'area', 'area', 'Area', 'laws', 1, 1, 4, ''), 
(65, 'cat', 'cat', 'Cat', 'laws', 1, 1, 5, ''), 
(66, 'detail', 'detail', 'Detail', 'laws', 1, 1, 2, ''), 
(67, 'main', 'main', 'Main', 'laws', 1, 1, 1, ''), 
(68, 'rss', 'rss', 'Rss', 'laws', 0, 0, 0, ''), 
(69, 'search', 'search', 'Search', 'laws', 1, 1, 3, ''), 
(70, 'signer', 'signer', 'Signer', 'laws', 1, 1, 7, ''), 
(71, 'sitemap', 'sitemap', 'Sitemap', 'laws', 0, 0, 0, ''), 
(72, 'subject', 'subject', 'Subject', 'laws', 1, 1, 6, '');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_modthemes`
--

DROP TABLE IF EXISTS `nn1_vi_modthemes`;
CREATE TABLE `nn1_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_modthemes`
--

INSERT INTO `nn1_vi_modthemes` VALUES
(0, 'left-main-right', 'default'), 
(0, 'main', 'mobile_default'), 
(1, 'main', 'mobile_default'), 
(1, 'main-right', 'default'), 
(4, 'main', 'mobile_default'), 
(4, 'main-right', 'default'), 
(5, 'main', 'mobile_default'), 
(5, 'main-right', 'default'), 
(6, 'main', 'mobile_default'), 
(6, 'main-right', 'default'), 
(7, 'main', 'mobile_default'), 
(7, 'main-right', 'default'), 
(8, 'main', 'mobile_default'), 
(8, 'main-right', 'default'), 
(9, 'main', 'mobile_default'), 
(9, 'main-right', 'default'), 
(10, 'main-right', 'default'), 
(11, 'main', 'mobile_default'), 
(11, 'main-right', 'default'), 
(12, 'main', 'mobile_default'), 
(12, 'main-right', 'default'), 
(18, 'main', 'mobile_default'), 
(18, 'main-right', 'default'), 
(19, 'main', 'mobile_default'), 
(19, 'main-right', 'default'), 
(20, 'main', 'mobile_default'), 
(20, 'main-right', 'default'), 
(21, 'main', 'mobile_default'), 
(21, 'main-right', 'default'), 
(22, 'main', 'mobile_default'), 
(22, 'main-right', 'default'), 
(23, 'main', 'mobile_default'), 
(23, 'main-right', 'default'), 
(24, 'main', 'mobile_default'), 
(24, 'main-right', 'default'), 
(25, 'main', 'mobile_default'), 
(25, 'main-right', 'default'), 
(26, 'main-right', 'default'), 
(27, 'main', 'mobile_default'), 
(27, 'main-right', 'default'), 
(28, 'main', 'mobile_default'), 
(28, 'main-right', 'default'), 
(30, 'main', 'mobile_default'), 
(30, 'main-right', 'default'), 
(31, 'main', 'mobile_default'), 
(31, 'main-right', 'default'), 
(32, 'main', 'mobile_default'), 
(32, 'main-right', 'default'), 
(33, 'main', 'mobile_default'), 
(33, 'main-right', 'default'), 
(34, 'main', 'mobile_default'), 
(34, 'main-right', 'default'), 
(35, 'main', 'mobile_default'), 
(35, 'main-right', 'default'), 
(36, 'main', 'mobile_default'), 
(36, 'main-right', 'default'), 
(37, 'main', 'mobile_default'), 
(37, 'main-right', 'default'), 
(38, 'main', 'mobile_default'), 
(38, 'main-right', 'default'), 
(39, 'main', 'mobile_default'), 
(39, 'main-right', 'default'), 
(40, 'main', 'mobile_default'), 
(40, 'main-right', 'default'), 
(46, 'main', 'mobile_default'), 
(46, 'main-right', 'default'), 
(47, 'main', 'mobile_default'), 
(47, 'main-right', 'default'), 
(48, 'main', 'mobile_default'), 
(48, 'main-right', 'default'), 
(49, 'main', 'mobile_default'), 
(49, 'main-right', 'default'), 
(50, 'main', 'mobile_default'), 
(50, 'main-right', 'default'), 
(56, 'main', 'mobile_default'), 
(56, 'main-right', 'default'), 
(57, 'main', 'mobile_default'), 
(57, 'main-right', 'default'), 
(58, 'main', 'mobile_default'), 
(58, 'main-right', 'default'), 
(59, 'main', 'mobile_default'), 
(59, 'main-right', 'default'), 
(60, 'main', 'mobile_default'), 
(60, 'main-right', 'default'), 
(61, 'main', 'mobile_default'), 
(61, 'main-right', 'default'), 
(62, 'main', 'mobile_default'), 
(62, 'main-right', 'default'), 
(63, 'main', 'mobile_default'), 
(63, 'main-right', 'default'), 
(64, 'main', 'mobile_default'), 
(64, 'main-right', 'default'), 
(65, 'main', 'mobile_default'), 
(65, 'main-right', 'default'), 
(66, 'main', 'mobile_default'), 
(66, 'main-right', 'default'), 
(67, 'main', 'mobile_default'), 
(67, 'main-right', 'default'), 
(68, 'left-main-right', 'default'), 
(69, 'main', 'mobile_default'), 
(69, 'main-right', 'default'), 
(70, 'main', 'mobile_default'), 
(70, 'main-right', 'default'), 
(71, 'left-main-right', 'default'), 
(72, 'main', 'mobile_default'), 
(72, 'main-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_modules`
--

DROP TABLE IF EXISTS `nn1_vi_modules`;
CREATE TABLE `nn1_vi_modules` (
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_file` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_data` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_upload` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_modules`
--

INSERT INTO `nn1_vi_modules` VALUES
('about', 'page', 'about', 'about', 'Giới thiệu', '', 1492855769, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0), 
('news', 'news', 'news', 'news', 'Tin Tức', '', 1492855769, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 0), 
('users', 'users', 'users', 'users', 'Thành viên', 'Tài khoản', 1492855769, 1, 1, '', '', '', '', '6', 3, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Liên hệ', '', 1492855769, 1, 1, '', '', '', '', '6', 4, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', 1492855769, 1, 1, '', '', '', 'online, statistics', '6', 5, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1492855769, 1, 1, '', '', '', '', '6', 6, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', 1492855769, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', 1492855769, 1, 0, '', '', '', '', '6', 8, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1492855769, 0, 1, '', '', '', '', '6', 9, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'RSS-feeds', 'RSS-feeds', 1492855769, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1492855769, 1, 1, '', '', '', '', '6', 11, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1492855769, 0, 1, '', '', '', '', '6', 12, 0, '', 0, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Giới thiệu sản phẩm', '', 1492855769, 0, 1, '', '', '', '', '6', 13, 1, '', 0, 0), 
('work-schedules', 'work-schedules', 'work_schedules', 'work-schedules', 'Lịch công tác', 'Lịch công tác', 1492916699, 1, 1, '', '', '', '', '6', 14, 1, '', 0, 0), 
('laws', 'laws', 'laws', 'laws', 'Văn bản pháp luật', 'Văn bản pháp luật', 1492917108, 1, 1, '', '', '', '', '6', 15, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_1`
--

DROP TABLE IF EXISTS `nn1_vi_news_1`;
CREATE TABLE `nn1_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_1`
--

INSERT INTO `nn1_vi_news_1` VALUES
(6, 1, '1', 0, 1, 'Nguyễn Thế Hùng', 6, 1453192444, 1492874548, 1, 1453192440, 0, 2, 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', 'hay-tro-thanh-nha-cung-cap-dich-vu-cua-nukeviet', 'Nếu bạn là công ty hosting, là công ty thiết kế web có sử dụng mã nguồn NukeViet, là cơ sở đào tạo NukeViet hay là công ty bất kỳ có kinh doanh dịch vụ liên quan đến NukeViet... hãy cho chúng tôi biết thông tin liên hệ của bạn để NukeViet hỗ trợ bạn trong công việc kinh doanh nhé!', 'hoptac.jpg', '', 1, 1, '6', 1, 16, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 5, 1445309676, 1492874394, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(14, 1, '1,11', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 1, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, NukeViet được đưa vào các hạng mục: Tập huấn sử dụng phần mềm nguồn mở cho giáo viên và cán bộ quản lý giáo dục; Khai thác, sử dụng và dạy học; đặc biệt phần &quot;khuyến cáo khi sử dụng các hệ thống CNTT&quot; có chỉ rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.', 'nukeviet-cms.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_10`
--

DROP TABLE IF EXISTS `nn1_vi_news_10`;
CREATE TABLE `nn1_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=20  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_10`
--

INSERT INTO `nn1_vi_news_10` VALUES
(17, 10, '10', 0, 1, '', 0, 1445391217, 1492874569, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Trên cơ sở Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&ĐT, Sở GD&ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&ĐT', 'tap-huan-pgd-ha-dong-2015.jpg', 'Tập huấn triển khai NukeViet tại Phòng Giáo dục và Đào tạo Hà Đông - Hà Nội', 1, 1, '4', 1, 3, 0, 0, 0), 
(19, 10, '10', 0, 1, '123host', 0, 1453192440, 1453192440, 1, 1453192440, 0, 2, 'Chọn nhà cung cấp Hosting nào tốt cho NukeViet?', 'chon-nha-cung-cap-hosting-nao-tot-cho-nukeviet', 'NukeViet được xây dựng và phát triển để tương thích với nhiều loại hosting và server. Tuy nhiên, để website NukeViet của bạn hoạt động tốt trên môi trường internet, cần chọn một nhà cung cấp Hosting uy tín, tin cậy và để &quot;chọn mặt gởi vàng&quot; website của mình. Bài viết này sẽ trình bày các tiêu chí để lựa chọn một nhà cung cấp Hosting tốt cho website của bạn.', '2016_01/how-to-choose-hosting.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_11`
--

DROP TABLE IF EXISTS `nn1_vi_news_11`;
CREATE TABLE `nn1_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_11`
--

INSERT INTO `nn1_vi_news_11` VALUES
(7, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1453192400, 1453192400, 1, 1453192400, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-PHP', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về PHP và MySQL?. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 1, 0, 0, 0), 
(8, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1445391089, 1445394192, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ phát triển NukeViet', 'Tuyen-dung-chuyen-vien-do-hoa', 'Bạn đam mê nguồn mở? Bạn là chuyên gia đồ họa? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0), 
(9, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1445391090, 1445394193, 1, 1445391060, 0, 2, 'Tuyển dụng lập trình viên front-end (HTML/CSS/JS) phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về front-end (HTML/CSS/JS)?. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0), 
(12, 11, '11', 0, 1, 'Vũ Bích Ngọc', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Công ty cổ phần phát triển nguồn mở Việt Nam là đơn vị chủ quản của phần mềm mã nguồn mở NukeViet - một mã nguồn được tin dùng trong cơ quan nhà nước, đặc biệt là ngành giáo dục. Chúng tôi cần tuyển 05 nhân viên kinh doanh cho lĩnh vực này.', 'tuyen-dung-nvkd.png', '', 1, 1, '4', 1, 0, 0, 0, 0), 
(14, 1, '1,11', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 1, 0, 0, 0), 
(15, 11, '11', 0, 1, 'Trần Thị Thu', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Công ty cổ phần phát triển nguồn mở Việt Nam tạo cơ hội việc làm và học việc miễn phí cho những ứng viên có đam mê thiết kế web, lập trình PHP… được học tập và rèn luyện cùng đội ngũ lập trình viên phát triển NukeViet.', 'hoc-viec-tai-cong-ty-vinades.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_2`
--

DROP TABLE IF EXISTS `nn1_vi_news_2`;
CREATE TABLE `nn1_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=19  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_2`
--

INSERT INTO `nn1_vi_news_2` VALUES
(18, 2, '2', 0, 1, 'VINADES', 0, 1453194455, 1492874433, 1, 1453194420, 0, 2, 'NukeViet 4.0 có gì mới?', 'nukeviet-4-0-co-gi-moi', 'NukeViet 4 là phiên bản NukeViet được cộng đồng đánh giá cao, hứa hẹn nhiều điểm vượt trội về công nghệ đến thời điểm hiện tại. NukeViet 4 thay đổi gần như hoàn toàn từ nhân hệ thống đến chức năng, giao diện người dùng. Vậy, có gì mới trong phiên bản này?', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 4, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_admins`
--

DROP TABLE IF EXISTS `nn1_vi_news_admins`;
CREATE TABLE `nn1_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_block`
--

DROP TABLE IF EXISTS `nn1_vi_news_block`;
CREATE TABLE `nn1_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_block`
--

INSERT INTO `nn1_vi_news_block` VALUES
(1, 18, 3), 
(2, 17, 2), 
(2, 16, 3), 
(2, 15, 4), 
(2, 14, 5), 
(2, 12, 6), 
(2, 11, 7), 
(1, 11, 4), 
(2, 6, 8), 
(2, 18, 1), 
(1, 6, 2), 
(1, 17, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nn1_vi_news_block_cat`;
CREATE TABLE `nn1_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_block_cat`
--

INSERT INTO `nn1_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_cat`
--

DROP TABLE IF EXISTS `nn1_vi_news_cat`;
CREATE TABLE `nn1_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text  COLLATE utf8mb4_unicode_ci,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `ad_block_cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `admins` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_cat`
--

INSERT INTO `nn1_vi_news_cat` VALUES
(1, 0, 'Nông thôn mới', '', 'nong-thon-moi', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, 'Array', '', '', 1274986690, 1492873543, '6'), 
(2, 0, 'Văn hóa xã hội', '', 'van-hoa-xa-hoi', '', '', '', 0, 2, 2, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, 'Array', '', '', 1274986705, 1492873572, '6'), 
(10, 0, 'Kinh tế', '', 'kinh-te', '', '', '', 0, 3, 3, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, 'Array', '', '', 1274987460, 1492873610, '6'), 
(11, 0, 'An ninh - Quốc phòng', '', 'an-ninh-quoc-phong', '', '', '', 0, 4, 4, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, 'Array', '', '', 1274987538, 1492873628, '6');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_config_post`
--

DROP TABLE IF EXISTS `nn1_vi_news_config_post`;
CREATE TABLE `nn1_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_config_post`
--

INSERT INTO `nn1_vi_news_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(7, 0, 0, 0, 0), 
(5, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_detail`
--

DROP TABLE IF EXISTS `nn1_vi_news_detail`;
CREATE TABLE `nn1_vi_news_detail` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_detail`
--

INSERT INTO `nn1_vi_news_detail` VALUES
(6, '<div style=\"text-align: justify;\">Tính đến năm 2015, ước tính có hơn 10.000 website đang sử dụng NukeViet. Nhu cầu triển khai NukeViet không chỉ dừng lại ở các cá nhân, doanh nghiệp, cơ sở giáo dục mà đã lan rộng ra khối chính phủ.</div><div style=\"text-align: justify;\"><br  />Cộng đồng NukeViet cũng đã lớn mạnh hơn trước. Nếu như đầu năm 2010, ngoài Công ty VINADES chỉ có một vài công ty cung cấp dịch vụ cho NukeViet nhưng không chuyên, thì theo thống kê năm 2015 đã có hàng trăm doanh nghiệp đang cung cấp dịch vụ có liên quan đến NukeViet như: đào tạo NukeViet, thiết kế web, phát triển phần mềm, cung cấp giao diện, module... trên nền tảng NukeViet. Đặc biệt có nhiều doanh nghiệp hoàn toàn cung cấp dịch vụ thiết kế web, cung cấp giao diện, module... sử dụng nền tảng NukeViet. Nhiều sản phẩm phái sinh từ NukeViet đã ra đời, NukeViet được phát triển thành nhiều phần mềm quản lý sử dụng trên mạng LAN hay trên internet, được phát triển thành các phần mềm dùng riêng hay sử dụng như một nền tảng để cung cấp dịch vụ online, thậm chí đã được thử nghiệm tích hợp vào trong các thiết bị phần cứng để bán cùng thiết bị (NukeViet Captive Portal - dùng để quản lý người dùng truy cập internet, tích hợp trong thiết bị quản lý wifi)...<br  /><br  />Tuy nhiên, cùng với những cơ hội, cộng đồng NukeViet đang đứng trước một thách thức mới. NukeViet cần tập hợp tất cả các doanh nghiệp, tổ chức và cá nhân đang cung cấp dịch vụ cho NukeViet và liên kết các đơn vị này với nhau để giúp nhau chuyên nghiệp hóa, cùng nhau chia sẻ những cơ hội kinh doanh và trở lên lớn mạnh hơn.<br  /><br  />Nếu cộng đồng NukeViet có 500 công ty siêu nhỏ chỉ 2-3 người và những công ty này đứng riêng rẽ như hiện nay thì NukeViet mãi bé nhỏ và sẽ không làm được việc gì. Nhưng nếu 500 công ty này biết nhau, cùng làm một số việc, cùng tham gia phát triển NukeViet, đó sẽ là sức mạnh rất lớn cho một phần mềm nguồn mở như NukeViet, và đó cũng là cơ hội rất lớn để các công ty nhỏ ấy trở lên chuyên nghiệp và vững mạnh.<br  /><br  />Cho dù bạn là doanh nghiệp hay một nhóm kinh doanh, cho dù bạn đang cung cấp bất kỳ dịch vụ có liên quan trực tiếp đến NukeViet như: đào tạo NukeViet, thiết kế web, phát triển phần mềm, cung cấp giao diện, module... hoặc gián tiếp có liên quan đến NukeViet (ví dụ các công ty hosting, các nhà cung cấp dịch vụ thanh toán điện tử...). Bạn đều là một thành phần quan trọng của NukeViet. Dù bạn là công ty to hay một nhóm nhỏ, hãy đăng ký vào danh sách các đối tác của NukeViet để thiết lập kênh liên lạc với các doanh nghiệp khác trong cộng đồng NukeViet và nhận sự hỗ trợ từ Ban Quản Trị NukeViet cũng như từ các cơ quan nhà nước đang có nhu cầu tìm kiếm các đơn vị cung ứng dịch vụ cho NukeViet.<br  /><br  />Hãy gửi email cho Ban Quản Trị NukeViet về địa chỉ: admin@nukeviet.vn để đăng ký vào danh sách các đơn vị hỗ trợ NukeViet.<br  /><br  />Tiêu đề email: Đăng ký vào danh sách các đơn vị cung cấp dịch vụ dựa trên NukeViet<br  />Nội dung email: Thông tin về đơn vị, dịch vụ cung cấp.<br  /><br  />Hoặc gửi yêu cầu tại đây: <a href=\"http://nukeviet.vn/vi/contact/\" target=\"_blank\">http://nukeviet.vn/vi/contact/</a><br  /><br  />Mọi yêu cầu sẽ được phản hồi trong vòng 24h. Trường hợp không nhận được phản hồi, hãy liên hệ với Ban Quản Trị NukeViet qua các kênh liên lạc khác như:<br  /><br  />- Diễn đàn doanh nghiệp NukeViet: <a href=\"http://forum.nukeviet.vn/viewforum.php?f=4\" target=\"_blank\">http://forum.nukeviet.vn/viewforum.php?f=4</a><br  />- Fanpage NukeViet trên FaceBook: <a href=\"http://fb.com/nukeviet/\" target=\"_blank\">http://fb.com/nukeviet/</a><br  /><br  />Vui lòng truy cập địa chỉ sau để xem danh sách các đơn vị: <a href=\"https://nukeviet.vn/vi/partner/\" target=\"_blank\">https://nukeviet.vn/vi/partner/</a></div>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 2, 0, 1, 1, 1, 0), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Lập trình viên PHP và MySQL<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><ul><li>Phát triển hệ thống NukeViet.</li><li>Phân tích yêu cầu và lập trình riêng cho các dự án cụ thể.</li><li>Thực hiện các công đoạn để dưa website vào hoạt động như upload dữ liệu lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng, trải nghiệm người dùng của sản phẩm trong khi sản phẩm hoạt động.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Nắm vững kiến thức hướng đối tượng, cấu trúc dữ liệu và giải thuật.</li><li>Có kinh nghiệm về PHP và các hệ cơ sở dữ liệu MySQL.…</li><li>Tư duy lập trình tốt, thiết kế CSDL chuẩn, biết xử lý nhanh các vấn đề khi phát sinh nghiệp vụ mới.</li><li>Sửa được các lỗi, nâng cấp tính năng cho các module đã có. 6. Viết module mới.</li><li>Biết đưa website lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo.</li><li>Đam mê công việc về lập trình web.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt.</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng.</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p style=\"text-align: justify;\"><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p style=\"text-align: justify;\"><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-4-85872007 - Fax: +84-4-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', 'http://vinades.vn/vi/news/Tuyen-dung/', 2, 0, 1, 1, 1, 0), 
(8, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Chuyên viên đồ hoạ.<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><br /><br /><em><strong>Công việc chính:</strong></em><ul><li>Thiết kế layout, banner, logo website theo yêu cầu của dự án.</li><li>Đưa ra sản phẩm sáng tạo dựa trên ý tưởng của khách hàng.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><em><strong>Ngoài ra bạn cần có khả năng thực hiện các công việc sau:</strong></em><ul><li>Cắt và ghép giao diện cho hệ thống.</li><li>Valid CSS, xHTML.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Sử dụng thành thạo phần mềm thiết kế: Photoshop ngoài ra cần biết cách sử dụng các phần mềm thiết kế khác là một lợi thế.</li><li>Có kiến thức cơ bản về thiết kế website: Am hiểu các dạng layout, thành phần của một website.</li><li>Có kinh nghiệm, kỹ năng thiết kế giao diện web, logo, banner.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo, tính thẩm mỹ tốt</li><li>Đam mê công việc thiết kế và website.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt</li><li>Am hiểu về Responsive và có thể thiết kế giao diện, layout trên mobile (Boostrap).</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Sử dụng thành thạo HTML5, CSS3 &amp; Javascrip/Jquery và Xtemplate</li><li>Khả năng chuyển PSD sang NukeViet tốt.</li><li>Hiểu rõ và nắm chắc cách làm Theme/Template.</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p style=\"text-align: justify;\"><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p style=\"text-align: justify;\"><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-4-85872007 - Fax: +84-4-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', '', 2, 0, 1, 1, 1, 0), 
(9, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Lập trình viên front-end (HTML/ CSS/ JS)<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><ul><li>Cắt, làm giao diện website từ bản thiết kế (sử dụng Photoshop) trên nền hệ thống NukeViet.</li><li>Tham gia vào việc phát triển Front-End các ứng dụng nền web.</li><li>Thực hiện các công đoạn để dưa website vào hoạt động như upload dữ liệu lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng, trải nghiệm người dùng, thẩm mỹ của sản phẩm trong khi sản phẩm hoạt động Tham mưu, tư vấn về chất lượng, thẩm mỹ, trải nghiệm người dùng về các sản phẩm.</li><li>Đảm bảo website theo các tiêu chuẩn web (W3c, XHTML, CSS 3.0, Tableless, no inline style, … ).</li><li>Đảm bảo website hiển thị đúng trên tất cả các trình duyệt.</li><li>Đảm bảo website theo chuẩn “Responsive Web Design.</li><li>Đảm bảo việc đưa sản phẩm thiết kế đến người dùng cuối cùng một cách chính xác và đẹp.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Có kiến thức cơ bản về thiết kế website: Am hiểu các dạng layout, thành phần của một website.</li><li>Hiểu rõ và nắm chắc cách làm Theme/Template.</li><li>Sử dụng thành thạo HTML5, CSS3 &amp; Javascrip/Jquery và Xtemplate</li><li>Khả năng chuyển PSD sang NukeViet tốt.</li><li>Biết đưa website lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo, tính thẩm mỹ tốt.</li><li>Đam mê công việc về web.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt.</li><li>Am hiểu về Responsive và có thể thiết kế giao diện, layout trên mobile (Boostrap).</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng.</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p style=\"text-align: justify;\"><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p style=\"text-align: justify;\"><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-4-85872007 - Fax: +84-4-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', '', 2, 0, 1, 1, 1, 0), 
(11, '<div style=\"text-align: justify;\">Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.<br  /><br  />Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những&nbsp;sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.</div><p style=\"text-align: justify;\">Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.</p><p style=\"text-align: justify;\">Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.</p><p style=\"text-align: justify;\">Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước.&nbsp;NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có&nbsp;<a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/\" target=\"_blank\">tại đây</a>.</p><p style=\"text-align: justify;\">Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải&nbsp;ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu&nbsp;như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Đồng thời,&nbsp;các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở&nbsp;trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.<br  /><br  />Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (<a href=\"http://vinades.vn/\" target=\"_blank\">VINADES.,JSC</a>) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.</p>', 'mic.gov.vn', 2, 0, 1, 1, 1, 0), 
(12, '<div style=\"text-align: justify;\">Trong năm 2016, chúng tôi xác định là đơn vị sát cánh cùng các đơn vị giáo dục- là đơn vị xây dựng nhiều website cho ngành giáo dục nhất trên cả nước.<br  />Với phần mềm mã nguồn mở NukeViet hiện có nhiều lợi thế:<br  />+ Được Bộ giáo dục khuyến khích sử dụng.<br  />+ Được bộ thông tin truyền thông chỉ định sử dụng trong khối cơ quan nhà nước.<br  />+Được cục công nghệ thông tin ghi rõ tên sản phẩm NukeViet nên dùng theo hướng dẫn thực hiện CNTT 2015-2016.<br  />Chúng tôi cần các bạn góp phần xây dựng nền giáo dục nước nhà ngày càng phát triển.</div><div>&nbsp;</div><table align=\"left\" border=\"1\" cellpadding=\"20\" cellspacing=\"0\" class=\"table table-striped table-bordered table-hover\" style=\"width:100%;\" width=\"653\">	<tbody>		<tr>			<td style=\"width: 27.66%;\"><strong>Vị trí tuyển dụng:</strong></td>			<td style=\"width: 72.34%;\">Nhân viên kinh doanh</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Chức vụ:</strong></td>			<td style=\"width: 72.34%;\">Nhân viên</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Ngành nghề:</strong></td>			<td style=\"width: 72.34%;\"><strong>Sản phẩm:</strong><br  />			Cổng thông tin, website cho các phòng, sở giáo dục và đào tạo các trường học.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hình thức làm việc:</strong></td>			<td style=\"width: 72.34%;\">Toàn thời gian cố định</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Địa điểm làm việc:</strong></td>			<td style=\"width: 72.34%;\">Văn phòng công ty (Được đi công tác theo hợp đồng đã ký)</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Mức lương:</strong></td>			<td style=\"width: 72.34%;\">&nbsp;Lương cố định + Thưởng vượt doanh số + thưởng theo từng hợp đồng (từ 2-7%).</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Mô tả công việc:</strong></td>			<td style=\"width: 72.34%;\">Chúng tôi có khách hàng mục tiêu và danh sách khách hàng, công việc đòi hỏi ứng viên sử dụng thành thạo vi tính văn phòng, các phần mềm liên quan đến công việc và có laptop để phục vụ công việc.<br  />			- Sales Online, quảng bá ký kết, liên kết, với các đối tác qua INTERNET. Xây dưng mối quan hệ phát triển bền vững với các đối tác.<br  />			- Gọi điện, giới thiệu dịch vụ, sản phẩm của công ty đến đối tác.<br  />			- Xử lý các cuộc gọi của khách hàng liên quan đến, sản phẩm, dịch vụ công ty.<br  />			- Đàm phán, thương thuyết, ký kết hợp đồng với khách hàng đang có nhu cầu thiết kế website , SEO website , PR thương hiệu trên Internet&nbsp;<br  />			- Duy trì và chăm sóc mối quan hệ lâu dài với khách hàng, mở rộng khách hàng tiềm năng nhằm thúc đẩy doanh số bán hàng<br  />			- Hỗ trợ khách hàng khi được yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Số lượng cần tuyển:</strong></td>			<td style=\"width: 72.34%;\">05</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Quyền lợi được hưởng:</strong></td>			<td style=\"width: 72.34%;\">- Được đào tạo kĩ năng bán hàng, được công ty hỗ trợ tham gia khóa học bán hàng chuyên nghiệp.<br  />			- Lương cứng: 3.000.000 VNĐ+ hoa hồng dự án (2-7%/năm/hợp đồng). Lương trả qua ATM, được xét tăng lương 3 tháng một lần dựa trên doanh thu.<br  />			- Bậc lương xét trên năng lực bán hàng.<br  />			- Thưởng theo dự án, các ngày lễ tết.<br  />			- Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội.<br  />			- Cơ hội làm việc và gắn bó lâu dài trong công ty, được thưởng cổ phần nếu doanh thu tốt.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Số năm kinh nghiệm:</strong></td>			<td style=\"width: 72.34%;\">Trên 6 tháng</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu bằng cấp:</strong></td>			<td style=\"width: 72.34%;\">Cao đẳng, Đại học</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu giới tính:</strong></td>			<td style=\"width: 72.34%;\">Không yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu độ tuổi:</strong></td>			<td style=\"width: 72.34%;\">Không yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu khác:</strong></td>			<td style=\"width: 72.34%;\">- Yêu thích và đam mê Internet Marketing, thích online, thương mại điện tử<br  />			- Giọng nói dễ nghe, không nói ngọng.<br  />			- Có khả năng giao tiếp qua điện thoại.<br  />			- Ngoại hình ưa nhìn là một lợi thế<br  />			- Có tính cẩn thận trong công việc, luôn cố gắng học hỏi.<br  />			- Kỹ năng sales online tốt.<br  />			-Trung thực, năng động, nhiệt tình,siêng năng, nhiệt huyết trong công việc.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hồ sơ bao gồm:</strong></td>			<td style=\"width: 72.34%;\"><strong>* Yêu cầu Hồ sơ:</strong><br  />			<strong>Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br  />			<br  />			<strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br  />			<strong>+ Đơn xin việc:</strong>&nbsp;Theo hướng dẫn bên dưới.<br  />			<strong>+ Thông tin ứng viên:</strong>&nbsp;Theo mẫu của VINADES.,JSC <strong><em>(download tại đây:&nbsp;<a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-kinh-doanh/\">Mẫu lý lịch ứng viên</a>)</em></strong><br  />			<strong>* Hồ sơ xin việc (Bản in thông thường) bao gồm</strong>:<br  />			- Giấy khám sức khoẻ của cơ quan y tế.<br  />			- Bản sao hộ khẩu (có công chứng)<br  />			- Bản sao giấy khai sinh (có công chứng)<br  />			- Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn -bằng chứng chỉ (có công chứng)<br  />			- Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.<br  />			- Thư giới thiệu (nếu có)<br  />			- Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).<br  />			<br  />			<strong>*Hướng dẫn</strong>:<br  />			- Với bản in của hồ sơ ứng tuyển, ứng viên sẽ phải nộp trước cho Ban tuyển dụng hoặc muộn nhất là mang theo khi có lịch phỏng vấn. Bản in sẽ không được trả lại ngay cả khi ứng viên không đạt yêu cầu.<br  />			- Nếu không thể bố trí thời gian phỏng vấn như sắp xếp của -Ban tuyển dụng, thí sinh cần thông báo ngay để được đổi lịch.<br  />			- Nếu có bất cứ thắc mắc gì bạn có thể liên hệ với Ms. Thu qua email: tuyendung@vinades.vn. Có thể gọi điện theo số điện thoại: 01255723353</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hạn nộp hồ sơ:</strong></td>			<td style=\"width: 72.34%;\">Không hạn chế cho tới khi tuyển đủ.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hình thức nộp hồ sơ:</strong></td>			<td style=\"width: 72.34%;\">Qua Email</td>		</tr>		<tr>			<td colspan=\"2\" style=\"width:100.0%;\">			<h3>THÔNG TIN LIÊN HỆ</h3>			</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Điện thoại liên hệ:</strong></td>			<td style=\"width: 72.34%;\">01255723353- Ms. Thu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Địa chỉ liên hệ:</strong></td>			<td style=\"width: 72.34%;\">Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Email liên hệ:</strong></td><td style=\"width: 72.34%;\">tuyendung@vinades.vn</td></tr></tbody></table>', '', 2, 0, 1, 1, 1, 0), 
(14, '<p style=\"text-align: justify;\">Nếu bạn yêu thích công nghệ, thích kinh doanh hoặc lập trình web và mong muốn trải nghiệm, học hỏi, thậm chí là đi làm ngay từ khi còn ngồi trên ghế nhà trường, hãy tham gia chương trình thực tập sinh tại công ty VINADES.</p><p style=\"text-align: justify;\">Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) là đơn vị chịu trách nhiệm chính trong việc phát triển phần mềm NukeViet và có nhiệm vụ hỗ trợ cộng đồng người dùng NukeViet &#91;<u><a href=\"http://vinades.vn/vi/about/history/\" target=\"_blank\">xem thêm giới thiệu về lịch sử hình thành VINADES</a></u>&#93;. Là công ty được thành lập từ cộng đồng phần mềm nguồn mở, hàng năm công ty dành những vị trí đặc biệt cho các bạn sinh viên được học tập, trải nghiệm, làm việc tại công ty.<br  />&nbsp;</p><h2 style=\"text-align: justify;\"><b>C</b><b>ác vị trí thực tập</b></h2><ul>	<li style=\"text-align: justify;\"><strong>Kinh doanh:</strong> Cổng thông tin doanh nghiệp, Cổng thông tin giáo dục Edu Gate…</li>	<li style=\"text-align: justify;\"><strong>Kỹ thuật:</strong> Chuyên viên đồ họa, Lập trình viên…</li></ul><h2 style=\"text-align: justify;\"><b>Quyền lợi của thực tập sinh</b></h2><ul>	<li style=\"text-align: justify;\">Được&nbsp;tiếp xúc với văn hóa doanh nghiệp, trải nghiệm trong môi trường làm việc chuyên nghiệp, năng động.</li>	<li style=\"text-align: justify;\">Được&nbsp;giao tiếp và học hỏi kiến thức từ những SEO, các lập trình viên chính của đội code NukeViet; qua đó&nbsp;nâng cao không chỉ kỹ năng chuyên môn liên quan đến công việc mà còn các kỹ năng mềm trong quá trình làm việc hàng ngày.</li>	<li style=\"text-align: justify;\">Có cơ hội tìm hiểu, phát triển định hướng của bản thân.</li>	<li style=\"text-align: justify;\">Tham gia các chương trình ngoại khóa, các hoạt động nội bộ của công ty.</li>	<li style=\"text-align: justify;\">Cơ&nbsp;hội được học việc để trở thành nhân viên chính thức nếu có kết quả thực tập tốt.</li>	<li style=\"text-align: justify;\">Thực tập không hưởng lương nhưng có thể được trả thù lao cho một số công việc được giao theo đơn hàng.</li></ul><h2 style=\"text-align: justify;\"><b>Thời gian làm việc</b></h2><ul>	<li style=\"text-align: justify;\">Toàn thời gian cố định hoặc làm online.</li>	<li style=\"text-align: justify;\">Thời gian làm việc là:&nbsp;8:00 – 17:00, Thứ hai – Thứ sáu</li>	<li style=\"text-align: justify;\">Ngày làm việc và thời gian làm việc có thể thay đổi linh hoạt tùy thuộc vào điều kiện của ứng viên và tình hình thực tế.</li></ul><h2 style=\"text-align: justify;\"><b>Đối tượng và điều kiện ứng tuyển</b></h2><p style=\"text-align: justify;\">Tất cả các bạn sinh viên năm cuối/mới tốt nghiệp các trường CĐ - ĐH đáp ứng được những yêu cầu sau:</p><ul>	<li style=\"text-align: justify;\">Sinh viên khối ngành kinh tế: yêu thích marketing online, mong muốn thực tập trong lĩnh vực kinh doanh phần mềm.</li>	<li style=\"text-align: justify;\">Sinh viên khối ngành kỹ thuật: yêu thích thiết kế, lập trình web.</li></ul><p style=\"text-align: justify;\">Có kỹ năng giao tiếp và tư duy logic tốt, năng động và ham học hỏi.</p><p style=\"text-align: justify;\">Có máy tính xách tay để làm việc.</p><p style=\"text-align: justify;\">Ưu tiên các ứng viên đam mê phần mềm nguồn mở, đặc biệt là các ứng viên đã từng tham gia và có bài viết diễn đàn NukeViet (<a href=\"http://forum.nukeviet.vn/\">forum.nukeviet.vn</a>).</p><h2 style=\"text-align: justify;\"><b>Cách thức ứng tuyển</b></h2><p style=\"text-align: justify;\">Gửi bản mềm đơn đăng ký ứng tuyển tới:&nbsp;<a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a>;</p><p style=\"text-align: justify;\">Tiêu đề mail ghi rõ: &#91;Họ tên&#93; –Ứng tuyển thực tập &#91;Bộ phận ứng tuyển&#93;.</p><p style=\"text-align: justify;\">Ví dụ: Lê Văn Nam –&nbsp;Ứng tuyển thực tập sinh bộ phận đồ họa</p><p style=\"text-align: justify;\">Hồ sơ bản cứng cần chuẩn bị (sẽ gửi sau nếu đạt yêu cầu) gồm:</p><ul>	<li style=\"text-align: justify;\">Giấy khám sức khoẻ của cơ quan y tế</li>	<li style=\"text-align: justify;\">Bản sao giấy khai sinh (có công chứng).</li>	<li style=\"text-align: justify;\">Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn bằng chứng chỉ (có công chứng) nếu đã tốt nghiệp.</li>	<li style=\"text-align: justify;\">Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.</li>	<li style=\"text-align: justify;\">Chứng minh thư (photo không cần công chứng).</li>	<li style=\"text-align: justify;\">Thư giới thiệu (nếu có)</li>	<li style=\"text-align: justify;\">Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).</li></ul><p><br  /><strong>Chi tiết vui lòng tham khảo tại:</strong>&nbsp;<a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /><br  />- Tel: +84-4-85872007 - Fax: +84-4-35500914<br  />- Email:&nbsp;<a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a>&nbsp;- Website:&nbsp;<a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></p></blockquote>', '', 2, 0, 1, 1, 1, 0), 
(15, '<p style=\"text-align: justify;\">Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) là đơn vị chịu trách nhiệm chính trong việc phát triển phần mềm NukeViet và có nhiệm vụ hỗ trợ cộng đồng người dùng NukeViet &#91;<u><a href=\"http://vinades.vn/vi/about/history/\" target=\"_blank\">xem thêm giới thiệu về lịch sử hình thành VINADES</a></u>&#93;.</p><p style=\"text-align: justify;\">Nếu bạn yêu thích phần mềm nguồn mở, triết lý của phần mềm tự do nguồn mở hoặc đơn giản là yêu NukeViet, hãy liên hệ ngay để gia nhập công ty VINADES, cùng chúng tôi phát triển NukeViet – Phần mềm nguồn mở Việt Nam – và tạo ra những sản phẩm web tuyệt vời cho cộng đồng.</p><h2 style=\"text-align: justify;\"><b>Các vị trí nhận học việc</b></h2><ul>	<li style=\"text-align: justify;\"><strong>Kinh doanh:</strong> Cổng thông tin doanh nghiệp, Cổng thông tin giáo dục Edu Gate…</li>	<li style=\"text-align: justify;\"><strong>Kỹ thuật:</strong> Chuyên viên đồ họa, Lập trình viên…</li></ul><h2 style=\"text-align: justify;\"><b>Quyền lợi của học viên</b></h2><ul>	<li style=\"text-align: justify;\">Được hưởng trợ cấp ăn trưa.</li>	<li style=\"text-align: justify;\">Được trợ cấp vé gửi xe.</li>	<li style=\"text-align: justify;\">Được hưởng lương khoán theo từng dự án (nếu có).</li>	<li style=\"text-align: justify;\">Được hỗ trợ học phí tham gia các khóa học nâng cao các kỹ năng (nếu có).</li>	<li style=\"text-align: justify;\">Được&nbsp;tiếp xúc với văn hóa doanh nghiệp, trải nghiệm trong môi trường làm việc chuyên nghiệp, năng động.</li>	<li style=\"text-align: justify;\">Được&nbsp;giao tiếp và học hỏi kiến thức từ những SEO, các lập trình viên chính của đội code NukeViet; qua đó&nbsp;nâng cao không chỉ kỹ năng chuyên môn liên quan đến công việc mà còn các kỹ năng mềm trong quá trình làm việc hàng ngày.</li>	<li style=\"text-align: justify;\">Tham gia các chương trình ngoại khóa, các hoạt động nội bộ của công ty.</li>	<li style=\"text-align: justify;\">Cơ&nbsp;hội ưu tiên (không cần qua thử việc) trở thành nhân viên chính thức nếu có kết quả học việc tốt.</li></ul><h2 style=\"text-align: justify;\"><b>Thời gian làm việc</b></h2><ul>	<li style=\"text-align: justify;\">Toàn thời gian cố định hoặc làm online.</li>	<li style=\"text-align: justify;\">Thời gian làm việc là:&nbsp;8:00 – 17:00, Thứ hai – Thứ sáu</li>	<li style=\"text-align: justify;\">Ngày làm việc và thời gian làm việc có thể thay đổi linh hoạt tùy thuộc vào điều kiện của ứng viên và tình hình thực tế.</li></ul><h2 style=\"text-align: justify;\"><b>Đối tượng</b></h2><p style=\"text-align: justify;\">Tất cả các bạn sinh viên năm cuối/mới tốt nghiệp các trường CĐ - ĐH đáp ứng được những yêu cầu sau:</p><ul>	<li style=\"text-align: justify;\">Sinh viên khối ngành kinh tế: yêu thích marketing online, mong muốn thực tập trong lĩnh vực kinh doanh phần mềm.</li>	<li style=\"text-align: justify;\">Sinh viên khối ngành kỹ thuật: yêu thích thiết kế, lập trình web.</li></ul><p style=\"text-align: justify;\">Có kỹ năng giao tiếp và tư duy logic tốt, năng động và ham học hỏi.</p><p style=\"text-align: justify;\">Ưu tiên các ứng viên đam mê phần mềm nguồn mở, đặc biệt là các ứng viên đã từng tham gia và có bài viết diễn đàn NukeViet (<a href=\"http://forum.nukeviet.vn/\">forum.nukeviet.vn</a>)</p><h2 style=\"text-align: justify;\"><b>Điều kiện</b></h2><p style=\"text-align: justify;\">Có máy tính xách tay để làm việc.</p><p style=\"text-align: justify;\">Ứng viên sẽ được ký hợp đồng học việc (có thời hạn cụ thể). Nếu được nhận vào làm việc chính thức, người lao động phải làm ở công ty ít nhất 2 năm, nếu không làm hoặc nghỉ trước thời hạn sẽ phải hoàn lại tiền đào tạo. Chi phí này được tính là 3.000.000 VND</p><p style=\"text-align: justify;\">Nếu được cử đi học, người lao động phải làm ở công ty ít nhất 2 năm, nếu không làm hoặc nghỉ trước thời hạn sẽ phải hoàn lại tiền học phí.</p><p style=\"text-align: justify;\">Thực hiện theo các quy định khác của công ty...</p><h2 style=\"text-align: justify;\"><b>Cách thức ứng tuyển</b></h2><p style=\"text-align: justify;\">Gửi bản mềm đơn đăng ký ứng tuyển tới:&nbsp;<a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a>;</p><p style=\"text-align: justify;\">Tiêu đề mail ghi rõ: &#91;Họ tên&#93; –Ứng tuyển học việc&#91;Bộ phận ứng tuyển&#93;;</p><p style=\"text-align: justify;\">Ví dụ: Lê Văn Nam –&nbsp;Ứng tuyển học việc bộ phận đồ họa</p><p style=\"text-align: justify;\">Hồ sơ bản cứng cần chuẩn bị (sẽ gửi sau nếu đạt yêu cầu) gồm:</p><ul>	<li style=\"text-align: justify;\">Giấy khám sức khoẻ của cơ quan y tế</li>	<li style=\"text-align: justify;\">Bản sao giấy khai sinh (có công chứng).</li>	<li style=\"text-align: justify;\">Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn bằng chứng chỉ (có công chứng) nếu đã tốt nghiệp.</li>	<li style=\"text-align: justify;\">Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.</li>	<li style=\"text-align: justify;\">Chứng minh thư (photo không cần công chứng).</li>	<li style=\"text-align: justify;\">Thư giới thiệu (nếu có)</li>	<li style=\"text-align: justify;\">Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).</li></ul><p style=\"text-align: justify;\"><br  /><strong>Chi tiết vui lòng tham khảo tại:</strong>&nbsp;<a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p style=\"text-align: justify;\"><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /><br  />- Tel: +84-4-85872007 - Fax: +84-4-35500914<br  />- Email:&nbsp;<a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a>&nbsp;- Website:&nbsp;<a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></p></blockquote>', '', 2, 0, 1, 1, 1, 0), 
(16, '<div class=\"details-content clearfix\" id=\"bodytext\"><strong>Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo có gì mới?</strong><br  /><br  />Trong các hướng dẫn thực hiện nhiệm vụ CNTT từ năm 2010 đến nay liên tục chỉ đạo việc đẩy mạnh công tác triển khai sử dụng phần mềm nguồn mở trong nhà trường và các cơ quan quản lý giáo dục. Tuy nhiên Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo có nhiều thay đổi mạnh mẽ đáng chú ý, đặc biệt việc chỉ đạo triển khai các phần mềm nguồn mở vào trong các cơ sở quản lý giao dục được rõ ràng và cụ thể hơn rất nhiều.<br  /><br  />Một điểm thay đổi đáng chú ý đối với phần mềm nguồn mở, trong đó đã thay hẳn thuật ngữ &quot;phần mềm tự do mã nguồn mở&quot; hoặc &quot;phần mềm mã nguồn mở&quot; thành &quot;phần mềm nguồn mở&quot;, phản ánh xu thế sử dụng thuật ngữ phần mềm nguồn mở đã phổ biến trong cộng đồng nguồn mở thời gian vài năm trở lại đây.<br  /><br  /><strong>NukeViet - Phần mềm nguồn mở Việt - không chỉ được khuyến khích mà đã được hướng dẫn thực thi</strong><br  /><br  />Từ 5 năm trước, thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐTquy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục, NukeViet đã được đưa vào danh sách các mã nguồn mở <strong>được khuyến khích sử dụng trong giáo dục</strong>. Tuy nhiên, việc sử dụng chưa được thực hiện một cách đồng bộ mà chủ yếu làm nhỏ lẻ rải rác tại một số trường, Phòng và Sở GD&amp;ĐT.<br  /><br  />Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo lần này, NukeViet&nbsp; không chỉ được khuyến khích mà đã được hướng dẫn thực thi, không những thế NukeViet còn được đưa vào hầu hết các nhiệm vụ chính, cụ thể:<div><div><div>&nbsp;</div>- <strong>Nhiệm vụ số 5</strong> &quot;<strong>Công tác bồi dưỡng ứng dụng CNTT cho giáo viên và cán bộ quản lý giáo dục</strong>&quot;, mục 5.1 &quot;Một số nội dung cần bồi dưỡng&quot; có ghi &quot;<strong>Tập huấn sử dụng phần mềm nguồn mở NukeViet.</strong>&quot;<br  />&nbsp;</div>- <strong>Nhiệm vụ số 10 &quot;Khai thác, sử dụng và dạy học bằng phần mềm nguồn mở</strong>&quot; có ghi: &quot;<strong>Khai thác và áp dụng phần mềm nguồn mở NukeViet trong giáo dục.&quot;</strong><br  />&nbsp;</div>- Phụ lục văn bản, có trong nội dung &quot;Khuyến cáo khi sử dụng các hệ thống CNTT&quot;, hạng mục số 3 ghi rõ &quot;<strong>Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.</strong><br  />&nbsp;<div>Hiện giờ văn bản này đã được đăng lên website của Bộ GD&amp;ĐT: <a href=\"http://moet.gov.vn/?page=1.10&amp;view=983&amp;opt=brpage\" target=\"_blank\">http://moet.gov.vn/?page=1.10&amp;view=983&amp;opt=brpage</a></div><p><br  />Hoặc có thể tải về tại đây: <a href=\"http://vinades.vn/vi/download/van-ban-luat/Huong-dan-thuc-hien-nhiem-vu-CNTT-nam-hoc-2015-2016/\" target=\"_blank\">http://vinades.vn/vi/download/van-ban-luat/Huong-dan-thuc-hien-nhiem-vu-CNTT-nam-hoc-2015-2016/</a></p><blockquote><p><em>Trên cơ sở hướng dẫn của Bộ GD&amp;ĐT, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&amp;ĐT, Sở GD&amp;ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT.<br  /><br  />Các Phòng, Sở GD&amp;ĐT có nhu cầu có thể xem thêm thông tin chi tiết tại đây: <a href=\"http://vinades.vn/vi/news/thong-cao-bao-chi/Ho-tro-trien-khai-dao-tao-va-trien-khai-NukeViet-cho-cac-Phong-So-GD-DT-264/\" target=\"_blank\">Hỗ trợ triển khai đào tạo và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT</a></em></p></blockquote></div>', '', 2, 0, 1, 1, 1, 0), 
(17, '<div class=\"details-content clearfix\" id=\"bodytext\"><span style=\"font-size:16px;\"><strong>Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng phần mềm nguồn mở NukeViet</strong></span><br  /><br  />Công tác hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng phần mềm nguồn mở NukeViet sẽ được thực hiện bởi đội ngũ chuyên gia giàu kinh nghiệm về NukeViet được tuyển chọn từ lực lượng lập trình viên, chuyên viên kỹ thuật hiện đang tham gia phát triển và hỗ trợ về NukeViet từ Ban Quản Trị NukeViet và Công ty cổ phần phát triển nguồn mở Việt Nam và các đối tác thuộc Liên minh phần mềm giáo dục nguồn mở NukeViet.<br  /><br  />Với kinh nghiệm tập huấn đã được tổ chức thành công cho nhiều Phòng giáo dục và đào tạo, các chuyên gia về NukeViet sẽ giúp chuyển giao giáo trình, chương trình, kịch bản đào tạo cho các Phòng, Sở GD&amp;ĐT; hỗ trợ các giáo viên và cán bộ quản lý giáo dục sử dụng trong suốt thời gian sau đào tạo.<br  /><br  />Đặc biệt, đối với các đơn vị sử dụng NukeViet làm website và cổng thông tin đồng bộ theo quy mô cấp Phòng và Sở, cán bộ tập huấn của NukeViet sẽ có nhiều chương trình hỗ trợ khác như chương trình thi đua giữa các website sử dụng NukeViet trong cùng đơn vị cấp Phòng, Sở và trên toàn quốc; Chương trình báo cáo và giám sát và xếp hạng website hàng tháng; Chương trình tập huấn nâng cao trình độ sử dụng NukeViet hàng năm cho giáo viên và cán bộ quản lý giáo dục đang thực hiện công tác quản trị các hệ thống sử dụng nền tảng NukeViet.<br  /><br  /><span style=\"font-size:16px;\"><strong>Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT</strong></span><br  /><br  />Nhằm hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT một cách toàn diện, đồng bộ và tiết kiệm, hiện tại, Liên minh phần mềm nguồn mở giáo dục NukeViet chuẩn bị ra mắt. Liên minh này do Công ty cổ phần phát triển nguồn mở Việt Nam đứng dầu và thực hiện việc điều phối công các hỗ trợ và phối hợp giữa các đơn vị trên toàn quốc. Thành viên của liên minh là các doanh nghiệp cung cấp sản phẩm và dịch vụ phần mềm hỗ trợ cho giáo dục (kể cả những đơn vị chỉ tham gia lập trình và những đơn vị chỉ tham gia khai thác thương mại). Liên minh sẽ cùng nhau làm việc để xây dựng một hệ thống phần mềm thống nhất cho giáo dục, có khả năng liên thông và kết nối với nhau, hoàn toàn dựa trên nền tảng phần mềm nguồn mở. Liên minh cũng hỗ trợ và phân phối phần mềm cho các đơn vị làm phần mềm trong ngành giáo dục với mục tiêu là tiết kiệm tối đa chi phí trong khâu thương mại, mang tới cơ hội cho các đơn vị làm phần mềm giáo dục mà không cần phải lo lắng về việc phân phối phần mềm. Các doanh nghiệp quan tâm đến cơ hội kinh doanh bằng phần mềm nguồn mở, muốn tìm hiểu và tham gia liên minh có thể đăng ký tại đây: <a href=\"http://edu.nukeviet.vn/lienminh-dangky.html\" target=\"_blank\">http://edu.nukeviet.vn/lienminh-dangky.html</a><br  /><br  />Liên minh phần mềm nguồn mở giáo dục NukeViet đang cung cấp giải pháp cổng thông tin chuyên dùng cho phòng và Sở GD&amp;ĐT (NukeViet Edu Gate) cung cấp dưới dạng dịch vụ công nghệ thông tin (theo mô hình của <a href=\"http://vinades.vn/vi/download/van-ban-luat/Quyet-dinh-80-ve-thue-dich-vu-CNTT/\" target=\"_blank\">Quyết định số 80/2014/QĐ-TTg của Thủ tướng Chính phủ</a>) có thể hỗ trợ cho các trường, Phòng và Sở GD&amp;ĐT triển khai NukeViet ngay lập tức.<br  /><br  />Giải pháp cổng thông tin chuyên dùng cho phòng và Sở GD&amp;ĐT (NukeViet Edu Gate) có tích hợp website các trường (liên thông 3 cấp: trường - phòng - sở) cho phép tích hợp hàng ngàn website của các trường cùng nhiều dịch vụ khác trên cùng một hệ thống giúp tiết kiệm chi phí đầu tư, chi phí triển khai và bảo trì hệ thống bởi toàn bộ hệ thống được vận hành bằng một phần mềm duy nhất. Ngoài giải pháp cổng thông tin giáo dục tích hợp, Liên minh phần mềm nguồn mở giáo dục NukeViet cũng đang phát triển một số&nbsp;sản phẩm phần mềm dựa trên phần mềm nguồn mở NukeViet và sẽ sớm ra mắt trong thời gian tới.<div><br  />Hiện nay,&nbsp;NukeViet Edu Gate cũng&nbsp;đã được triển khai rộng rãi và nhận được sự ủng hộ của&nbsp;nhiều Phòng, Sở GD&amp;ĐT trên toàn quốc.&nbsp;Các phòng, sở GD&amp;ĐT quan tâm đến giải pháp NukeViet Edu Gate có thể truy cập&nbsp;<a href=\"http://edu.nukeviet.vn/\" target=\"_blank\">http://edu.nukeviet.vn</a>&nbsp;để tìm hiểu thêm hoặc liên hệ:<br  /><br  /><span style=\"font-size:14px;\"><strong>Liên minh phần mềm nguồn mở giáo dục NukeViet</strong></span><br  />Đại diện: <strong>Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC)</strong><br  /><strong>Địa chỉ</strong>: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội<br  /><strong>Email</strong>: contact@vinades.vn, Tel: 04-85872007, <strong>Fax</strong>: 04-35500914,<br  /><strong>Hotline</strong>: 0904762534 (Mr. Hùng), 0936226385 (Ms. Ngọc),&nbsp;<span style=\"color: rgb(38, 38, 38); font-family: arial, sans-serif; font-size: 13px; line-height: 16px;\">0904719186 (Mr. Hậu)</span><br  />Các Phòng GD&amp;ĐT, Sở GD&amp;ĐT có thể đăng ký tìm hiểu, tổ chức hội thảo, tập huấn, triển khai NukeViet trực tiếp tại đây: <a href=\"http://edu.nukeviet.vn/dangky.html\" target=\"_blank\">http://edu.nukeviet.vn/dangky.html</a><br  /><br  /><span style=\"font-size:16px;\"><strong>Tìm hiểu về phương thức chuyển đổi các hệ thống website cổng thông tin sang NukeViet theo mô hình tích hợp liên thông từ trưởng, lên Phòng, Sở GD&amp;ĐT:</strong></span><br  /><br  />Đối với các Phòng, Sở GD&amp;ĐT, trường Nầm non, tiểu học, THCS, THPT... chưa có website, Liên minh phần mềm nguồn mở giáo dục NukeViet sẽ hỗ trợ triển khai NukeViet theo mô hình cổng thông tin liên cấp như quy định tại <a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-quy-dinh-ve-ve-to-chuc-hoat-dong-su-dung-thu-dien-tu/\" target=\"_blank\">thông tư số <strong>53/2012/TT-BGDĐT</strong> của Bộ GD&amp;ĐT</a> ban hành ngày 20-12-2012 quy định về quy định về về tổ chức hoạt động, sử dụng thư điện tử và cổng thông tin điện tử tại sở giáo dục và đào tạo, phòng giáo dục và đào tạo và các cơ sở GDMN, GDPT và GDTX.<br  /><br  />Trường hợp các đơn vị có website và đang sử dụng NukeViet theo dạng rời rạc thì việc chuyển đổi và tích hợp các website NukeViet rời rạc vào NukeViet Edu Gate của Phòng và Sở có thể thực hiện dễ dàng và giữ nguyên toàn bộ dữ liệu.<br  /><br  />Trường hợp các đơn vị có website và nhưng không sử dụng NukeViet cũng có thể chuyển đổi sang sử dụng NukeViet để hợp nhất vào hệ thống cổng thông tin giáo dục cấp Phòng, Sở. Tuy nhiên mức độ và tỉ lệ dữ liệu được chuyển đổi thành công sẽ phụ thuộc vào tình hình thực tế của từng website.</div></div>', '', 2, 0, 1, 1, 1, 0), 
(18, '<p dir=\"ltr\" style=\"text-align: justify;\">Trải qua hơn 10 năm phát triển, từ một mã nguồn chỉ mang tính cá nhân, NukeViet đã phát triển thành công theo hướng cộng đồng. Năm 2010, NukeViet 3 ra đời đánh dấu một mốc lớn trong quá trình đi lên của NukeViet, phát triển theo hướng chuyên nghiệp với sự hậu thuẫn của Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). NukeViet 3 đã và được sử dụng rộng rãi trong cộng đồng, từ các cổng thông tin tổ chức, hệ thống giáo dục, cho đến các website cá nhân, thương mại, mang lại các trải nghiệm vượt trội của mã nguồn thương hiệu Việt so với các mã nguồn nổi tiếng khác trên thế giới.<br  /><br  />Năm 2016, NukeViet 4 ra đời được xem là một cuộc cách mạng lớn trong chuỗi sự kiện phát triển NukeViet, cũng như xu thế công nghệ hiện tại. Hệ thống gần như được đổi mới hoàn toàn từ nhân hệ thống đến giao diện, nâng cao đáng kể hiệu suất và trải nghiệm người dùng.<br  /><br  /><span style=\"line-height: 1.6;\"><strong>Dưới đây là một số thay đổi của NukeViet 4.</strong></span><br  /><strong><span style=\"line-height: 1.6;\">Các thay đổi từ nhân hệ thống:</span></strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Các công nghệ mới được áp dụng.</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Sử dụng composer để quản lý các thư viện PHP được cài vào hệ thống.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Từng bước áp dụng &nbsp;các tiêu chuẩn viết code PHP theo khuyến nghị của <a href=\"http://www.php-fig.org/psr/\">http://www.php-fig.org/psr/</a></p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Sử dụng PDO để thay cho extension MySQL.</p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Tăng cường khả năng bảo mật</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Sau khi các chuyên giả bảo mật của HP gửi đánh giá, chúng tôi đã tối ưu NukeViet 4.0 để hệ thống an toàn hơn.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Mã hóa các mật khẩu lưu trữ trong hệ thống: Các mật khẩu như FPT, SMTP,... đã được mã hóa, bảo mật thông tin người dùng.</p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Tối ưu SEO:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">SEO được xem là một trong những ưu tiên hàng đầu được phát triển trong phiên bản này. NukeViet 4 tập trung tối ưu hóa SEO Onpage mạnh mẽ. Các công cụ hỗ trợ SEO được tập hợp lại qua module “Công cụ SEO”. Các chức năng được thêm mới:</p>		<ul>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Loại bỏ tên module khỏi URL khi không dùng đa ngôn ngữ</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Cho phép đổi đường dẫn module</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Thêm chức năng xác thực Google+ (Bản quyền tác giả)</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Thêm chức năng ping đến các công cụ tìm kiếm: Submit url mới đến google để việc hiển thị bài viết mới lên kết quả tìm kiếm nhanh chóng hơn.</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Hỗ trợ Meta OG của facebook</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\" style=\"text-align: justify;\">Hỗ trợ chèn Meta GEO qua Cấu hình Meta-Tags</p>			</li>		</ul>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Cùng với đó, các module cũng được tối ưu hóa bằng các form hỗ trợ khai báo tiêu đề, mô tả (description), từ khóa (keywods) cho từng khu vực, từng trang. &nbsp;</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Với sự hỗ trợ tối đa này, người quản trị (admin) có thể tùy biến lại website theo phong cách SEO riêng biệt.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Thay đổi giao diện, sử dụng giao diện tuỳ biến</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Giao diện trong NukeViet 4 được làm mới, tương thích với nhiều màn hình hơn.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Sử dụng thư viện bootstrap để việc phát triển giao diện thống nhất và dễ dàng hơn.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Hệ thống nhận thông báo:&nbsp;</strong><span style=\"line-height: 1.6;\">Có thể gọi đây là một tiện ích nhỏ, song nó rất hữu dụng để admin tương tác với hệ thống một cách nhanh chóng. Admin có thể nhận thông báo từ hệ thống (hoặc từ module) khi có sự kiện nào đó.</span></p>	</li></ul><p dir=\"ltr\" style=\"text-align: justify; margin-left: 40px;\"><strong>Ví dụ:</strong> Khi có khách gửi liên hệ (qua module contact) đến thì hệ thống xuất hiện biểu tượng thông báo “Có liên hệ mới” ở góc phải, Admin sẽ nhận được ngay lập tức thông báo khi người dùng đang ở Admin control panel (ACP).</p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Thay đổi cơ chế quản lý block:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Nhận thấy việc hiển thị block ở lightbox trong NukeViet 3 dẫn đến một số bất tiện trong quá trình quản lý, NukeViet 4 đã thay thế cách hiển thị này ở dạng cửa sổ popup. Dễ nhận thấy sự thay đổi này khi admin thêm (hoặc sửa) một block nào đó.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">“Cấu hình hiển thị block trên các thiết bị” cũng được đưa vào phần cấu hình block, admin có thể tùy chọn cho phép block hiển thị trên các thiết bị nào (tất cả thiết bị, thiết bị di động, máy tính bảng, thiết bị khác).<span style=\"line-height: 1.6;\">&nbsp;</span></p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Thêm ngôn ngữ tiếng Pháp:</strong> website cài đặt mới có sẵn 3 ngôn ngữ mặc định là Việt, Anh và Pháp.</p>	</li></ul><p dir=\"ltr\" style=\"text-align: justify;\"><strong>Các thay đổi của module:</strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Module menu:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Phương án quản lý menu được thay đổi hướng tới việc quản lý menu nhanh chóng, tiện lợi nhất cho admin. Admin có thể nạp nhanh menu theo các tùy chọn mà hệ thống cung cấp.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Mẫu menu cũng được thay đổi, đa dạng và hiển thị tốt với các giao diện hiện đại.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Module contact (Liên hệ):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Bổ sung các trường thông tin về bộ phận (Điện thoại, fax, email, các trường liên hệ khác,...).</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Admin có thể trả lời khách nhiều lần, hệ thống lưu lại lịch sử trao đổi đó.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Module users (Tài khoản):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thay thế OpenID bằng thư viện OAuth - hỗ trợ tích hợp đăng nhập qua tài khoản mạng xã hội</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Cho phép đăng nhập 1 lần tài khoản người dùng NukeViet với Alfresco, Zimbra, Moodle, Koha</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm chức năng tùy biến trường dữ liệu thành viên</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm chức năng phân quyền sử dụng module users</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm cấu hình: Số ký tự username, độ phức tạp mật khẩu, tạo mật khảu ngẫu nhiên,....</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Cho phép sử dụng tên truy cập, hoặc email để đăng nhập</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Module about:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Module about ở NukeViet 3 được đổi tên thành module page</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm các cấu hình hỗ trợ SEO: Ảnh minh họa, chú thích ảnh minh họa, mô tả, từ khóa cho bài viết, hiển thị các công cụ tương tác với các mạng xã hội.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm RSS</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Cấu hình phương án hiển thị các bài viết trên trang chính</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\"><strong>Module news (Tin tức):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm phân quyền cho người quản lý module, đến từng chủ đề</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thay đổi phương án lọc từ khóa bài viết, lọc từ khóa theo các từ khóa đã có trong tags thay vì đọc từ từ điển.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Bổ sung các trạng thái bài viết</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm cấu hình mặc định hiển thị ảnh minh họa trên trang xem chi tiết bài viết</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\" style=\"text-align: justify;\">Thêm các công cụ tương tác với mạng xã &nbsp;hội.</p>		</li>	</ul>	</li></ul><p dir=\"ltr\" style=\"text-align: justify;\"><strong>Quản lý Bình luận</strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\" style=\"text-align: justify;\">Các bình luận của các module sẽ được tích hợp quản lý tập trung để cấu hình.</p>	</li>	<li dir=\"ltr\" style=\"text-align: justify;\">Khi xây dựng mới module, Chỉ cần nhúng 1 đoạn mã vào. Tránh phải việc copy mã code gây khó khăn cho bảo trì.</li></ul>', '', 2, 0, 1, 1, 1, 0), 
(19, '<h2><span style=\"color:rgb(255, 0, 0);\"><strong>1. Tốc độ</strong></span></h2><div style=\"text-align:center\"><img alt=\"litespeed benchmark\" height=\"292\" src=\"/egov/uploads/news/2016_01/litespeed-benchmark.jpg\" width=\"540\" /></div><br  />Tốc độ truy cập website rất quan trọng, ảnh hưởng đến trải nghiệm của người dùng cũng như thứ hạng trên các bộ máy tìm kiếm (Google, Bing...). Website có tốc độ nhanh là website không để người dùng &quot;chờ&quot; khi click vào bất cứ trang nào. Hay nói cách khác tốc độ load trang phải 1 giây trở xuống. Có 2 yếu tố tác động đến tốc độ đó là &quot;sự tối ưu của mã nguồn website&quot; và &quot;sự tối ưu của hệ thống hosting&quot;<br  />&nbsp;<ul>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Sự tối ưu của mã nguồn website:</strong></span> Nếu bạn đang dùng NukeViet, bạn đang rất may mắn bởi NukeViet được thiết kế để tối ưu và tăng tốc truy cập.</li>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Sự tối ưu của hệ thống hosting:</strong></span> Các nhà cung cấp hosting kinh nghiệm và uy tín luôn tối ưu hệ thống Hosting của họ một cách tốt nhất, hãy để ý một số tiêu chí sau để đánh giá mức độ VIP về việc tối ưu tốc độ của hosting bạn đang sử dụng:	<ul>		<li><strong>Ổ cứng SSD:</strong> Công nghệ ổ cứng SSD đang được sử dụng mạnh mẽ để thay thế các ổ cứng SATA thế hệ cũ bởi tốc độ đọc ghi dữ liệu của ổ cứng SSD cực nhanh, giúp máy chủ hosting xử lý và đọc ghi dữ liệu nhanh hơn. Công nghệ này không những áp dụng vào hệ thống hosting mà còn đang áp dụng với hầu hết các hệ thống máy chủ thời nay.</li>		<li><strong>Webserver Litespeed:</strong> Đây là phần mềm web server có tốc độ nhanh nhất (nhanh gấp 5 lần Apache), là giải pháp thay thế cho web server truyền thống Apache. Web server này cũng được đánh giá là ổn định và bảo mật. Tuy nhiên đây là phần mềm web server có bản quyền<strong>. <span style=\"background-color:rgb(250, 235, 215);\">Nếu nhà cung cấp hosting của bạn sử dụng phần mềm này, họ đã đầu tư bài bản cho hệ thống hosting của mình</span></strong>.</li>	</ul>	</li></ul><h2><span style=\"color:rgb(255, 0, 0);\"><strong>2. Bảo mật</strong></span></h2><div style=\"text-align:center\"><img alt=\"cloudlinux security\" height=\"312\" src=\"/egov/uploads/news/2016_01/cloudlinux-security.jpg\" width=\"540\" /></div><br  />Khi sử dụng hosting, bạn cần quan tâm đến hình thức tấn công &quot;local attack&quot;. Bởi một máy chủ hosting có rất nhiều tài khoản hosting khác nhau. Local attack là hình thức chiếm quyền điều khiển tài khoản hosting A (vì website trên hosting A này bị lỗi bảo mật hoặc bị lộ mật khẩu) sau đó dùng hosting A để chiếm quyền điền khiển sang hosting B - hosting của bạn. Hình thức tấn công này rất nguy hiểm, tuy nhiên hãy để ý, <strong><span style=\"background-color:rgb(255, 255, 224);\">nếu nhà cung cấp hosting nào đang sử dụng công nghệ &quot;CloudLinux&quot;, hosting của họ đã chống được gần như 100% hình thức tấn công này</span></strong><span style=\"background-color:rgb(255, 255, 224);\">.</span><h3>&nbsp;</h3><h2><span style=\"color:rgb(255, 0, 0);\"><strong>3. Ổn định</strong></span></h2><div style=\"text-align:center\"><img alt=\"123host network security\" height=\"310\" src=\"/egov/uploads/news/2016_01/123host-network-security.jpg\" width=\"540\" /></div><br  />Sự ổn định rất quan trọng bởi bạn sẽ sử dụng hosting lâu dài ngày này qua ngày khác. Sự chập chờn, gián đoạn truy cập chỉ trong ít phút cũng đã ảnh hưởng đến doanh thu, thứ hạn, làm giảm lượng truy cập vào website bạn. Các yếu tố cơ bản sau ảnh hưởng đến độ ổn định của dịch vụ hosting:<ul>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Network &amp; Datacenter: </strong></span>Hạ tầng network ổn định đặt tại các datacenter lớn là tiêu chí rất quan trọng. <strong><span style=\"background-color:rgb(255, 255, 224);\">Các nhà cung cấp hosting lớn luôn đặt máy chủ của mình tại các datacenter lớn nhất Việt Nam như VDC2 hoặc ViettelIDC</span></strong>.</li>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Chống tấn công DDOS: </strong></span>Đây là yếu tố cực kỳ quan trọng giúp các máy chủ hosting ổn định. Một máy chủ hosting có thể chứa hàng nghìn website, vì vậy thường xuyên sẽ có những cuộc tấn công DDOS vào một trong số các website này và sẽ ảnh hưởng toàn bộ máy chủ hosting và tất nhiên sẽ ảnh hưởng đến website của bạn. Truy cập sẽ chập chờn, lúc chậm lúc nhanh và có khi sẽ gián đoạn<strong>. <span style=\"background-color:rgb(255, 255, 224);\">Hãy để ý các nhà cung cấp hosting tốt luôn có hệ thống Firewall</span> </strong>(tường lửa) chuyện dụng cho hosting của mình.</li></ul><h2><br  /><span style=\"color:rgb(255, 0, 0);\"><strong>4. Hỗ trợ</strong></span></h2><div style=\"text-align:center\"><img alt=\"support247\" height=\"151\" src=\"/egov/uploads/news/2016_01/support247.jpg\" width=\"540\" /></div><br  />Không cần bàn cãi gì nữa, một nhà cung cấp hosting tốt luôn:<br  />&nbsp;<ul>	<li>Hỗ trợ khách hàng 24/7 bất kể là đêm hay ngày, kể cả những ngày lễ tết.</li>	<li>Hỗ trợ nhanh và nhiệt tình, giải quyết các vấn đề bạn gặp phải nhanh chóng.</li></ul><h3>&nbsp;</h3><h2><span style=\"color:rgb(255, 0, 0);\"><strong>5. Các tham số quan trọng của hosting</strong><span style=\"font-size: 13px; line-height: 1.6;\">&nbsp;</span></span></h2><ul>	<li><strong><span style=\"color:rgb(0, 0, 205);\">Băng thông</span></strong> (bandwidth): Tham số này rất quan trọng nếu website của bạn chứa nhiều hình ảnh và lượng truy cập website cao. Vì vậy khi lựa chọn hosting, hãy để ý tham số băng thông, tốt nhất <strong><span style=\"background-color:rgb(255, 255, 224);\">nên chọn các nhà cung cấp hosting không giới hạn băng thông</span></strong>&nbsp;để khỏi lo lắng về vấn đề này.</li>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Tự ý thay đổi được phiên bản PHP</strong></span>, thành phần mở rộng (extension) của PHP cũng như các tham số cấu hình PHP: Yếu tố này cũng khá quan trọng, ví dụ bạn đang dùng NukeViet 3, phiên bản NukeViet này yêu cầu PHP version là 5.3, nếu bạn nâng cấp Nukeviet lên Nukeviet 4, yêu cầu phiên bản PHP phải là 5.4 . Vì vậy<strong> <span style=\"background-color:rgb(255, 255, 224);\">hãy chọn lựa các nhà cung cấp hosting cho phép bạn thay đổi được các phiên bản PHP</span></strong> cũng như các tham số cấu hình nó.</li></ul>&nbsp;<br  />Đến thời điểm hiện tại, <a href=\"https://123host.vn/web-hosting.html\" target=\"_blank\"><strong>123HOST</strong></a> là nhà cung cấp hosting đầu tiên&nbsp;<span style=\"color:rgb(0, 0, 205);\"><strong>đạt chứng nhận tương thích với mã nguồn NukeViet 4 </strong></span>(xem tại <a href=\"http://nukeviet.vn/vi/partner/hosting/\">http://nukeviet.vn/vi/partner/hosting/</a> ).&nbsp; Đồng thời họ cũng là nhà cung cấp hosting uy tín đáp ứng được tất cả 5 tiêu chí khắt khe trên.<br  />&nbsp;<div style=\"text-align:center\"><img alt=\"hosting 123host nukeviet\" height=\"298\" src=\"/egov/uploads/news/2016_01/hosting-123host-nukeviet.jpg\" width=\"540\" /></div><br  /><br  />Nếu sử dụng NukeViet hay bất kỳ mã nguồn mở nào khác, chúng tôi khuyên bạn nên dùng dịch vụ tại <strong>123HOST</strong>. Ngoài đáp ứng 5 tiêu chí trên, hosting tại <strong>123HOST</strong> còn có các tính năng đặc biệt mà không nhà cung cấp nào có:<ul>	<li>Tất cả các gói hosting của <strong>123HOST</strong> đều<strong> <span style=\"color:rgb(0, 0, 205);\">không giới hạn băng thông</span></strong>, parked domain, tài khoản email, FTP, tài khoản MySQL. Hầu như tất cả đều không giới hạn cho tất cả các gói hosting.</li>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>DDOS Protection:</strong> </span>Nếu dùng hosting của các nhà cung cấp khác, khi website của bạn bị tấn công DDOS, họ sẽ khóa website của bạn để khỏi ảnh hưởng đến máy chủ hosting. Tuy nhiên tại <strong>123HOST</strong>, hệ thống của họ sẽ tự phát hiện và bật cản lọc tấn công cho website của bạn. Đồng thời bạn cũng có thể tự&nbsp; mình kích hoạt tính năng này tại giao diện cPanel. &nbsp;Website của bạn sẽ an toàn và hoạt động bình thường.</li>	<li><span style=\"color:rgb(0, 0, 205);\"><strong>Malware Scanner:</strong></span> Tính năng này được tích hợp tại cPanel để người dùng quét xem mã nguồn website của mình có bị kẻ xấu lợi dụng và upload mã độc lên hay không. Đồng thời họ cũng hỗ trợ kiểm tra mã nguồn cho bạn nếu bạn gởi yêu cầu hỗ trợ kỹ thuật.</li>	<li><strong><span style=\"color:rgb(0, 0, 205);\">Backup miễn phí:</span> </strong>Hosting tại <strong>123HOST</strong> đều tự động backup trong vòng 7 ngày, mỗi ngày 1 bản backup. Nếu bạn lỡ tay xóa mất dữ liệu website của mình hay website bị kẻ xấu hack và xóa dữ liệu, hãy bình tĩnh và liên hệ với kỹ thuật của 123HOST, họ sẽ khôi phục website cho bạn MIỄN PHÍ.</li></ul><div style=\"text-align:center\"><img alt=\"cpanel ddos protection malware scanner\" height=\"300\" src=\"/egov/uploads/news/2016_01/cpanel-ddos-protection-malware-scanner.jpg\" width=\"540\" /></div><br  />Chúc các bạn thành công.<br /><br />----<div>Giấy phép:<br /><a href=\"http://creativecommons.org/licenses/by-nc-sa/4.0/\" rel=\"license\" target=\"_blank\"><img alt=\"CC BY NC SA\" height=\"15\" src=\"/egov/uploads/news/2016_01/cc-by-nc-sa.png\" style=\"border-width: 0px;\" width=\"80\" /></a><br />Bài viết này được chia sẻ với các điều khoản của <a href=\"http://creativecommons.org/licenses/by-nc-sa/4.0/\" rel=\"license\" target=\"_blank\">giấy phép Creative Commons Attribution-NonCommercial-ShareAlike 4.0</a>.<br />Nguồn: <a href=\"https://123host.vn/blog/chon-nha-cung-cap-hosting-nao-tot-cho-nukeviet.html\" target=\"_blank\">https://123host.vn/blog/chon-nha-cung-cap-hosting-nao-tot-cho-nukeviet.html</a></div>', '', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_logs`
--

DROP TABLE IF EXISTS `nn1_vi_news_logs`;
CREATE TABLE `nn1_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_rows`
--

DROP TABLE IF EXISTS `nn1_vi_news_rows`;
CREATE TABLE `nn1_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=20  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_rows`
--

INSERT INTO `nn1_vi_news_rows` VALUES
(6, 1, '1', 0, 1, 'Nguyễn Thế Hùng', 6, 1453192444, 1492874548, 1, 1453192440, 0, 2, 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', 'hay-tro-thanh-nha-cung-cap-dich-vu-cua-nukeviet', 'Nếu bạn là công ty hosting, là công ty thiết kế web có sử dụng mã nguồn NukeViet, là cơ sở đào tạo NukeViet hay là công ty bất kỳ có kinh doanh dịch vụ liên quan đến NukeViet... hãy cho chúng tôi biết thông tin liên hệ của bạn để NukeViet hỗ trợ bạn trong công việc kinh doanh nhé!', 'hoptac.jpg', '', 1, 1, '6', 1, 16, 0, 0, 0), 
(7, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1453192400, 1453192400, 1, 1453192400, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-PHP', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về PHP và MySQL?. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 1, 0, 0, 0), 
(8, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1445391089, 1445394192, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ phát triển NukeViet', 'Tuyen-dung-chuyen-vien-do-hoa', 'Bạn đam mê nguồn mở? Bạn là chuyên gia đồ họa? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0), 
(9, 11, '11', 0, 1, 'Phạm Quốc Tiến', 0, 1445391090, 1445394193, 1, 1445391060, 0, 2, 'Tuyển dụng lập trình viên front-end (HTML/CSS/JS) phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về front-end (HTML/CSS/JS)?. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 5, 1445309676, 1492874394, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(12, 11, '11', 0, 1, 'Vũ Bích Ngọc', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Công ty cổ phần phát triển nguồn mở Việt Nam là đơn vị chủ quản của phần mềm mã nguồn mở NukeViet - một mã nguồn được tin dùng trong cơ quan nhà nước, đặc biệt là ngành giáo dục. Chúng tôi cần tuyển 05 nhân viên kinh doanh cho lĩnh vực này.', 'tuyen-dung-nvkd.png', '', 1, 1, '4', 1, 0, 0, 0, 0), 
(14, 1, '1,11', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 1, 0, 0, 0), 
(15, 11, '11', 0, 1, 'Trần Thị Thu', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Công ty cổ phần phát triển nguồn mở Việt Nam tạo cơ hội việc làm và học việc miễn phí cho những ứng viên có đam mê thiết kế web, lập trình PHP… được học tập và rèn luyện cùng đội ngũ lập trình viên phát triển NukeViet.', 'hoc-viec-tai-cong-ty-vinades.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, NukeViet được đưa vào các hạng mục: Tập huấn sử dụng phần mềm nguồn mở cho giáo viên và cán bộ quản lý giáo dục; Khai thác, sử dụng và dạy học; đặc biệt phần &quot;khuyến cáo khi sử dụng các hệ thống CNTT&quot; có chỉ rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.', 'nukeviet-cms.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0), 
(17, 10, '10', 0, 1, '', 0, 1445391217, 1492874569, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Trên cơ sở Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&ĐT, Sở GD&ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&ĐT', 'tap-huan-pgd-ha-dong-2015.jpg', 'Tập huấn triển khai NukeViet tại Phòng Giáo dục và Đào tạo Hà Đông - Hà Nội', 1, 1, '4', 1, 3, 0, 0, 0), 
(18, 2, '2', 0, 1, 'VINADES', 0, 1453194455, 1492874433, 1, 1453194420, 0, 2, 'NukeViet 4.0 có gì mới?', 'nukeviet-4-0-co-gi-moi', 'NukeViet 4 là phiên bản NukeViet được cộng đồng đánh giá cao, hứa hẹn nhiều điểm vượt trội về công nghệ đến thời điểm hiện tại. NukeViet 4 thay đổi gần như hoàn toàn từ nhân hệ thống đến chức năng, giao diện người dùng. Vậy, có gì mới trong phiên bản này?', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 4, 0, 0, 0), 
(19, 10, '10', 0, 1, '123host', 0, 1453192440, 1453192440, 1, 1453192440, 0, 2, 'Chọn nhà cung cấp Hosting nào tốt cho NukeViet?', 'chon-nha-cung-cap-hosting-nao-tot-cho-nukeviet', 'NukeViet được xây dựng và phát triển để tương thích với nhiều loại hosting và server. Tuy nhiên, để website NukeViet của bạn hoạt động tốt trên môi trường internet, cần chọn một nhà cung cấp Hosting uy tín, tin cậy và để &quot;chọn mặt gởi vàng&quot; website của mình. Bài viết này sẽ trình bày các tiêu chí để lựa chọn một nhà cung cấp Hosting tốt cho website của bạn.', '2016_01/how-to-choose-hosting.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_sources`
--

DROP TABLE IF EXISTS `nn1_vi_news_sources`;
CREATE TABLE `nn1_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_sources`
--

INSERT INTO `nn1_vi_news_sources` VALUES
(5, 'mic.gov.vn', '', '', 1, 1492874394, 1492874394), 
(6, 'vinades.vn', 'http://vinades.vn', '', 2, 1492874548, 1492874548);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_tags`
--

DROP TABLE IF EXISTS `nn1_vi_news_tags`;
CREATE TABLE `nn1_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=43  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_tags_id`
--

DROP TABLE IF EXISTS `nn1_vi_news_tags_id`;
CREATE TABLE `nn1_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_tid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_news_topics`
--

DROP TABLE IF EXISTS `nn1_vi_news_topics`;
CREATE TABLE `nn1_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_news_topics`
--

INSERT INTO `nn1_vi_news_topics` VALUES
(1, 'NukeViet 4', 'NukeViet-4', '', 'NukeViet 4', 1, 'NukeViet 4', 1445396011, 1445396011);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_page`
--

DROP TABLE IF EXISTS `nn1_vi_page`;
CREATE TABLE `nn1_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_page_config`
--

DROP TABLE IF EXISTS `nn1_vi_page_config`;
CREATE TABLE `nn1_vi_page_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_page_config`
--

INSERT INTO `nn1_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_referer_stats`
--

DROP TABLE IF EXISTS `nn1_vi_referer_stats`;
CREATE TABLE `nn1_vi_referer_stats` (
  `host` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_searchkeys`
--

DROP TABLE IF EXISTS `nn1_vi_searchkeys`;
CREATE TABLE `nn1_vi_searchkeys` (
  `id` varchar(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skey` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_voting`
--

DROP TABLE IF EXISTS `nn1_vi_voting`;
CREATE TABLE `nn1_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_voting`
--

INSERT INTO `nn1_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 4?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Lợi ích của phần mềm nguồn mở là gì?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_voting_rows`
--

DROP TABLE IF EXISTS `nn1_vi_voting_rows`;
CREATE TABLE `nn1_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_voting_rows`
--

INSERT INTO `nn1_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng HTML5, CSS3 và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nn1_vi_work_schedules_rows`
--

DROP TABLE IF EXISTS `nn1_vi_work_schedules_rows`;
CREATE TABLE `nn1_vi_work_schedules_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `correct_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Hiệu chỉnh cho',
  `correct_userid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Người hiệu chỉnh',
  `post_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Người đăng lịch',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Tạo lúc',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Cập nhật lần cuối lúc',
  `e_day` smallint(2) unsigned NOT NULL DEFAULT '0' COMMENT 'Ngày',
  `e_month` smallint(2) unsigned NOT NULL DEFAULT '0' COMMENT 'Tháng',
  `e_week` smallint(2) unsigned NOT NULL DEFAULT '0' COMMENT 'Tuần',
  `e_year` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Năm',
  `e_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'TG bắt đầu kiểu số',
  `e_shour` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Giờ bắt đầu',
  `e_smin` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Phút bắt đầu',
  `e_ehour` smallint(4) NOT NULL DEFAULT '-1' COMMENT 'Giờ kết thúc',
  `e_emin` smallint(4) NOT NULL DEFAULT '-1' COMMENT 'Phút kết thúc',
  `e_content` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nội dung sự kiện',
  `e_element` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Thành phần',
  `e_location` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Địa điểm',
  `e_host` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Chủ trì',
  `e_note` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Ghi chú',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0: Ẩn, 1: Hiện',
  `highlights` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0: Bình thường, 1: Nhấn mạnh',
  PRIMARY KEY (`id`),
  KEY `e_day` (`e_day`),
  KEY `e_month` (`e_month`),
  KEY `e_week` (`e_week`),
  KEY `e_year` (`e_year`),
  KEY `e_time` (`e_time`),
  KEY `post_id` (`post_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nn1_vi_work_schedules_rows`
--

INSERT INTO `nn1_vi_work_schedules_rows` VALUES
(1, 0, 0, 1, 1492929687, 1492929687, 24, 4, 17, 2017, 1492974300, 2, 5, 6, 6, 'Họp giao ban', 'TC', 'Hoi truong', 'Chu tich', '', 1, 0);